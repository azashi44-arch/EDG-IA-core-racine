# EDG-IA Core

Moteur d'IA du projet EDG-IA : outils, serveur et évaluations pour recevoir, adapter, évaluer et exécuter le
modèle livré par l'équipe d'entraînement. Projet **indépendant** de l'application EDG-IA, relié plus tard par une API sécurisée.

> **État : phases 1 à 8 écrites (registre/adaptateur, données et adaptation LoRA, évaluations, base documentaire, déploiement, contrat d'intégration). Aucun modèle réel n'a encore été chargé, entraîné ni évalué.**
> Il n'y a **aucun modèle entraîné** dans ce projet. Par défaut le serveur répond avec `edgia-demo`, un modèle de
> démonstration qui ne génère pas de texte avec une IA et se déclare comme tel dans chaque réponse.
> Le mode réel (`EDGIA_MODE=real`) est écrit pour charger un modèle Transformers, mais **n'a jamais été exécuté avec un
> vrai modèle** : voir `docs/GUIDE_SPECIALISTES.md`.

## Ce qui fonctionne aujourd'hui

- Configuration sécurisée par défaut (`.env.example`).
- Descripteur de modèle strict (`configs/model.example.yaml`) : fichiers, format, runtime, licence, matériel, adaptation, SHA-256.
- Vérification « le service peut-il démarrer ? » sans rien télécharger ni charger : `python -m edgia_core check-config`.
- Serveur HTTP (`python -m edgia_core serve`) : `/health`, `/ready`, `/v1/models`, `/v1/chat/completions`, streaming SSE,
  authentification par clé, limite de débit, limites de taille, délai d'attente, limite de concurrence, journaux sans contenu.
  Voir [docs/API.md](docs/API.md).
- Registre de modèles (versions, validation, activation contrôlée, retour arrière) : `python -m edgia_core models --registry … list`.
- Mode réel : chargement d'un modèle Transformers local (safetensors, adaptateur LoRA facultatif), arrêts, annulation,
  streaming, refus de démarrer au moindre doute. **Non validé sur un vrai modèle.**
- Préparation de données d'adaptation (nettoyage, données personnelles, anti-contamination, doublons, découpage) : `edgia-core data prepare`.
- Plan d'entraînement LoRA qui refuse au moindre doute : `edgia-core train plan` (**la boucle d'entraînement n'a jamais été exécutée**).
- Évaluation sur des cas en français et comparaison de modèles : `edgia-core eval run | compare` (voir docs/EVALUATION.md).
- Base documentaire EDG-IA (notes de démarrage, recherche lexicale, sources citées, droits obligatoires) : `edgia-core knowledge --db data/knowledge.sqlite3 seed-starter`, `POST /v1/knowledge/search`, champ `knowledge` du chat ou recherche automatique (`EDGIA_KNOWLEDGE_AUTO_SEARCH=true`). Voir `docs/KNOWLEDGE.md`.
- Apprentissage par le chat (leçons proposées par les utilisateurs, relecture humaine, faits indexés, exemples exportables ; aucun réentraînement automatique) : `edgia-core learning …`, `POST /v1/learning/lessons` — voir [docs/LEARNING.md](docs/LEARNING.md).
- Exploitation : `edgia-core doctor` (diagnostic avant déploiement), `edgia-core backup` (sauvegarde vérifiable des bases) ; Docker, systemd et proxy TLS fournis **mais jamais exécutés** (docs/DEPLOIEMENT.md).
- Plus de 350 tests (unitaires, API, serveur lancé en processus réel), sans réseau externe, sans modèle, sans GPU.

## Installation (développement)

Python 3.11 ou plus (testé uniquement avec 3.13.16). Dépendances : pydantic, PyYAML, starlette, uvicorn.

```bash
python -m venv .venv && . .venv/bin/activate
pip install -e .
```

> `pip install -e .` n'a **pas pu être vérifié** pendant la phase 1 (setuptools trop ancien dans l'environnement de
> développement, voir `docs/PHASE_TRACKER.md`). Sans installation, depuis la racine du projet, remplacez `python -m edgia_core ...`
> par `PYTHONPATH=src python -m edgia_core ...` ; les tests passent par `./scripts/run_tests.sh`.

## Configuration

```bash
cp .env.example .env
# Générer une clé d'API (24 caractères minimum) et la placer dans EDGIA_API_KEYS :
python -c "import secrets; print(secrets.token_urlsafe(32))"
python -m edgia_core check-config --env-file .env
```

Le code de sortie vaut `0` si le service peut démarrer, `2` sinon (avec la liste des problèmes).

## Lancer le serveur

```bash
PYTHONPATH=src python -m edgia_core serve --env-file .env      # écoute sur 127.0.0.1:8000
curl -s http://127.0.0.1:8000/health
curl -s http://127.0.0.1:8000/v1/chat/completions \
  -H "Authorization: Bearer $EDGIA_API_KEY" -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Bonjour"}]}'
```

Le serveur refuse de démarrer (sans ouvrir de port) si la configuration est invalide. Il ne gère pas TLS : placez-le
derrière un proxy TLS pour tout usage hors de la machine locale.

Pour le mode réel, copiez `configs/model.example.yaml` en `configs/model.yaml`, renseignez les informations
fournies par l'équipe d'entraînement, puis `EDGIA_MODE=real` et `EDGIA_MODEL_DESCRIPTOR=configs/model.yaml`.
Le démarrage est refusé tant que la licence n'est pas marquée comme vérifiée par un humain, que les poids sont
absents ou que les sommes SHA-256 déclarées ne correspondent pas.

## Tests

```bash
./scripts/run_tests.sh
```

Les tests nécessitant un vrai modèle ou un GPU sont séparés (`tests/real_model/`), ignorés par défaut, et **n'ont jamais été exécutés**.

## Organisation

```
src/edgia_core/   config, errors, cli, server, api/, inference/, security/, model/ (registre, chargeur) (+ training/, evaluation/, knowledge/ : à venir)
configs/          exemples sans secrets
scripts/          commandes utilitaires
tests/unit/       tests rapides, sans modèle (config, descripteur, sécurité, moteur de démo, API)
tests/integration/ serveur lancé en processus réel sur la boucle locale
docs/             architecture, dépendances, suivi des phases
models/           emplacement local des poids (ignoré par Git)
```

## Documentation

- [API](docs/API.md)
- [Guide pour l'équipe d'entraînement](docs/GUIDE_SPECIALISTES.md)
- [Modèles candidats](docs/MODELES_CANDIDATS.md)
- [Données et adaptation LoRA](docs/DONNEES.md)
- [Base documentaire](docs/KNOWLEDGE.md)
- [Déploiement](docs/DEPLOIEMENT.md) et [exploitation](docs/EXPLOITATION.md)
- [Évaluation](docs/EVALUATION.md) (suites de cas, comparaison de modèles)
- [Architecture](docs/ARCHITECTURE.md)
- [Dépendances et versions testées](docs/DEPENDANCES.md)
- [Suivi des phases et problèmes restants](docs/PHASE_TRACKER.md)
- [Intégration dans l'application EDG-IA](docs/INTEGRATION.md) · [Contrat OpenAPI](docs/openapi.yaml) · [Bilan vérifié / non vérifié](docs/BILAN.md)

## Limites connues

Aucune capacité (français, anglais, programmation, etc.) n'est garantie : elles dépendront du modèle livré et ne
seront affirmées qu'après validation par les évaluations de la phase 5 exécutées sur le vrai modèle (l'outil existe, mais aucun résultat réel n'existe encore).
