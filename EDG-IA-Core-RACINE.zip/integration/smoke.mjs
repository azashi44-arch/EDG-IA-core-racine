// Essai de bout en bout du client de référence : EDGIA_URL=http://127.0.0.1:8000 EDGIA_CHECK_API_KEY=… node integration/smoke.mjs
import { EdgiaCoreClient, EdgiaCoreError } from "./edgia-core-client.mjs";

const baseUrl = process.env.EDGIA_URL;
const apiKey = process.env.EDGIA_CHECK_API_KEY;
const out = {};

// 1. Par défaut, le serveur de démonstration est REFUSÉ.
const strict = new EdgiaCoreClient({ baseUrl, apiKey });
try {
  await strict.chat([{ role: "user", content: "Bonjour" }], { max_tokens: 8 });
  out.demoRefused = false;
} catch (error) {
  out.demoRefused = error instanceof EdgiaCoreError && error.code === "demo_model_refused";
}

// 2. Avec allowDemo (développement), réponse complète et flux.
const client = new EdgiaCoreClient({ baseUrl, apiKey, allowDemo: true });
const full = await client.chat([{ role: "user", content: "Bonjour" }], { max_tokens: 16, temperature: 0, champInconnu: "ignoré par le client" });
out.chat = { hasText: typeof full.text === "string" && full.text.length > 0, demo: full.edgia.demo, requestId: Boolean(full.requestId), usage: full.usage.total_tokens > 0, sources: full.sources };

const deltas = [];
let done = null;
for await (const event of client.chatStream([{ role: "user", content: "Bonjour" }], { max_tokens: 16 })) {
  if (event.type === "delta") deltas.push(event.text);
  else done = event;
}
out.stream = { deltas: deltas.length, joinedMatches: deltas.join("") === full.text, finish: done?.finishReason, fullFinish: full.finishReason };

// 3. Erreurs : code de l'API conservé, contenu jamais recopié.
try {
  await client.chat([{ role: "user", content: "x" }], { model: "modele-inexistant" });
} catch (error) {
  out.unknownModel = { code: error.code, status: error.status, requestId: Boolean(error.requestId) };
}
try {
  await new EdgiaCoreClient({ baseUrl, apiKey: "z".repeat(30) }).models();
} catch (error) {
  out.badKey = { code: error.code, status: error.status };
}
try {
  await new EdgiaCoreClient({ baseUrl: "http://127.0.0.1:1", apiKey, timeoutMs: 2000 }).ready();
} catch (error) {
  out.unreachable = error.code;
}
console.log(JSON.stringify(out));
