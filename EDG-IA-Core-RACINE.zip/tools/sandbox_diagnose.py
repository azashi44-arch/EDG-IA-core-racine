#!/usr/bin/env python3
"""Diagnostic autonome du bac à sable d'EDG-IA Core (bibliothèque standard uniquement, ne modifie rien).

Usage (depuis la racine du projet, avec le MÊME Python que celui des tests) :
    python3 sandbox_diagnose.py            # rapport lisible
    python3 sandbox_diagnose.py --json     # rapport JSON
    python3 sandbox_diagnose.py --python /chemin/vers/python

Il reproduit le lancement du bac à sable (`python -I`, environnement vidé, limites système, setsid) MAIS étape par étape :
sans limite, puis chaque limite seule, puis toutes ensemble, en capturant le code de sortie et la sortie d'erreur que le
bac à sable jette (stderr=DEVNULL). Il n'exécute AUCUN code de modèle : seulement du code fixe et inoffensif.
Il ne prouve rien tant qu'il n'est pas exécuté sur la machine où les échecs apparaissent.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import signal
import subprocess
import sys
import tempfile
from pathlib import Path

try:
    import resource
except ImportError:  # Windows
    resource = None  # type: ignore[assignment]

MB = 1024 * 1024
# Valeurs identiques à SandboxLimits() dans src/edgia_core/evaluation/sandbox.py
LIMITS = {"AS": 512 * MB, "CPU": 5, "FSIZE": 1 * MB, "CORE": 0, "NPROC": 16}
TRIVIAL = "import sys\nsys.stdout.write('OK')"


def _apply(limits: dict[str, int], setsid: bool, report_fd: int):
    """Fonction exécutée dans le processus fils : applique les limites une par une et note celle qui échoue."""

    def run() -> None:
        steps = []
        for name, value in limits.items():
            attr = "RLIMIT_" + name
            if hasattr(resource, attr):
                steps.append((attr, lambda a=attr, v=value: resource.setrlimit(getattr(resource, a), (v, v))))
        if setsid:
            steps.append(("setsid", os.setsid))
        for label, step in steps:
            try:
                step()
            except BaseException as exc:  # noqa: BLE001
                os.write(report_fd, f"{label}: {type(exc).__name__}: {exc}".encode())
                raise

    return run


def stage(name: str, python: str, code: str = TRIVIAL, *, limits: dict[str, int] | None = None, setsid: bool = False,
          clean_env: bool = True, stdin: str | None = None, timeout: float = 20.0) -> dict:
    limits = limits or {}
    with tempfile.TemporaryDirectory(prefix="edgia-diag-") as workdir:
        env = (
            {"PATH": "/usr/bin:/bin", "HOME": workdir, "TMPDIR": workdir, "PYTHONDONTWRITEBYTECODE": "1"}
            if clean_env else dict(os.environ)
        )
        read_fd, write_fd = os.pipe()
        result: dict = {"stage": name, "limits": {k: v for k, v in limits.items()}, "setsid": setsid, "clean_env": clean_env}
        try:
            process = subprocess.Popen(
                [python, "-I", "-c", code],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                cwd=workdir, env=env, pass_fds=(write_fd,),
                preexec_fn=_apply(limits, setsid, write_fd) if (limits or setsid) and resource else None,
            )
            try:
                out, err = process.communicate((stdin or "").encode(), timeout=timeout)
                code_out = process.returncode
            except subprocess.TimeoutExpired:
                process.kill()
                out, err = process.communicate()
                code_out = None
                result["timeout"] = True
            result.update(
                exit_code=code_out,
                signal=signal.Signals(-code_out).name if isinstance(code_out, int) and code_out < 0 else None,
                stdout=out.decode("utf-8", "replace")[-200:],
                stderr_tail=err.decode("utf-8", "replace")[-600:],
                ok=(code_out == 0 and out.decode("utf-8", "replace").strip().endswith("OK")),
            )
        except BaseException as exc:  # noqa: BLE001 - échec avant ou pendant le lancement
            result.update(ok=False, exit_code=None, launch_exception=f"{type(exc).__name__}: {exc}")
        finally:
            os.close(write_fd)
            try:
                child_report = os.read(read_fd, 400).decode("utf-8", "replace")
            finally:
                os.close(read_fd)
            if child_report:
                result["limit_step_failed_in_child"] = child_report
        return result


def environment(python: str) -> dict:
    info: dict = {
        "platform": platform.platform(), "machine": platform.machine(), "system": platform.system(),
        "python_running_this_script": sys.version.split()[0], "python_tested": python,
        "python_tested_realpath": os.path.realpath(python),
        "uid": os.getuid() if hasattr(os, "getuid") else None,
    }
    try:
        head = Path(os.path.realpath(python)).read_bytes()[:2]
        info["python_is_script_wrapper"] = head == b"#!"
    except OSError as exc:
        info["python_is_script_wrapper"] = f"illisible : {exc}"
    try:
        probe = subprocess.run(
            [python, "-I", "-c",
             "import sys,sysconfig,json;print(json.dumps({'version':sys.version,'prefix':sys.prefix,'base_prefix':sys.base_prefix,"
             "'venv':sys.prefix!=sys.base_prefix,'gil_disabled':sysconfig.get_config_var('Py_GIL_DISABLED'),"
             "'mimalloc':sysconfig.get_config_var('WITH_MIMALLOC'),'pymalloc':sysconfig.get_config_var('WITH_PYMALLOC'),"
             "'executable':sys.executable}))"],
            capture_output=True, text=True, timeout=20,
        )
        try:
            info["python_tested_details"] = json.loads(probe.stdout)
        except ValueError:
            info["python_tested_details"] = {
                "SONDE_NON_JSON(interpréteur sans limite ni environnement vidé)": {
                    "exit_code": probe.returncode, "stdout": probe.stdout[-200:], "stderr": probe.stderr[-400:]}}
    except (OSError, subprocess.SubprocessError) as exc:
        info["python_tested_details"] = {"SONDE_IMPOSSIBLE": f"{type(exc).__name__}: {exc}"}
    if resource:
        info["limits_inherited"] = {
            n: list(resource.getrlimit(getattr(resource, "RLIMIT_" + n))) for n in LIMITS if hasattr(resource, "RLIMIT_" + n)
        }
    proc = Path("/proc")
    if proc.exists():
        uid = os.getuid()
        count = 0
        for entry in proc.iterdir():
            if entry.name.isdigit():
                try:
                    if entry.stat().st_uid == uid:
                        count += 1
                except OSError:
                    pass
        info["processes_of_this_user"] = count
        for label, path in (("kernel", "/proc/version"), ("cgroup_pid1", "/proc/1/cgroup")):
            try:
                info[label] = Path(path).read_text()[:300].strip()
            except OSError:
                pass
        info["in_docker_file"] = Path("/.dockerenv").exists()
        binfmt = Path("/proc/sys/fs/binfmt_misc")
        if binfmt.exists():
            info["binfmt_misc_entries"] = sorted(p.name for p in binfmt.iterdir() if p.name not in ("register", "status"))
    return info


def verdict(stages: list[dict]) -> list[str]:
    by = {s["stage"]: s for s in stages}
    notes: list[str] = []
    if not by["A1 sans limite, environnement hérité"]["ok"]:
        notes.append("ÉCHEC dès A1 (aucune limite, environnement normal) : l'interpréteur testé ne démarre pas du tout ici. "
                     "Le problème n'est PAS le bac à sable : voir stderr_tail de A1.")
        return notes
    if not by["A2 sans limite, environnement vidé (comme le bac à sable)"]["ok"]:
        notes.append("A1 réussit mais A2 échoue : c'est l'ENVIRONNEMENT VIDÉ (PATH=/usr/bin:/bin, pas de LD_LIBRARY_PATH, pas de "
                     "variables d'environnement virtuel) qui empêche l'interpréteur de démarrer (script intermédiaire pyenv/uv/conda/venv, "
                     "bibliothèque introuvable). Cause hors limites système.")
        return notes
    single = [s for s in stages if s["stage"].startswith("B")]
    culprits = [s["stage"] for s in single if not s["ok"]]
    if culprits:
        notes.append("Limites ou appels ISOLÉS qui font échouer le lancement : " + "; ".join(culprits))
    if not by["C tout ensemble (comme le bac à sable)"]["ok"] and not culprits:
        notes.append("Chaque élément réussit seul mais l'ensemble échoue : interaction entre limites (voir stage C).")
    if by["C tout ensemble (comme le bac à sable)"]["ok"]:
        notes.append("Le lancement avec TOUTES les limites réussit ici : les échecs du bac à sable ne sont pas reproduits par cet "
                     "outil dans cet environnement.")
    bis = [s for s in stages if s["stage"].startswith("D")]
    if bis:
        first_ok = next((s for s in bis if s["ok"]), None)
        if first_ok is None:
            notes.append("RLIMIT_AS : aucune valeur testée (jusqu'à 4 Go) ne permet le démarrage.")
        else:
            notes.append(f"RLIMIT_AS : démarrage réussi à partir de {first_ok['limits']['AS'] // MB} Mo (valeur du bac à sable : 256 Mo).")
    return notes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    if resource is None:
        print("Module `resource` absent (Windows ?) : le bac à sable est indisponible sur cette plateforme. Rien à diagnostiquer.")
        return 0
    py = args.python
    stages = [
        stage("A1 sans limite, environnement hérité", py, clean_env=False),
        stage("A2 sans limite, environnement vidé (comme le bac à sable)", py),
    ]
    for name, value in LIMITS.items():
        stages.append(stage(f"B limite seule : RLIMIT_{name}={value}", py, limits={name: value}))
    stages.append(stage("B appel seul : os.setsid()", py, setsid=True))
    stages.append(stage("C tout ensemble (comme le bac à sable)", py, limits=LIMITS, setsid=True))
    for mb in (16, 32, 64, 128, 256, 512, 1024, 2048, 4096):
        stages.append(stage(f"D RLIMIT_AS seul = {mb} Mo", py, limits={"AS": mb * MB}))
        if stages[-1]["ok"]:
            break
    report = {"environment": environment(py), "stages": stages, "verdict": verdict(stages)}
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print("== ENVIRONNEMENT")
        print(json.dumps(report["environment"], indent=2, ensure_ascii=False))
        print("\n== ÉTAPES (ok = l'interpréteur a démarré et répondu OK)")
        for s in stages:
            extra = ""
            for key in ("exit_code", "signal", "launch_exception", "limit_step_failed_in_child", "timeout"):
                if s.get(key) not in (None, ""):
                    extra += f" | {key}={s[key]}"
            print(f"[{'OK ' if s['ok'] else 'ÉCHEC'}] {s['stage']}{extra}")
            if not s["ok"] and s.get("stderr_tail"):
                print("      stderr :", s["stderr_tail"].strip().replace("\n", "\n             "))
        print("\n== LECTURE")
        for line in report["verdict"]:
            print("-", line)
        print("\nCe rapport décrit ce qui a été OBSERVÉ ici ; envoyez-le en entier avec la commande exacte utilisée.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
