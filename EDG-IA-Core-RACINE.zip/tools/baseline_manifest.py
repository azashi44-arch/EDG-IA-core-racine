#!/usr/bin/env python3
"""Génère un manifeste SHA-256 (« <sha256>  <chemin relatif> ») de tous les fichiers d'un dossier.

Usage : python tools/baseline_manifest.py <dossier> [--out fichier]
Le manifeste de référence de L0 (`native_baseline/BASELINE_SHA256.txt`) a été calculé sur l'extraction propre du ZIP d'origine
(EDG-IA-Core_phase9_custom_transformer.zip) AVANT tout travail : 230 fichiers.
"""

from __future__ import annotations

import argparse
import hashlib
import os
import sys
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def walk(root: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for current, dirs, files in os.walk(root):
        dirs.sort()
        for name in sorted(files):
            path = Path(current) / name
            out[path.relative_to(root).as_posix()] = sha256_file(path)
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root")
    parser.add_argument("--out")
    args = parser.parse_args()
    manifest = walk(Path(args.root))
    text = "".join(f"{digest}  {rel}\n" for rel, digest in sorted(manifest.items()))
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
