# EDG-IA Core — L0 : fondation du moteur natif

Ce dossier est le projet **EDG-IA Core d'origine (phase 9) + l'ajout `edgia_core.native`** : le début de votre propre modèle de langage
(architecture, tokenizer, pipeline de données, pipeline d'entraînement), initialisé aléatoirement, **sans aucun poids externe**.

> **L0 n'est PAS une IA.** Aucun modèle n'a été entraîné. Un modèle XS (25 M de paramètres) entraîné sur des données ouvertes ne rivalisera
> pas avec les IA actuelles : L0 est une fondation technique vérifiable.

## Où en est-on (honnêtement)
| Élément | Codé | Testé (exécuté) | Fonctionnel |
|---|---|---|---|
| Configurations XS/S/M/L/smoke, comptage exact des paramètres | oui | **oui** | oui |
| Tokenizer BPE maison (jetons verrouillés, anti-injection, flux UTF-8) | oui | **oui** (fuzz 20 000 chaînes) | oui (smoke) ; production : besoin de données |
| Format safetensors (lecture défensive/écriture, sans pickle) | oui | **oui** (round-trip ; croisé officiel : non) | oui |
| Pipeline de données (registre, portes 1/2, doublons, découpage, shards, manifeste, chargeur) | oui | **oui** | oui (sur données synthétiques) ; données réelles à fournir |
| Checkpoints atomiques + reprise (mécanique) | oui | **oui** (mini-entraîneur NumPy ; bit à bit niveau A) | oui |
| Référence NumPy du modèle (RMSNorm, RoPE, GQA, SwiGLU, cache KV) | oui | **oui** | oui (oracle des tests) |
| Boucle de génération, échantillonnage, masque de sortie | oui | **oui** (avec la référence NumPy) | oui |
| Export + vérification + garde-fous (statut, distribution) | oui | **oui** | oui |
| CLI | oui | **oui** (hors PyTorch) | oui |
| **Modèle PyTorch** (`model.py`) | oui | **NON** (PyTorch absent ici) | **inconnu** |
| **Boucle d'entraînement PyTorch** (`train/loop.py`) | oui | **NON** | **inconnu** |
| **Backend Core natif** (`backend.py`) + patches | oui | **NON** (hash et syntaxe seulement) | **inconnu** |
| Entraînement réel, GPU, données réelles | non | — | à faire (besoin de données, GPU, validation juridique) |

Résultats réels : `docs/native/RESULTATS_TESTS.md` (177 tests : 156 réussis, 21 sautés faute de PyTorch/pydantic/safetensors, 0 échec ; 32 mutants sur 32 tués).

## Démarrage rapide
```bash
PYTHONPATH=src python -m edgia_core.native info
PYTHONPATH=src python tools/run_native_tests.py
python tools/verify_untouched.py --root .
```
Guides : `docs/native/` — ARCHITECTURE, INSTALLATION, CONFIGURATION, TESTS, ENTRAINEMENT, DONNEES, PROBLEMES, PROCHAINES_ETAPES, AUDIT_AVANT_APRES,
FICHIERS_AJOUTES_MODIFIES, RESULTATS_TESTS, MANIFESTE_VERIFICATION. Le `README.md` d'origine de Core est inchangé.

## Protection du projet existant
230 fichiers d'origine : **227 inchangés** (dont tout le prototype phase 9) et **3 modifiés par patches minimaux et réversibles**
(`descriptor.py`, `loader.py`, `pyproject.toml`) ; originaux dans `native_baseline/originals/`, patches dans `patches/`.
Preuve : `python tools/verify_untouched.py` (référence `native_baseline/BASELINE_SHA256.txt`).
