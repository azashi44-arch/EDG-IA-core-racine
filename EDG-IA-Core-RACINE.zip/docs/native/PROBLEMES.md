# Problèmes résolus et problèmes restants

## A. Erreurs identifiées et corrigées (erreur → cause → correction → test)

| N° | Erreur | Cause | Correction | Test qui le démontre |
|---|---|---|---|---|
| 1 | Perte initiale attendue fausse (10,40 ± 0,15) dans la spéc. v1.0 | variance des logits (σ≈0,39) et alignement des embeddings liés ignorés | intervalle [10,3 ; 10,8], estimation ≈ 10,5 | `test_m2_initial_loss_xs…` : **mesuré 10,4969** sur XS (référence NumPy) |
| 2 | Tailles S, M, L approximatives (110 M, 330 M, 1 Md) | calcul à la main sans GQA/SwiGLU exacts | formule unique ; 100 682 496 / 299 418 624 / 953 239 552 | `test_formula_equals_sum_of_shapes`, `test_spec_table_values` |
| 3 | « Fenêtres sans chevauchement » (v1.0) | stride 1024, longueur 1025 → 1 token partagé | chaque token prédit exactement une fois ; fenêtres jamais à cheval sur deux fragments | `test_s8_every_token_predicted_once…`, mutant « pas de fenêtre faux » tué |
| 4 | Compteur de pas d'Adam absent des checkpoints (v1.0) | omission | sauvegardé (`adam_steps`) et restauré | `test_s4_resume_is_bit_exact…` + `test_s4b…` (l'oubli CHANGE le résultat) |
| 5 | `is_causal=True` avec cache KV | alignement haut-gauche du masque | masque explicite quand le cache est non vide | `test_m9_cache_equivalence_all_chunkings` (NumPy) ; version PyTorch : `test_torch_model` (non exécuté) |
| 6 | Jetons spéciaux interprétés dans le texte par les bibliothèques courantes | comportement par défaut des tokenizers | tokenizer maison : texte ≠ structure ; gabarit au niveau des identifiants ; masque de sortie | fuzz 20 000 chaînes `test_t3…`, `test_t4…`, `test_t11…`, mutants tués |
| 7 | Un décodeur UTF-8 naïf coupe les caractères entre deux tokens | tokens d'octets | décodeur incrémental à tampon | `test_t10_every_split_point`, `test_f3_utf8_streaming_through_the_loop` |
| 8 | MinHash (seuil 0,8) ne détecte PAS 5 % de mots modifiés | 5 % de mots ⇒ ~22 % d'empreintes de 5 mots changées | contrôle de fuite par séquences de 13 mots en second filet | **mesuré** : rappel 0,0 à 5 % ; `test_leak_filter_is_the_second_net…` |
| 9 | Vocabulaire de 32 768 impossible à entraîner sur un petit corpus | trop peu de paires fréquentes | profil `smoke` (1 024) distinct, refus de mélange ; erreur explicite si corpus insuffisant | `test_t14…`, `test_corpus_too_small…` |
| 10 | Tests trop stricts/erronés écrits pendant L0 | égalité exacte entre formes différentes (BLAS) ; départage d'égalité de logits ; répertoire temporaire fermé ; faux positif `model.eval()` du scanner ; `.pyc`/`.pytest_cache` de la référence écartés d'une copie | corrigés (tolérance, attente juste, portée du `with`, scanner AST, copie fidèle) | suite complète verte ; chaque correction est visible dans l'historique des tests |
| 11 | Mutant « K non tourné dans le cache » survivait | aucun test NumPy ne vérifiait la rotation des K stockés | ajout d'un calcul indépendant des K de la couche 0 | `test_layer0_cached_keys_are_the_rotated_projections…` ; mutant tué |
| 12 | Dépendances `tokenizers` et `safetensors` prévues par la spéc. | — | **décision L0** : tokenizer BPE et format safetensors implémentés dans le paquet (aucune dépendance de plus, pas de comportement implicite) | tests T1–T14, `test_safetensors_io` ; compatibilité officielle : test croisé SAUTÉ (voir C) |

## B. Mutation (erreurs volontaires injectées dans une copie)
**32 mutants, 32 tués, 0 survivant** (`docs/native/resultats/mutation.json`). Limite : ils portent sur le code exécutable ici (référence NumPy, tokenizer, données,
checkpoints, génération, export) ; le modèle PyTorch n'a PAS été muté faute de PyTorch.

## C. Problèmes restants (non résolus) — à lire
1. **Code PyTorch non exécuté** : `model.py`, `train/loop.py`, `backend.py`. Écrits avec soin, logique vérifiée par la référence NumPy, mais JAMAIS lancés. Risque élevé de petites erreurs d'API. Tests prêts : `test_torch_model`, `test_torch_training`.
2. **Intégration Core non exécutée** : pydantic/starlette absents ici ; la suite existante de Core (`tests/unit`) n'a PAS été lancée. Seule l'intégrité des fichiers est prouvée (hash).
3. **Test croisé avec la bibliothèque `safetensors` officielle non exécuté** : le format est construit d'après la spécification publique.
4. **Aucun entraînement, aucune donnée réelle, aucun tokenizer de production** ; le BPE en Python pur n'a pas été mesuré à 32 384 fusions sur de gros corpus (probablement lent : prévoir un entraîneur plus rapide produisant la MÊME liste de fusions).
5. **Windows non testé.** Versions `torch>=2.9,<3` : bornes non testées.
6. **Contexte de 1 024 tokens** : Chat envoie jusqu'à 40 messages et `max_tokens` jusqu'à 2 048 (Core refuse > 512 par défaut). Le backend lève une erreur claire (« conversation trop longue »), mais la gestion côté Chat (troncature par budget) n'est pas faite ; non modifié par L0.
7. **Quasi-doublons sémantiques** (traductions, paraphrases) non détectés ; seuils provisoires (Jaccard 0,8 ; 13-grammes 10 %) ; détection de langue heuristique ; données personnelles par motifs seulement.
8. **Questions juridiques** (licences et poids, usage interne vs API vs distribution, RGPD) : le code impose les validations, il ne les remplace pas.
9. **Non-déterminisme GPU** : pas de reprise bit à bit sur GPU (niveau B) ; mesure du bruit de base à faire au pilote.
10. **Tests et code ont les mêmes auteurs** : une erreur conceptuelle commune passerait. Une relecture indépendante des formules (docstring de `reference/numpy_model.py`) reste recommandée.
11. **Mapping d'erreurs du backend** : `EngineError` pour un prompt trop long ; le code HTTP final dépend de Core (non vérifié).
