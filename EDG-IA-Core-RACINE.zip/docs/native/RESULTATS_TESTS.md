# Résultats RÉELS des tests (exécutés lors de la livraison L0)

Environnement : Linux, Python 3.12.3, NumPy 2.5.4, PyYAML 6.0.3. **PyTorch, pydantic, starlette, safetensors, tokenizers, pytest : absents** (pas de réseau).

## Suite `tests/native` : 177 tests — **156 réussis, 21 sautés, 0 échecs, 0 erreurs** (35.6 s)

Tests SAUTÉS (ils n'ont PAS été exécutés ; sauté ≠ réussi) :

- **test_core_integration** (1 tests) — pydantic absent : `test_backend_implements_the_abstract_interface`
- **test_core_integration** (3 tests) — pydantic absent : intégration Core non exécutée : `test_build_engine_dispatch_is_lazy_and_other_runtimes_unchanged`, `test_check_model_accepts_a_real_export_directory`, `test_new_runtime_and_format_are_accepted_and_consistent`
- **test_safetensors_official** (1 tests) — bibliothèque officielle `safetensors` absente : compatibilité croisée NON vérifiée : `test_we_write_official_reads_and_vice_versa`
- **test_torch_model** (11 tests) — PyTorch absent : tests du modèle PyTorch non exécutés : `test_initial_loss_matches_the_numpy_measurement_interval`, `test_m11_overfits_one_batch`, `test_m12_loss_shift_and_value`, `test_m15_tied_weights_no_lm_head_and_strict_loading`, `test_m17_logits_match_numpy_reference`, `test_m1_param_count_including_xs_on_meta_device`, `test_m4_rope_matches_numpy`, `test_m5_causality`, `test_m6_gqa_mapping_matches_numpy`, `test_m9_kv_cache_equals_full_forward_for_every_chunking`, `test_tied_embedding_receives_gradient_from_the_output_path`
- **test_torch_training** (4 tests) — PyTorch absent : entraînement non exécuté : `test_f1_smoke_chain_loss_decreases_and_exports`, `test_resume_refused_if_config_changes`, `test_s10_nan_guard_stops_without_checkpoint`, `test_s4_resume_level_a_is_bit_exact`
- **test_torch_training** (1 tests) — PyTorch ou dépendances de Core (pydantic) absents : intégration non exécutée : `test_f2_untrained_refused_then_served_with_explicit_override`

## Tests de mutation : 32 mutants, **32 tués**, survivants : aucun
(détail : `docs/native/resultats/mutation.json`).

## Mesures réelles relevées
- Perte initiale XS (référence NumPy, 3 séquences aléatoires) : **10,4969** (ln 32 768 = 10,3972 ; intervalle visé [10,3 ; 10,8]).
- Octets par token (tokenizer smoke, texte SYNTHÉTIQUE) : **4,06** (seuil provisoire 3,0) — non représentatif du français réel.
- Rappel de détection des quasi-doublons (MinHash, seuil 0,8) : **1,0** (copie+ajout), **1,0** (1 % de mots modifiés), **0,0** (5 % de mots modifiés ; le contrôle de fuite 13-grammes prend le relais).
- Paramètres : XS 25 172 352 ; S 100 682 496 ; M 299 418 624 ; L 953 239 552 (formule = somme des formes = allocation réelle NumPy pour XS).
- Entraînement du tokenizer smoke (640 fusions, ~1 Mo synthétique) : ≈ 0,4 s.

## Non exécuté (à lancer chez vous)
- `test_torch_model`, `test_torch_training`, `test_core_integration`, `test_safetensors_official` ; suite existante de Core (`python -m pytest tests/unit`).

## Sortie complète
`docs/native/resultats/tests_verbose.txt`, `docs/native/resultats/tests.json`, `docs/native/resultats/verify_untouched.md`.
