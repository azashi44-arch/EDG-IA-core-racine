# Manifeste SHA-256 et rapport de vérification

## Référence (calculée AVANT tout travail)
- Source : extraction propre de `EDG-IA-Core_phase9_custom_transformer.zip` (fichiers originaux, y compris 96 `.pyc` Python 3.13 et `.pytest_cache`).
- Fichier : `native_baseline/BASELINE_SHA256.txt` — **230 fichiers** ; son propre SHA-256 : `a9861fef62ee72fb539e3913a1fa4dc168a309f99fce82a53359cacb2e0a1cdb`.
- Déclaration des seules modifications autorisées : `native_baseline/PATCHED_FILES.json` (3 fichiers, empreintes avant/après, copies d'origine, patches).

## Vérification (exécutée)
- Fichiers de référence : 230
- Inchangés : 227
- Modifiés et déclarés (patches) : 3 → pyproject.toml, src/edgia_core/model/descriptor.py, src/edgia_core/model/loader.py
- Modifiés NON déclarés : 0 []
- Supprimés : 0 []
- Ajoutés (dossiers autorisés) : 85
- Ajoutés hors dossiers autorisés : 0 []
- Artefacts d'exécution ignorés (__pycache__, *.pyc) : 0
- Patches non réversibles : []

**Résultat : CONFORME**

## Reproduire
```bash
python tools/verify_untouched.py --root . --report rapport.md      # code de sortie 0 = conforme
python tools/baseline_manifest.py . --out mon_manifeste.txt        # recalcule tous les SHA-256
```
`native_baseline/FINAL_SHA256.txt` liste le SHA-256 de TOUS les fichiers de cette livraison (hors lui-même) :
`cd <projet> && sha256sum -c native_baseline/FINAL_SHA256.txt`.

## Garanties et limites
- Prouvé : aucun fichier d'origine supprimé ; 227 inchangés (dont tout `custom_model/`) ; 3 modifiés exactement comme déclaré ; copies d'origine et patches réversibles (test `test_reverse_patches_restore_the_originals`).
- Non prouvé : le comportement de Core après patches (sa suite de tests n'a pas pu être exécutée ici : pydantic/starlette absents).
