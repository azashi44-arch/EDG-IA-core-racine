# Guide de configuration et d'exécution

Toutes les commandes : `python -m edgia_core.native <commande>` (depuis le dossier du projet, avec `PYTHONPATH=src` ou après `pip install -e .`).
Aucune commande ne télécharge quoi que ce soit.

| Commande | Rôle | PyTorch |
|---|---|---|
| `info` | tailles, empreintes des préréglages (xs, s, m, l, smoke) | non |
| `selfcheck --lock configs/native/special_tokens.lock.json` | formules + verrou | non |
| `sources-check --registry R` | porte 1 sur un registre (sortie 0 si toutes admises, 2 sinon) | non |
| `data-build --registry R --input a.jsonl … --out DS --profile smoke|production` | construit le jeu de données | non |
| `data-verify DS` | recalcule tous les SHA-256 | non |
| `train-plan --model xs` | affiche ce que ferait un entraînement (rien n'est lancé) | non |
| `train-run --model smoke --data DS --out RUN` | entraînement (smoke libre ; autre profil : `--confirm-training`) | oui |
| `ckpt-verify RUN/ckpt` | vérifie les checkpoints | non |
| `export --model xs --ckpt-dir RUN/ckpt --data DS --out EXP --status pilot` | exporte pour Core | non |
| `export-random --model smoke --tokenizer DS/tokenizer --out EXP` | export à poids ALÉATOIRES (essais d'intégration) | non |
| `export-verify EXP` | contrôle complet d'un export | non |

Configurations : `configs/native/xs.yaml` (référence), `smoke.yaml` (tests techniques), `sources.example.yaml` (registre : AUCUNE source approuvée),
`model.native.example.yaml` (descripteur Core).

## Servir un export avec Core
1. Copier `configs/native/model.native.example.yaml`, adapter les chemins, **faire valider la licence** (`reviewed: true`).
2. Un export `random_init` / `smoke_test` est REFUSÉ au démarrage. Pour un essai purement technique : `EDGIA_ALLOW_UNTRAINED=true` (jamais en production).
3. Périphérique : `EDGIA_NATIVE_DEVICE=cpu|cuda|auto` (défaut `cpu`).
4. Limites actuelles : contexte de 1024 tokens ; Chat envoie jusqu'à 40 messages sans budget de tokens (voir `PROBLEMES.md`).
