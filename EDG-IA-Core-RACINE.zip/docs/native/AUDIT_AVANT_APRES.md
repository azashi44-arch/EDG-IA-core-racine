# Rapport d'audit avant / après

## Avant (ZIP `EDG-IA-Core_phase9_custom_transformer.zip`)
- 230 fichiers (3,6 Mo décompressé) ; API : `/ready`, `/v1/models`, `/v1/chat/completions` (JSON + SSE), `/v1/knowledge/search` ; authentification par clé ; limites, délais, concurrence ; registre de versions ; `doctor`, `backup`.
- Un seul runtime de modèle réel : `transformers` (`hf_backend.py`) — exige des poids préentraînés externes ; aucun poids dans le ZIP ⇒ seul le mode démo était exécutable.
- Prototype phase 9 `custom_model/` : Transformer d'octets (≈ 0,8 M de paramètres, contexte 128, positions apprises, LayerNorm, GELU, attention `nn.MultiheadAttention`, sans cache KV, fenêtre glissante au pas de 1, `torch.load(weights_only=False)`), non branché à l'API.
- Présents dans l'archive : 96 fichiers `.pyc` (Python 3.13) et un dossier `.pytest_cache` : conservés tels quels.
- Environnement de ce développement : pas de réseau, pas de PyTorch/pydantic/starlette : la suite existante de Core n'a donc PAS pu être exécutée (avant comme après).

## Après (L0)
| Mesure | Valeur |
|---|---|
| Fichiers d'origine inchangés | 227 / 230 |
| Fichiers d'origine modifiés (patches minimaux, réversibles) | 3 |
| Fichiers d'origine supprimés | 0 |
| Fichiers ajoutés (hors `__pycache__`) | 86 |
| Code du paquet `native` | 35 fichiers, 3454 lignes |
| Tests `tests/native` | 21 fichiers, 2691 lignes — 177 tests |
| Outils (`tools/`) | 4 fichiers, 310 lignes |
| Documentation (`docs/native/`) | 9 fichiers |
| Nouveau runtime Core | `edgia_native` (additif ; import paresseux ; démo et Transformers inchangés) |

Ce qui est NOUVEAU : architecture native (RMSNorm, RoPE, GQA, SwiGLU, cache KV, embeddings liés), tokenizer BPE maison, pipeline de données avec portes de licence,
checkpoints atomiques et reprise, export sécurisé avec statuts, backend Core, CLI, 177 tests + 32 mutants + référence NumPy, outils de preuve d'intégrité.
Ce qui n'a PAS changé : l'API, l'authentification, le streaming SSE, le mode démo, le prototype phase 9, Chat.
