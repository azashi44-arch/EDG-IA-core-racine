# Guide d'installation des dépendances

Python 3.11 à 3.13 (Core l'exige ; 3.12 ou 3.13 conseillé).

## Sans PyTorch (outils, données, tokenizer, tests NumPy)
```bash
pip install -e .            # dépendances de Core (pydantic, starlette, …)
pip install numpy pyyaml    # numpy ≥ 1.26 (déjà requis par les outils natifs)
python tools/run_native_tests.py
```
Les modules `native` sauf `model.py`, `train/loop.py` et `backend.py` n'exigent que NumPy et PyYAML.

## Avec PyTorch (modèle, entraînement, backend)
```bash
pip install -e ".[native]"      # torch>=2.9,<3 ; numpy>=1.26,<3 — BORNES DE DÉPART NON TESTÉES
```
Installez la version de `torch` adaptée à vos pilotes (CPU ou CUDA) depuis la page officielle de PyTorch, puis **figez** les versions
après un premier lancement réussi (`pip freeze > requirements-native.lock`). Une version stable récente que nous avons relevée est la 2.14.x ;
la 2.15 était annoncée pour fin octobre 2026 : à confirmer à l'installation.

## Ce qui n'est PAS requis
`transformers`, `peft`, `tokenizers`, `safetensors`, `datasets` : le tokenizer BPE et le format safetensors sont implémentés dans le paquet
(décision L0 : zéro dépendance de plus, aucun comportement implicite de bibliothèque sur les jetons spéciaux). Option : installer `safetensors`
pour exécuter le test croisé `test_safetensors_official.py`.

## Windows
`torch.compile`/Triton et NCCL sont limités : inutiles pour XS (désactivés). Aucun test n'a été exécuté sous Windows lors de L0.
