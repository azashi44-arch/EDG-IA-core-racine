# Données, licences et provenance

- **Classes** : A (domaine public/CC0), B (licences à obligations, chacune séparée : CC-BY 4.0, Licence Ouverte 2.0, MIT, BSD, Apache-2.0), C (copyleft/partage à l'identique : exclue sauf décision juridique écrite),
  D (restrictions : exclue), E (inconnue : bloquée). Aucune équivalence automatique.
- **Porte 1** (admission) : dossier complet + validateur humain ; classe B : avis écrit sur l'usage en entraînement ; confiance déléguée à un éditeur de jeu de données : audit d'un échantillon.
- **Porte 2** (distribution des poids) : second avis écrit par source ; `distribution_cleared` faux par défaut.
- **Ce module ne rend aucun avis juridique.** Questions à faire trancher : usage interne vs service par API vs remise des poids ; obligations d'attribution sur des poids ; RGPD.
- **Doublons** : exacts (`doc_id`), quasi-doublons MinHash (seuil 0,8 provisoire). **Mesuré** : rappel 1,0 pour copie+ajout et 1 % de mots modifiés, **0,0 pour 5 % de mots modifiés** → le contrôle de fuite par séquences de 13 mots est le second filet (testé).
- **Découpage** par groupe d'œuvres ; trois jeux ; `val` jamais utilisée pour le tokenizer ni le modèle (imposé par le code et testé).
- **Limites** : traductions/paraphrases non détectées ; seuils provisoires ; détection de langue heuristique ; retrait des données personnelles par motifs (pas une garantie d'anonymisation) ; MinHash en Python pur : lent à grande échelle.
- **Traçabilité** : index document → fragment (`*.index.jsonl`), `dataset_manifest.json` (SHA-256), `DATA_CARD.md`, `lineage.json` dans les exports.
