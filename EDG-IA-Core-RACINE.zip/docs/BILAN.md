# Bilan : ce qui est vérifié et ce qui ne l'est pas

## Vérifié (exécuté dans le bac à sable, Python 3.13, tests `unittest` en `-W error`)
- Configuration, registre de modèles, refus de démarrer en mode réel si fichiers absents ou invalides.
- Serveur Starlette : authentification, limites, flux SSE, erreurs, journaux sans contenu (moteur de **démonstration**).
- Évaluations : 16 types de vérifications, rapports, comparaison, bac à sable de code (non une frontière de sécurité).
- Préparation de données, plan d'entraînement qui refuse au moindre doute.
- Base de connaissances SQLite FTS5 (lexicale).
- `doctor`, sauvegarde SQLite avec vérification.
- Contrat HTTP : `contract-check` 10/10 sur le serveur de démonstration ; cohérence OpenAPI ↔ code ; client Node 22.

## NON vérifié
- **Aucun modèle entraîné n'existe ici** : aucune qualité de réponse n'est mesurée.
- Chargement d'un vrai modèle (torch/transformers non installés) ; boucle LoRA jamais exécutée.
- Docker, compose, systemd, Caddy, nginx : écrits, jamais lancés.
- Versions de dépendances non figées ; Python 3.11/3.12 non testés ; lecture PDF (`pypdf`) non testée.
- Choix du modèle de base non fait (licence Gemma contradictoire à clarifier).
- Chargeur sans quantification ni multi-GPU : un modèle 27–32 B en 16 bits demande ≈ 54–64 Go de poids, donc un GPU de 80 Go (calcul, pas mesure).
- Recherche lexicale seulement ; mitigation d'injection de prompt non garantie.
- Intégration réelle avec l'application EDG-IA : code de l'application non vu.

## Liste de premier lancement (machine avec réseau et GPU)
1. Environnement propre : installer, lancer les tests, **figer les versions**.
2. Python 3.11 et 3.12 : relancer les tests.
3. Test de modèle réel (`tests/real_model`) sur un petit modèle puis sur le candidat.
4. Boucle LoRA sur un très petit modèle, avec `--confirm-training`.
5. `docker build` et `compose up`, puis `contract-check --expect-real`.
6. Suite d'évaluation sur le modèle de base, puis comparaison avec le modèle adapté + relecture humaine.
7. Mesure réelle mémoire/latence ; décider quantification ou GPU 80 Go.
8. Déploiement ombre → canari → général.
