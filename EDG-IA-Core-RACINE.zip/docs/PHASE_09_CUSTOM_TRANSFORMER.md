# Phase 9 — EDG-IA Custom Transformer Engine

## Objectif
Ajouter une première architecture Transformer decoder-only écrite dans EDG-IA Core,
avec tokeniseur byte-level, corpus texte, boucle d'entraînement causale et checkpoints.

## Contenu
- `src/edgia_core/custom_model/tokenizer.py`: encode/decode UTF-8 en IDs octets (0..255).
- `transformer.py`: embeddings tokens/positions, blocs attention causale + MLP, logits LM et génération.
- `dataset.py`: charge un fichier `.txt` ou un dossier récursif `.txt` en séquences décalées.
- `train.py`: entraînement PyTorch, AdamW, clipping, logs, sauvegarde périodique et reprise.
- `configs/model/edgia_transformer_small.json`: paramètres de démarrage.

## Installation (Windows PowerShell)
Depuis la racine du projet :
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[ml,dev]"
```

## Préparer le corpus
Créer `corpus/` puis y placer des fichiers `.txt` dont tu as le droit d'utiliser le contenu.
Le prototype exige au moins `context_length + 1` octets. Pour une première vérification,
choisir `--context 64` et un corpus plus long que 65 octets.

## Lancer une expérience de test
```powershell
python -m edgia_core.custom_model.train --data ./corpus --context 64 --d-model 64 --heads 4 --layers 2 --batch-size 2 --steps 20 --save-every 10
```

## Reprendre
```powershell
python -m edgia_core.custom_model.train --data ./corpus --output ./artifacts/edgia-small --context 64 --d-model 64 --heads 4 --layers 2 --batch-size 2 --steps 100 --resume ./artifacts/edgia-small/checkpoint-20.pt
```

## Limites et avertissements
- Ce modèle commence avec des poids aléatoires : il ne sait pas parler avant entraînement.
- Un corpus minuscule produit du texte incohérent; un entraînement sérieux demande beaucoup de données, du nettoyage, des tests et un GPU avec mémoire suffisante.
- Le tokeniseur byte-level est volontairement simple; il représente les caractères multi-octets par plusieurs tokens et n'est pas efficace à grande échelle.
- La génération n'est pas encore branchée à l'API centrale existante. C'est une prochaine étape à faire après validation des tests de forme et du pipeline d'entraînement.
- n8n est un orchestrateur d'outils/workflows, pas une API de modèle ni une solution d'entraînement.
- Ne pas entraîner sur des données privées, confidentielles ou protégées sans autorisation.
