# API d'EDG-IA Core

API HTTP indépendante de l'API publique du produit EDG-IA. Format de conversation proche de celui d'OpenAI
(`messages` avec `role` et `content`), sans prétendre à une compatibilité complète.

> **État (phase 3)** : par défaut le serveur utilise le **modèle de démonstration** `edgia-demo`, qui ne génère pas de
> texte avec une IA ; ses réponses le déclarent (`edgia.demo: true` et un champ `notice`). En mode réel, `model` est
> l'identifiant du descripteur et `edgia.demo` vaut `false` ; ce mode n'a jamais été exécuté avec un vrai modèle.

## Démarrage

```bash
export EDGIA_API_KEYS="$(python -c 'import secrets; print(secrets.token_urlsafe(32))')"
PYTHONPATH=src python -m edgia_core serve          # écoute sur 127.0.0.1:8000 par défaut
```

Le service **refuse de démarrer** (code de sortie 2, aucun port ouvert) si la configuration est invalide :
aucune clé d'API, variable `EDGIA_` inconnue, mode réel avec modèle absent, licence non vérifiée, etc.

## Authentification

`Authorization: Bearer <clé>` sur `/v1/models` et `/v1/chat/completions`. Les clés sont fournies par
`EDGIA_API_KEYS` (séparées par des virgules, 24 caractères minimum). `/health` et `/ready` sont publics.

Après 10 authentifications échouées en une minute depuis la même adresse, les requêtes de cette adresse reçoivent `429`.
Derrière un proxy, toutes les requêtes semblent venir de l'adresse du proxy : placez la protection d'accès au niveau du proxy.

## Endpoints

### `GET /health`
Le processus répond. `200 {"status":"ok","service":"edgia-core","version":"..."}`.

### `GET /ready`
Le modèle est prêt à répondre. `200 {"status":"ready","model":"edgia-demo","demo":true}` ou `503` (`model_unavailable`).

### `GET /v1/models`
```json
{"object":"list","data":[{"id":"edgia-demo","object":"model","owned_by":"edgia",
  "edgia":{"demo":true,"model_version":"0","runtime":"demo","ready":true,"notice":"MODE DÉMONSTRATION : …"}}]}
```

### `POST /v1/chat/completions`
`Content-Type: application/json`. Champs (tout champ inconnu ou de mauvais type est refusé, sans conversion implicite) :

| Champ | Type | Défaut | Règle |
|---|---|---|---|
| `messages` | liste | obligatoire | 1 à `EDGIA_MAX_MESSAGES` ; chaque message : `role` (`system`, `user`, `assistant`) et `content` (texte, `EDGIA_MAX_MESSAGE_CHARS` au plus) |
| `model` | texte | modèle actif | doit être l'identifiant du modèle actif |
| `max_tokens` | entier ≥ 1 | `EDGIA_MAX_NEW_TOKENS` | refusé (pas écrêté) au-delà de `EDGIA_MAX_NEW_TOKENS` |
| `temperature` | nombre | 0,7 | de 0 à 2 |
| `top_p` | nombre | 1 | de 0 (exclu) à 1 |
| `stream` | booléen | `false` | voir ci-dessous |
| `stop` | liste de textes | aucune | 4 séquences au plus, de 1 à 64 caractères |
| `knowledge` | objet | absent | ancrage documentaire explicite : `{"collection": "…", "top_k": 1 à 8 (défaut 3)}` ; exige `EDGIA_KNOWLEDGE_DB`. Si `EDGIA_KNOWLEDGE_AUTO_SEARCH=true`, Core recherche aussi automatiquement sans ce champ. Voir `docs/KNOWLEDGE.md`. |

Le prompt et `max_tokens` doivent tenir dans `EDGIA_MAX_CONTEXT_TOKENS`. Le décompte du modèle de démonstration
est approximatif (un mot = un token).

Réponse `200` :
```json
{"id":"chatcmpl-…","object":"chat.completion","created":1760000000,"model":"edgia-demo",
 "choices":[{"index":0,"message":{"role":"assistant","content":"…"},"finish_reason":"stop"}],
 "usage":{"prompt_tokens":3,"completion_tokens":22,"total_tokens":25},
 "edgia":{"demo":true,"model_version":"0","notice":"MODE DÉMONSTRATION : …"}}
```
`finish_reason` vaut `stop` ou `length`.

**Streaming** (`"stream": true`) : réponse `text/event-stream`, un événement `data: {…}` par fragment
(`object: "chat.completion.chunk"`, premier fragment `delta: {"role":"assistant"}`, puis `delta: {"content":"…"}`),
un dernier fragment avec `finish_reason`, `usage` et `edgia`, puis `data: [DONE]`. En cas d'erreur après le début du
flux, un événement `data: {"error":{…}}` est envoyé et le flux se termine **sans** `[DONE]`.

Avec `knowledge` ou la recherche automatique, `edgia.sources` liste les passages utilisés (`n`, `document_id`, `title`, `source`, `section`,
`position`) ; une liste vide signifie qu'aucun passage pertinent n'a été trouvé. Les passages sont envoyés au modèle comme
données non fiables (voir `docs/KNOWLEDGE.md`) ; le prompt final doit encore tenir dans la fenêtre de contexte.

### `POST /v1/knowledge/search`
Authentifié, `Content-Type: application/json`. Corps : `{"query": "…" (1 à 1000 caractères), "top_k": 1 à 20 (défaut 5), "collection": "…" (facultatif)}`.
Réponse `200` : `{"object":"list","data":[{"document_id","title","source","collection","position","section","text","score","coverage"}]}`,
liste vide si rien n'atteint la couverture minimale. `404 knowledge_disabled` si `EDGIA_KNOWLEDGE_DB` n'est pas défini.

### Apprentissage par le chat (si `EDGIA_LEARNING_DB` est défini)

Voir `docs/LEARNING.md`. Une leçon proposée est **en attente** : un humain la relit (`edgia-core learning …`) avant tout usage.

- `POST /v1/learning/lessons` : `{"kind":"fact","consent":true,"text":"…"}` (fait, 10 à 2000 caractères) ou
  `{"kind":"example","consent":true,"messages":[{"role":"user",…},{"role":"assistant",…}]}` (conversation corrigée : 2 à 12 messages,
  `user`/`assistant` en alternance, rôle `system` refusé). `consent` doit valoir `true`. Réponse `201` : `{"object":"lesson","id","kind","status","created_at","pii_redactions","indexed"}`
  (le contenu n'est jamais renvoyé). Avec `EDGIA_LEARNING_AUTO_APPROVE_FACTS=true`, un fait est indexé aussitôt (`status: approved`).
- `GET /v1/learning/lessons[?status=pending|approved|rejected]` : leçons de **la clé appelante** seulement, sans contenu.
- `DELETE /v1/learning/lessons/{id}` : retire une leçon de la clé appelante (et le document indexé). N'annule pas un entraînement déjà fait.

## En-têtes de toutes les réponses
`X-Request-ID` (identifiant à citer dans un signalement), `Cache-Control: no-store`, `X-Content-Type-Options: nosniff`.

## Erreurs

Toutes les erreurs ont la forme `{"error":{"type":"…","code":"…","message":"…"}}`. Les messages ne recopient jamais
le contenu envoyé par le client.

| Statut | `code` | Cause |
|---|---|---|
| 400 | `invalid_json` | corps non JSON, non UTF-8 ou trop imbriqué |
| 400 | `invalid_request` | en-tête `Content-Length` invalide |
| 400 | `knowledge_disabled` | champ `knowledge` du chat sans base documentaire configurée |
| 400 | `streaming_disabled` | `EDGIA_STREAMING_ENABLED=false` |
| 400 | `streaming_unsupported` | le moteur servi ne gère pas le streaming |
| 401 | `unauthorized` | clé absente ou invalide (en-tête `WWW-Authenticate: Bearer`) |
| 404 | `model_not_found` | `model` ne correspond pas au modèle actif |
| 404 | `knowledge_disabled` | `POST /v1/knowledge/search` sans base documentaire configurée |
| 404 | `not_found` | route inconnue |
| 405 | `method_not_allowed` | méthode non prévue (en-tête `Allow`) |
| 413 | `request_too_large` | corps supérieur à `EDGIA_MAX_REQUEST_BYTES` (contrôlé aussi sans `Content-Length`) |
| 415 | `unsupported_media_type` | `Content-Type` différent de `application/json` |
| 422 | `invalid_request` | schéma non respecté ou limite dépassée (messages, longueur, `max_tokens`) |
| 404 | `learning_disabled` | routes `/v1/learning/…` sans `EDGIA_LEARNING_DB` |
| 404 | `lesson_not_found` | leçon inconnue ou appartenant à une autre clé |
| 409 | `lesson_duplicate` | leçon identique déjà proposée |
| 409 | `lesson_state` | leçon déjà traitée, ou indexation / retrait impossible (base documentaire) |
| 422 | `consent_required` | `consent` absent de la leçon ou différent de `true` |
| 422 | `lesson_invalid` | leçon hors limites (longueur, rôles, caractères de contrôle) |
| 429 | `lesson_quota_exceeded` | trop de leçons en attente pour cette clé (`EDGIA_LEARNING_MAX_PENDING_PER_KEY`) |
| 422 | `context_length_exceeded` | prompt + `max_tokens` au-delà de `EDGIA_MAX_CONTEXT_TOKENS` |
| 429 | `rate_limited` | limite de requêtes par clé, ou trop d'échecs d'authentification (en-tête `Retry-After`) |
| 500 | `internal_error` | erreur interne (détails dans les journaux, jamais dans la réponse) |
| 503 | `server_busy` | `EDGIA_MAX_CONCURRENT_REQUESTS` générations déjà en cours (`Retry-After: 1`, pas de file d'attente) |
| 503 | `model_unavailable` | modèle non prêt ou serveur en arrêt |
| 504 | `generation_timeout` | génération plus longue que `EDGIA_REQUEST_TIMEOUT_SECONDS` |

## Journalisation

Une ligne par requête : identifiant, méthode, chemin (caractères de contrôle neutralisés, sans paramètres d'URL),
statut, durée, identité de la clé (`key-1`, `key-2`… selon sa position dans la configuration, jamais la clé),
nombre de tokens. **Le contenu des messages n'est jamais journalisé** tant que `EDGIA_LOG_REDACT_CONTENT=true`
(valeur par défaut) ; avec `false` et `EDGIA_LOG_LEVEL=DEBUG`, il apparaît dans les journaux : à réserver au
développement, jamais en production.

## Limites connues

- Une génération qui dépasse son délai reçoit `504`. Le moteur de langage réel est alors interrompu (annulation) ; le
  modèle de démonstration, lui, va jusqu'au bout et garde son emplacement de concurrence jusque-là.
- Les limites de débit sont en mémoire et locales à un processus. Avec plusieurs instances, une limite globale
  relève de la passerelle.
- Le serveur ne gère pas TLS : placez-le derrière un proxy TLS pour tout usage hors de la machine locale.
- Aucune requête n'est mise en file d'attente : au-delà de la concurrence permise, la réponse est immédiate (`503`).
