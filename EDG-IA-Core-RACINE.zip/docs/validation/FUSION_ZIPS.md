# Fusion des archives

Sources comparées fichier par fichier (contenu SHA-256) : `EDG-IA-Core-L0-corrige` (221 fichiers), `EDG-IA-Core-Knowledge-v1` / `_1` / `_0c37d9`
(238 fichiers, les trois sont strictement identiques) et la livraison « Apprentissage par le chat ».

| Cas | Fichiers | Décision |
|---|---|---|
| Identiques dans toutes les archives | 212 | gardés une seule fois |
| Présents seulement dans Knowledge v1 (bibliothèque de départ : `starter.py`, 14 notes, test, rapport) | 17 | gardés |
| Différents entre L0 et Knowledge v1 (`README.md`, `pyproject.toml`, `.env.example`, `cli.py`, `config.py`, `api/app.py`, `docs/API.md`, `docs/KNOWLEDGE.md`, `tests/unit/test_knowledge_api.py`) | 9 | Knowledge v1 contient tout L0 plus des ajouts (recherche automatique, `seed-starter`, paquet de données) : version Knowledge gardée |
| Présents seulement dans L0 | 0 | — |
| Ajoutés ou modifiés par l'apprentissage par le chat | 7 nouveaux, 13 modifiés | intégrés par-dessus Knowledge v1 (6 des 13 recoupent les 9 fichiers ci-dessus : les ajouts des deux côtés sont conservés) |

Aucun conflit réel (deux versions chacune avec un ajout que l'autre n'a pas) : L0 est un état antérieur de Knowledge v1.
Le dossier `__pycache__` et `.pytest_cache` ne sont pas inclus.
