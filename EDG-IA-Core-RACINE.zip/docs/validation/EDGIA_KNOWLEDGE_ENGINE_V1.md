# EDG-IA Knowledge Engine v1 — rapport de livraison

Date : 7 novembre 2026

## Livré

- Pack documentaire initial original de 14 notes Markdown : méthode RAG, français, anglais, mathématiques, statistiques/probabilités, informatique, Python, Web, algorithmique, physique, biologie, géographie du Cameroun, méthodes d'apprentissage, IA/apprentissage automatique.
- Indexation SQLite FTS5 par collections et passages avec les fonctions de recherche et de citation déjà présentes dans EDG-IA Core.
- Nouvelle commande idempotente `edgia-core knowledge --db data/knowledge.sqlite3 seed-starter`. Elle ajoute les documents absents et ne remplace jamais les documents déjà présents.
- Option `EDGIA_KNOWLEDGE_AUTO_SEARCH=true` : lorsque la base est configurée, Core recherche automatiquement dans la bibliothèque à partir du dernier message utilisateur. L'option est désactivée par défaut et son activation sans base est refusée au démarrage.
- Le champ explicite `knowledge` des requêtes chat et `POST /v1/knowledge/search` restent disponibles.
- Les passages sont injectés comme données non fiables, et les sources utilisées apparaissent dans `edgia.sources`.
- Documentation mise à jour dans `docs/KNOWLEDGE.md`, `docs/API.md`, `.env.example` et `README.md`.

## Vérifications effectuées

- Tests documentaires et API : **43 réussis**.
- Création de la base par la commande CLI : **14 documents indexés, 59 passages**, 8 collections.
- Recherche CLI sur « Python langage programmation » : résultat retrouvé dans la collection `programmation`.
- Recherche automatique pendant un appel chat sans champ `knowledge` : test réussi ; le contexte est transmis au moteur et la source est retournée.
- Garde de configuration (recherche automatique sans base) : test réussi, démarrage refusé.
- Compilation Python (`compileall`) : réussie.
- Construction du wheel Python en mode sans isolation : réussie ; les **14 fichiers Markdown** du pack sont présents dans le wheel.

## Limites et éléments non prétendus

- Le pack est une bibliothèque de démarrage pédagogique concise, pas une encyclopédie exhaustive et pas un corpus suffisant pour préentraîner le modèle.
- La recherche reste lexicale (SQLite FTS5/BM25), pas sémantique : synonymes et reformulations peuvent être manqués.
- Les notes originales doivent être relues avant diffusion publique ; les données évolutives doivent être vérifiées avec des sources officielles récentes.
- La recherche RAG ne modifie pas les poids du modèle. Une passerelle distincte vers la préparation d'un corpus d'entraînement, avec droits, consentement, nettoyage, déduplication, validation et approbation humaine, reste à concevoir.
- La suite complète de tous les tests du dépôt n'a pas été terminée : le lancement global a dépassé le délai disponible. Aucun résultat global de suite complète n'est revendiqué.
- Aucun entraînement de modèle ni test GPU n'a été exécuté.
