# EDG-IA Core L0 — correctifs techniques complémentaires

Date : 7 novembre 2026

## Périmètre

Correctifs appliqués dans cette copie de travail du ZIP L0. L'archive L0 d'origine n'a pas été modifiée. Les autres fichiers du projet sont conservés.

## Correctifs

1. `src/edgia_core/evaluation/sandbox.py`
   - La limite mémoire virtuelle par défaut du sous-processus sandbox passe de 256 à 512 MiB.
   - Les limites CPU, durée, taille de fichier, processus et groupe de processus restent actives.
   - Cette valeur répond au diagnostic observé dans cet environnement : le démarrage Python échouait avec `pthread_create() ... Resource temporarily unavailable` sous 256 MiB.
   - 512 MiB reste une limite, mais elle est plus permissive : à réévaluer sur les machines de déploiement. Ce sandbox n'est pas une isolation contre du code hostile ; utiliser un conteneur ou une VM jetable sans réseau pour du code non fiable.

2. `tools/sandbox_diagnose.py`
   - Sa limite de diagnostic est alignée sur les 512 MiB de `SandboxLimits()`.

3. `src/edgia_core/native/config.py`
   - Validation renforcée des paramètres d'entraînement : entiers positifs, valeurs numériques finies, plages des coefficients Adam, taux et fréquences.
   - Une valeur `micro_batch_seqs=0` est désormais rejetée proprement par `ConfigError`, sans division par zéro.

4. `tests/native/test_config.py`
   - Ajout de cas invalides pour micro-batch nul, coefficients Adam hors plage, fréquence de checkpoint nulle et weight decay négatif.

## Tests exécutés ici

- `PYTHONPATH=src pytest -q tests/unit --disable-warnings` : **360 passed, 2 subtests passed**.
- `PYTHONPATH=src pytest -q tests/native/test_config.py tests/unit/test_eval_sandbox.py --disable-warnings` : **27 passed, 2 subtests passed**.
- `PYTHONPATH=src pytest -q tests/native --disable-warnings` : **non terminé dans le délai disponible** ; aucun résultat global ne peut être annoncé.

## Limites non validées

- Pas de validation GPU/CUDA, de benchmark VRAM ni d'entraînement complet.
- Pas d'approbation juridique des sources de données d'entraînement.
- Les changements doivent être revus avant déploiement en production, en particulier la hausse de la limite mémoire du sandbox.
