# Dépendances et versions testées

Règle : une version n'est déclarée « testée » que si les tests ont réellement été exécutés avec elle.

## Environnement de la phase 1

Les tests ont été exécutés dans l'environnement de la session de développement. L'accès à PyPI y est refusé
(403 du proxy) : **aucun paquet n'a pu être installé**. Seuls les paquets déjà présents ont servi.

| Composant | Version | Statut |
|---|---|---|
| Python | 3.13.16 | testé (le projet déclare `>=3.11` ; 3.11 et 3.12 non testés) |
| pydantic | 2.13.5 | **testé** (config, descripteur, schémas de l'API) |
| PyYAML | 6.0.3 | **testé** (descripteur) |
| starlette | 1.6.0 | **testé** (serveur HTTP, phase 2) |
| uvicorn | 0.53.0 | **testé** (serveur lancé en processus réel, phase 2) |
| anyio | 4.15.1 | présent (dépendance de starlette), non déclaré directement |
| unittest (bibliothèque standard) | — | **utilisé** pour tous les tests (plus de 200 exécutés) |

numpy 2.5.3 est présent dans l'environnement mais n'est pas utilisé.

## Choix du serveur : Starlette plutôt que FastAPI

FastAPI n'a pas pu être installé (PyPI bloqué dans la session de développement). Le serveur est donc écrit avec
Starlette, que FastAPI utilise lui-même ; les routes, les formats de requête et de réponse ne dépendent pas de ce choix,
donc l'application EDG-IA n'en verra aucune différence. Migrer vers FastAPI reste possible plus tard.

## Prévus, non installés, non testés

| Composant | Pourquoi | Décision |
|---|---|---|
| pytest | confort de développement | extra `dev`; non installé ici : les tests utilisent `unittest` et n'ont pas été lancés avec pytest |
| torch, transformers | chargement du modèle réel (phase 3) | extra `ml` ; **code écrit mais jamais exécuté avec ces bibliothèques** ; versions à noter après le premier chargement réel |
| peft | adaptateur LoRA (phases 3-4) | extra `ml` ; non testé ; requis seulement avec un adaptateur |
| safetensors | lecture des poids | installé avec Transformers ; non déclaré directement |
| Base relationnelle | métadonnées du registre (phase 3) | **`sqlite3` de la bibliothèque standard, utilisé et testé** |
| Moteur de recherche documentaire | phase 6 | à choisir selon le volume de documents |

## Fichier de versions figées

Un fichier de versions figées (lock) complet ne peut pas être produit honnêtement ici : PyPI est inaccessible, donc
`pip freeze` d'un environnement propre est impossible. `pyproject.toml` pose des bornes sur les quatre dépendances
réellement testées (pydantic, PyYAML, starlette, uvicorn). **À faire sur une machine avec accès à PyPI** : créer un
environnement propre, relancer les tests, puis figer les versions (`pip freeze` ou `pip-compile`). Les dépendances
de `ml` (torch, transformers, peft, safetensors) seront évaluées en phase 3, selon le modèle retenu.

## Mise à jour (phases 4 à 7)

- **Aucune dépendance Python ajoutée** : les phases 4 à 7 n'utilisent que la bibliothèque standard et les quatre dépendances testées
  (pydantic, PyYAML, starlette, uvicorn). La base documentaire s'appuie sur `sqlite3` avec **FTS5** (SQLite 3.45.1 ici ; FTS5 est
  absent de certaines compilations de SQLite : le programme le détecte et refuse avec un message clair).
- **Facultatifs, non installés, non testés** : `pypdf` (lecture des PDF), `torch`, `transformers`, `peft`, `safetensors` (mode réel et
  entraînement). La boucle d'entraînement et le chargement réel n'ont jamais été exécutés avec ces bibliothèques.
- Docker, systemd, nginx, Caddy : fichiers d'exemple jamais exécutés.
- Les versions ne sont toujours pas figées (PyPI inaccessible dans la session de développement).
