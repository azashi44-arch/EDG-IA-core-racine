# Premier modèle réel — Windows 10/11

Ce guide prépare **Qwen2.5-1.5B-Instruct** pour un premier test local. Le modèle n'est pas fourni dans le ZIP : son téléchargement demande plusieurs Go et doit se faire sur le PC qui exécutera EDG-IA Core.

## 1. Préparer l'environnement

Ouvrez PowerShell dans le dossier `EDG-IA-Core` :

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip setuptools
python -m pip install -e .
python -m pip install torch transformers huggingface_hub safetensors
```

Si PowerShell bloque l'activation, utilisez une invite de commandes (CMD) :

```bat
.venv\Scripts\activate.bat
```

Le premier téléchargement demande Internet et plusieurs Go libres. Gardez au moins 8 Go libres pour le modèle, le cache et les fichiers temporaires. Sur un PC avec 16 Go de RAM et sans GPU CUDA, démarrez en mode CPU ; la génération peut être lente.

## 2. Télécharger les poids et créer le descripteur

Depuis la racine `EDG-IA-Core` avec l'environnement virtuel activé :

```powershell
python scripts/prepare_qwen_model.py
```

Le script télécharge le modèle et le tokenizer dans `models/qwen2.5-1.5b-instruct`, calcule les SHA-256 des poids et crée `configs/model.yaml`. Il ne remplace jamais un descripteur existant.

## 3. Vérifier la licence avant l'usage commercial

Ouvrez `models/qwen2.5-1.5b-instruct/LICENSE` et lisez les conditions. Le descripteur généré reste volontairement bloqué jusqu'à une vérification humaine. Seulement après cette lecture, ouvrez `configs/model.yaml` et confirmez les deux champs :

```yaml
license:
  commercial_use_allowed: true
  reviewed: true
```

Ne mettez pas ces valeurs à `true` si la licence n'a pas été lue et validée. Vérifiez aussi les obligations de conservation de licence et d'attribution.

## 4. Vérifier le descripteur et les dépendances

```powershell
python -m edgia_core check-config --env-file .env
```

Créez `.env` à partir de `.env.example` et renseignez au minimum :

```dotenv
EDGIA_MODE=real
EDGIA_HOST=127.0.0.1
EDGIA_PORT=8000
EDGIA_MODEL_DESCRIPTOR=configs/model.yaml
EDGIA_AUTH_ENABLED=true
EDGIA_API_KEYS=REMPLACER_PAR_UNE_CLE_ALEATOIRE_DE_32_CARACTERES_OU_PLUS
EDGIA_MAX_CONTEXT_TOKENS=4096
EDGIA_MAX_NEW_TOKENS=512
EDGIA_REQUEST_TIMEOUT_SECONDS=120
EDGIA_MAX_CONCURRENT_REQUESTS=1
```

Générez une clé locale aléatoire avec :

```powershell
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

Collez la clé produite dans `EDGIA_API_KEYS`. Ne partagez pas `.env` et ne mettez jamais cette clé dans l'application mobile.

## 5. Lancer et tester l'API

```powershell
python -m edgia_core serve --env-file .env
```

Dans une seconde fenêtre PowerShell, avec la même clé :

```powershell
$env:EDGIA_API_KEY = "COLLER_LA_MEME_CLE_ICI"
Invoke-RestMethod http://127.0.0.1:8000/health
Invoke-RestMethod http://127.0.0.1:8000/v1/models -Headers @{ Authorization = "Bearer $env:EDGIA_API_KEY" }
$body = @{ model = "qwen2.5-1.5b-instruct"; messages = @(@{ role = "user"; content = "Réponds en français : explique la photosynthèse à un élève de 12 ans." }); max_tokens = 120; temperature = 0.2 } | ConvertTo-Json -Depth 6
Invoke-RestMethod http://127.0.0.1:8000/v1/chat/completions -Method Post -Headers @{ Authorization = "Bearer $env:EDGIA_API_KEY" } -ContentType "application/json" -Body $body
```

Confirmez dans la réponse que `edgia.demo` est absent ou vaut `false`. Un démarrage réussi seul ne suffit pas : gardez la réponse de test, le temps de chargement et la mémoire consommée pour la validation.

## 6. Intégrer à l'application EDG-IA

L'intégration doit être faite **dans le backend NestJS**, jamais directement depuis Expo Go : la clé Core doit rester côté serveur. Pour le backend de l'application, les paramètres de base sont :

```dotenv
AI_PROVIDER=openai-compatible
AI_BASE_URL=http://127.0.0.1:8000/v1
AI_API_KEY=LA_MEME_CLE_QUE_EDGIA_API_KEYS
AI_MODEL=qwen2.5-1.5b-instruct
AI_TIMEOUT_MS=130000
AI_MAX_TOKENS=400
```

Ces variables appartiennent au `.env` du **backend NestJS**, pas au `.env` mobile. Si Core et NestJS sont dans le même PC, `127.0.0.1` convient. Si Core tourne sur un autre ordinateur, utilisez l'adresse privée de cet ordinateur et protégez le trafic avec un réseau de confiance et TLS ; n'exposez pas le port Core directement sur Internet.

Le patch de référence `integration/app-patch/ai-provider.edgia-core.patch` ajoute le refus explicite du modèle de démonstration et la lecture de `edgia.sources`. Il n'a pas été appliqué à l'application dans cette archive. Avant de l'appliquer, vérifiez le fichier réel `backend/src/ai/ai-provider.ts` de la version exacte de l'application. Gardez une sauvegarde et vérifiez `ai.service.ts`, les quotas, le timeout et la gestion des erreurs après le changement.

## Limites et statut

- Ce guide ne prétend pas que les poids ont été téléchargés ou chargés dans l'environnement de création de l'archive.
- Le backend Transformers du projet indique que le premier chargement avec de vraies bibliothèques et de vrais poids n'a pas encore été validé. La commande de test ci-dessus est donc obligatoire.
- La suite de tests de ce ZIP a des échecs liés au bac à sable d'exécution de code dans certains environnements. Ils doivent être traités séparément ; ne les masquez pas pour déclarer Core entièrement validé.
- Pour terminer l'intégration au code exact de l'application, il faut l'archive source de l'application EDG-IA (par exemple `EDG-IA_v7_1_0_EGA_SOURCE.zip` ou la version réellement utilisée). Ce ZIP Core seul ne contient pas le backend complet NestJS.
