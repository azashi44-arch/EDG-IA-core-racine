# Architecture d'EDG-IA Core

EDG-IA Core est un projet **indépendant** de l'application EDG-IA. Il sera relié à l'application plus tard,
uniquement par une API HTTP sécurisée (phase 8). Aucun fichier de l'application existante n'est lu ni modifié.

## Rôle de chaque partie

| Module | Responsabilité | Phase |
|---|---|---|
| `config.py` | Configuration par variables d'environnement, sécurisée par défaut, rapport « le service peut-il démarrer ? » | 1 (fait) |
| `model/descriptor.py` | Descripteur de modèle : fichiers, format, runtime, licence, matériel, adaptation, sommes SHA-256 | 1 (fait) |
| `model/registry.py` | Registre SQLite : versions immuables, validation, activation contrôlée (revalidée), retour arrière, historique | 3 (fait) |
| `model/loader.py`, `inference/llm_engine.py`, `inference/hf_backend.py` | Chargement du modèle réel (Transformers), arrêts, annulation, streaming. **Backend jamais exécuté avec de vraies bibliothèques** | 3 (écrit ; validation réelle à faire) |
| `inference/` | Interface des moteurs (`InferenceEngine`), modèle de démonstration, verrou de concurrence | 2 (fait) |
| `api/`, `server.py` | Serveur Starlette : `/health`, `/ready`, `/v1/models`, `/v1/chat/completions`, streaming (voir `API.md`) | 2 (fait) |
| `security/` | Authentification par clé, limite de débit, blocage des échecs d'authentification | 2 (fait) |
| `training/` | Préparation des données (masquage, anti-contamination, déduplication, découpage), plan et boucle SFT/LoRA | 4 |
| `evaluation/` | Évaluations, comparaison base/adapté, rapport | 5 |
| `ops/` | Diagnostic de l'environnement (`doctor`) et sauvegardes SQLite vérifiables (`backup`) | 7 |
| `integration/` | Vérificateur de contrat HTTP (`contract-check`) ; client Node de référence à la racine (`integration/`) | 8 |
| `knowledge/` | Base documentaire : extraction, découpage, recherche lexicale FTS5, contexte non fiable pour le modèle | 6 |

## Principes appliqués dès la phase 1

- **Sécurisé par défaut** : écoute locale (`127.0.0.1`), authentification et limite de débit activées.
  Désactiver l'authentification est refusé hors boucle locale.
- **Refus de démarrer en mode réel** si le descripteur, les poids, le tokenizer, la licence ou les sommes de contrôle
  ne sont pas valides. Le mode démonstration existe, mais se déclare toujours comme tel.
- **Une variable `EDGIA_` inconnue est refusée** : une faute de frappe ne doit pas désactiver une protection.
- **Les secrets ne sont jamais recopiés** dans les messages d'erreur, ni affichés par `repr`, `str` ou `model_dump`.
- **Pas de format pickle** pour les poids (`.bin`, `.pt`) : seuls `safetensors` et `gguf` sont acceptés.
- **Aucun téléchargement automatique** de poids ; aucun entraînement lancé par le code.

## Mode réel (phase 3)

L'API ne connaît que l'interface `InferenceEngine`. En mode réel, `create_app` valide le descripteur (ou prend la
version active du registre), puis charge le modèle avec `build_engine` : `HuggingFaceBackend` (produit du texte) sous
`LanguageModelEngine` (arrêts, annulation, comptage, streaming). Tout échec de chargement **empêche le démarrage** ;
il n'y a jamais de repli sur la démonstration. Voir `docs/GUIDE_SPECIALISTES.md`.

## Quatre mécanismes distincts (à ne pas confondre)

1. **Adaptation des paramètres du modèle** (entraînement, SFT/LoRA) : réalisée par l'équipe d'entraînement ; ce projet fournit les outils et l'évaluation.
2. **Base de connaissances** (documents indexés) : connaissances externes au modèle, ajoutables et supprimables sans réentraîner.
3. **Mémoire conversationnelle** : contexte envoyé à chaque requête, limité par `EDGIA_MAX_CONTEXT_TOKENS`.
4. **Retours utilisateurs** : collectés en vue d'une amélioration future uniquement ; jamais de réentraînement automatique.
   Les leçons proposées par chat (`learning/`, voir `LEARNING.md`) en sont la voie : faits indexés après relecture, exemples exportables, aucun entraînement automatique.
   Tout cycle d'amélioration exige : validation des données, contrôle des droits, protection des données personnelles,
   évaluation du modèle obtenu et approbation humaine avant déploiement.

## Frontière avec le produit EDG-IA

L'API d'EDG-IA Core est distincte de l'API publique du produit. Les comptes développeurs, les quotas commerciaux
et les clés des clients relèvent de la passerelle ou du backend du produit, pas de ce projet. Ce projet ne connaît
que des clés techniques, fournies par variables d'environnement.
