# Suivi des phases

Règle : chaque phase enrichit les fichiers existants sans les recréer ni les supprimer.

| Phase | Contenu | État |
|---|---|---|
| 1 | Squelette, configuration, descripteur de modèle, tests | **Terminée** (voir compte rendu ci-dessous) |
| 2 | Serveur d'inférence, endpoints, sécurité, modèle de démonstration | **Terminée** (voir compte rendu) |
| 3 | Registre et adaptateur de modèle, premier chargement d'un petit modèle autorisé | **Écrite, validation réelle à faire** (voir compte rendu) |
| 4 | Préparation des données, outils d'adaptation (SFT/LoRA) | **Écrite ; entraînement jamais exécuté** (voir compte rendu) |
| 5 | Évaluations et rapport de résultats | **Écrite, jamais exécutée sur un vrai modèle** (voir compte rendu) |
| 6 | Recherche documentaire | **Écrite et testée (recherche lexicale seulement)** (voir compte rendu) |
| 7 | Déploiement et documentation pour les spécialistes | **Documentation et outils écrits ; déploiement jamais exécuté** (voir compte rendu) |
| 8 | Contrat d'intégration avec l'application EDG-IA | **Écrite ; contrat vérifié contre le serveur de démonstration, jamais contre l'application réelle** (voir compte rendu) |

## Phase 1 — compte rendu

**Fonctionnel et testé** (52 tests unitaires exécutés, tous réussis, Python 3.13.16, pydantic 2.13.5, PyYAML 6.0.3) :
- configuration par variables d'environnement et fichier `.env`, sécurisée par défaut ;
- refus des variables `EDGIA_` inconnues, des clés trop courtes ou dupliquées, de l'authentification désactivée hors boucle locale ;
- descripteur de modèle (format, runtime, licence, matériel, adaptation, SHA-256) et vérifications locales ;
- refus de démarrer en mode réel si descripteur, poids, tokenizer, licence ou sommes de contrôle sont absents ou invalides ;
- commande `python -m edgia_core check-config`.

**Écrit mais NON testé** :
- `Dockerfile` et `compose.yaml` (aucune image construite) ;
- `pip install .` / `pip install -e .` : essayé dans la session, la construction a échoué à cause du setuptools 68.1.2
  fourni par Debian (erreur `install_layout` avec Python 3.13), sans rapport apparent avec le code ; setuptools n'a pas pu être
  mis à jour (PyPI inaccessible). À revérifier sur une machine avec un setuptools récent. D'ici là, les tests et
  `check-config` se lancent depuis les sources avec `PYTHONPATH=src`.

**Pas encore implémenté** : serveur HTTP, registre, adaptateur, entraînement, évaluation, recherche documentaire.

**Problèmes restants** :
- PyPI est inaccessible depuis la session de développement : fastapi, pytest et httpx n'ont pas pu être installés ;
  les tests de la phase 1 utilisent donc `unittest`. L'API (phase 2) devra être testée dans un environnement avec accès à PyPI.
- Python 3.11 et 3.12 (versions minimales déclarées) n'ont pas été testés.
- Aucun modèle de base n'est choisi : à décider avec l'équipe d'entraînement, après examen des licences (voir `docs/ARCHITECTURE.md`).

## Phase 2 — compte rendu

**Fonctionnel et testé** (141 tests exécutés au total, tous réussis, aussi avec les avertissements traités comme des erreurs ;
Python 3.13.16, starlette 1.6.0, uvicorn 0.53.0, pydantic 2.13.5) :
- `GET /health`, `GET /ready`, `GET /v1/models`, `POST /v1/chat/completions` (réponse complète et streaming SSE) ;
- validation stricte des requêtes, erreurs JSON documentées (`docs/API.md`) qui ne recopient jamais le contenu du client ;
- authentification par clé (comparaison en temps constant, clés jamais conservées en clair), blocage après échecs répétés ;
- limite de débit par clé, limites de taille (corps, y compris sans `Content-Length`, messages, `max_tokens`, fenêtre de contexte) ;
- délai d'attente (504) et limite de concurrence (503) ; l'emplacement n'est rendu qu'à la fin réelle de la génération ;
- journaux sans contenu des messages ni clés, caractères de contrôle neutralisés ;
- le serveur lancé en vrai processus répond en HTTP, et refuse de démarrer (code 2, aucun port ouvert) sans clé, avec un modèle réel absent ou une variable inconnue ;
- le modèle de démonstration se déclare comme tel dans chaque réponse (`edgia.demo`, `edgia.notice`).

**Pas encore implémenté** : chargement d'un vrai modèle (le mode réel est refusé explicitement), registre de modèles,
entraînement, évaluation, recherche documentaire.

**Écrit mais NON testé** : `Dockerfile` et `compose.yaml` (pas construits ; le `CMD` du Dockerfile ne lance encore que
`check-config`, à remplacer par `serve` une fois l'image validée) ; `pip install .` (voir phase 1) ; tests avec pytest.

**Problèmes restants / limites** :
- Aucun test de charge ni de montée en puissance n'a été fait ; seuls des scénarios de concurrence à 1 ou 2 requêtes sont testés.
- Une génération en dépassement de délai ne peut pas être interrompue dans son thread (limite documentée dans `API.md`) ; le moteur réel de la phase 3 devra gérer l'annulation.
- Les limites de débit sont locales au processus ; pas de TLS (à placer derrière un proxy).
- Les versions ne sont pas figées dans un fichier de verrouillage (PyPI inaccessible ici, voir `docs/DEPENDANCES.md`).
- Le décompte de tokens du modèle de démonstration est une approximation (un mot = un token) ; celui du vrai modèle viendra de son tokenizer.

## Phase 3 — compte rendu

**Fonctionnel et testé** (plus de 200 tests exécutés, tous réussis ; Python 3.13.16) :
- registre de modèles SQLite : versions immuables, validation (licence, fichiers, SHA-256), activation **revalidée à l'instant**,
  une seule version active, retour arrière, historique, persistance dans un fichier ; commandes `edgia-core models …` ;
- moteur de langage générique (`LanguageModelEngine`) : séquences d'arrêt même coupées entre deux morceaux, comptage,
  streaming, **annulation réelle** d'une génération en dépassement de délai (l'emplacement de concurrence est alors rendu
  rapidement, ce qui corrige la limite de la phase 2 pour ce moteur), fermeture propre ;
- mode réel dans le serveur : le modèle est chargé avant l'ouverture du port, depuis un descripteur ou la version active
  du registre ; tout échec empêche le démarrage ; **jamais de repli sur la démonstration** ; vérifié en processus réel
  (sans PyTorch, le serveur refuse de démarrer avec « Dépendance absente »).

**Écrit mais JAMAIS exécuté avec de vraies bibliothèques** :
- `inference/hf_backend.py` (chargement PyTorch/Transformers, génération en flux, adaptateur LoRA) : testé uniquement avec
  de fausses bibliothèques (`tests/unit/test_hf_backend_smoke.py`), qui vérifient l'enchaînement des appels et la logique
  de fin, **pas** la compatibilité avec le vrai Transformers. Ce test de fumée a d'ailleurs révélé un vrai défaut
  (une génération normale se terminait en « annulée »), corrigé et gardé sous test ; d'autres défauts ne peuvent être
  découverts qu'avec le vrai modèle.
- `tests/real_model/test_real_model.py` : écrit, **jamais lancé** (ignoré faute de modèle). C'est le premier test à
  exécuter sur la machine de l'équipe d'entraînement (voir `docs/GUIDE_SPECIALISTES.md`).

**Pas pris en charge** : runtime `llama_cpp` / format GGUF ; quantification au chargement (QLoRA, 4 bits) ; répartition
d'un modèle sur plusieurs GPU ; traitement par lots (les générations sont sérialisées) ; rechargement à chaud d'une
nouvelle version (redémarrage nécessaire) ; lecture automatique de la fenêtre de contexte du modèle.

**Problèmes restants / limites** :
- Aucun modèle n'a été chargé : temps de chargement, mémoire et vitesse sont inconnus.
- Le choix du modèle de base n'est pas fait (voir `docs/MODELES_CANDIDATS.md`) ; licences à lire en texte intégral.
- Les limites des phases 1 et 2 restent valables (Dockerfile non construit, versions non figées, pas de TLS).

## Phase 5 — compte rendu

**Fonctionnel et testé** (266 tests exécutés, tous réussis, aussi avec `-W error` ; Python 3.13.16) :
- format de suite YAML strict (erreurs avec fichier et cas, doublons, somme SHA-256) ; 16 types de vérifications
  déterministes (nombres au format français, JSON, structure, langue, refus, accents/casse) ;
- exécuteur (température 0, latence, débit, mémoire maximale, erreurs de moteur isolées par cas), statuts
  pass/fail/partial/skipped/review/error ;
- rapports Markdown, HTML autonome (sortie du modèle échappée), CSV de relecture (formules neutralisées) ; bandeau
  « sans signification » pour le moteur de démonstration ;
- comparaison de deux résultats (même suite exigée, cas inversés, écart par catégorie, McNemar exact indicatif) ;
- bac à sable de code **optionnel** (désactivé par défaut) : boucle infinie, excès de mémoire et fichiers géants testés
  réellement dans un sous-processus ;
- suite de départ : 43 cas (9 français, 10 connaissances, 4 rédaction/résumé, 8 instructions, 5 programmation,
  7 sécurité/robustesse), validée par des réponses de référence écrites à la main (elles réussissent ; des réponses
  fausses échouent) ;
- commandes `edgia-core eval validate-suite | run | compare`.

**Écrit mais JAMAIS exécuté** : évaluation d'un vrai modèle (`--descriptor` s'appuie sur le chargement de la phase 3,
lui-même jamais exécuté avec de vraies bibliothèques) ; mesure de mémoire GPU (nécessite PyTorch et un GPU).

**Limites** : voir `docs/EVALUATION.md` (heuristiques, 43 cas seulement, vérifications de non-fuite faibles, un seul
tirage déterministe, bac à sable non étanche — conteneur jetable recommandé, POSIX uniquement). Aucun résultat de
modèle réel n'existe : aucune capacité n'est démontrée.

## Phase 4 — compte rendu

**Fonctionnel et testé** (299 tests exécutés au total, tous réussis, aussi avec `-W error` ; Python 3.13.16) :
- format JSONL strict avec source, licence et origine obligatoires ; erreurs par fichier et ligne sans recopier le contenu ;
- préparation : refus des conversations d'utilisateurs sans consentement ET autorisation explicite, filtres de qualité,
  masquage de données personnelles par motifs, **anti-contamination avec la suite d'évaluation**, doublons exacts et
  quasi-doublons, découpage déterministe par groupe, manifeste avec sommes SHA-256 ; dossier de sortie jamais écrasé ;
- plan d'entraînement qui refuse tant que licence, poids, jeu de données (intact, contrôlé contre la contamination),
  nombre d'exemples et dépendances ne sont pas en règle ; lancement uniquement avec `--confirm-training` ;
- fonctions pures du SFT (labels limités à la dernière réponse, calendrier du taux d'apprentissage, descripteur proposé
  avec licence remise à « non vérifiée ») ;
- commandes `edgia-core data validate | prepare` et `edgia-core train plan | run`.

**Écrit mais JAMAIS exécuté** : la boucle d'entraînement LoRA (`training/sft.py`, `run_sft`) : elle exige PyTorch,
Transformers et PEFT, indisponibles ici. Première version à valider sur un petit modèle et un très petit jeu.

**Pas pris en charge** : QLoRA, multi-GPU, reprise après interruption, mesure réelle de la mémoire.

**Problèmes restants** : aucune donnée réelle (sources, droits, consentements à établir) ; masquage des noms et adresses
impossible par motifs ; voir `docs/DONNEES.md`. Aucun modèle adapté n'existe : aucune amélioration n'est démontrée.

## Phase 6 — compte rendu

**Fonctionnel et testé** (339 tests exécutés au total, tous réussis, aussi avec `-W error` ; Python 3.13.16, SQLite 3.45.1 avec FTS5) :
- base documentaire SQLite : source et droits obligatoires, doublons refusés, suppression complète d'un document, persistance ;
- extraction `.txt`, `.md`, `.html`, `.docx` (bibliothèque standard ; DOCTYPE/ENTITY refusés, taille bornée) ; document sans texte refusé ;
- découpage en passages avec sections et recouvrement ; recherche FTS5/BM25 insensible aux accents et à la casse, avec seuil de
  couverture (rien de pertinent = liste vide), filtre par collection, syntaxe de recherche non injectable ;
- ancrage des réponses : extraits délimités et présentés comme données non fiables, sources numérotées dans `edgia.sources` ;
- API : `POST /v1/knowledge/search` et champ `knowledge` du chat (réponse complète et streaming), refus propre sans base,
  erreurs sans recopie du contenu ; le serveur refuse de démarrer si la base configurée est absente ;
- commandes `edgia-core knowledge add | list | search | delete | stats`.

**Écrit mais NON testé** : lecture des `.pdf` (exige `pypdf`, absent ici ; seul le refus clair sans la bibliothèque est testé).

**Pas pris en charge** : embeddings / recherche sémantique, OCR, mise à jour en place, droits d'accès par utilisateur ou
établissement, tests de performance sur de gros volumes.

**Problèmes restants** : la recherche lexicale rate les questions formulées avec d'autres mots que le document ; l'injection
de consignes par un document est atténuée, pas éliminée ; aucun vrai modèle n'a été testé avec les extraits (citations,
absence d'invention non vérifiées) ; les droits des documents sont déclarés, jamais vérifiés. Voir `docs/KNOWLEDGE.md`.

## Phase 7 — compte rendu

**Fonctionnel et testé** (352 tests exécutés au total, tous réussis, aussi avec `-W error` ; Python 3.13.16) :
- `edgia-core doctor` : diagnostic de la machine et de la configuration (Python, dépendances, bibliothèques d'IA, GPU si
  PyTorch est présent, mémoire, espace disque, port, taille du modèle comparée à la mémoire, réglages risqués) ; code de sortie 2
  en cas de blocage ; testé avec des mesures simulées (aucune machine de production n'a été diagnostiquée) ;
- `edgia-core backup` / `backup --verify` : sauvegarde cohérente des bases SQLite (registre, base documentaire) pendant que
  le serveur écrit, avec sommes SHA-256 et contrôle d'intégrité ; corruption détectée ; rien n'est écrasé ;
- test de cohérence : toute variable de configuration est documentée dans `.env.example` et inversement.

**Écrit mais JAMAIS exécuté** : `Dockerfile` (image, vérification de santé, démarrage du serveur), `compose.yaml`
(volumes, GPU en commentaire), `deploy/edgia-core.service`, `deploy/Caddyfile.example`, `deploy/nginx.conf.example`.
Procédures de `docs/DEPLOIEMENT.md` et `docs/EXPLOITATION.md` (restauration, changement de version, rotation des clés) :
décrites, non répétées sur un vrai serveur.

**Constat important pour le dimensionnement** : le chargeur actuel n'a ni quantification ni répartition sur plusieurs GPU ; un
modèle de 27-32 milliards en 16 bits (≈ 54-64 Go de poids) exige donc un GPU de 80 Go. Les chiffres « 24 Go en 4 bits » de
`MODELES_CANDIDATS.md` ne s'appliquent pas tant que la quantification n'est pas prise en charge. Calculs, pas mesures.

**Pas prévu dans cette version** : métriques et alertes, rechargement à chaud, haute disponibilité, limite de débit partagée,
test de charge, restauration automatique.

## Phase 8 — compte rendu

**Fonctionnel et testé** (Python 3.13.16, Node 22, tests `unittest` en `-W error`) :
- `docs/openapi.yaml` (OpenAPI 3.1 écrit à la main) tenu cohérent avec le code par des tests (routes, codes d'erreur, champs de requête) ;
- commande `edgia-core contract-check` (10 vérifications HTTP ; `--expect-real` échoue sur un serveur de démonstration ; clé lue dans une variable d'environnement) ;
- client Node de référence `integration/edgia-core-client.mjs` (réponse complète, flux, recherche, erreurs typées, refus du mode démonstration par défaut), exécuté contre un vrai serveur par `tests/integration/test_node_client.py` ;
- `docs/INTEGRATION.md` (règles pour l'application) et `docs/BILAN.md` (vérifié / non vérifié, liste de premier lancement).

**NON vérifié** : toute intégration avec le code réel de l'application EDG-IA (non vu) ; les noms `AI_*` et l'esquisse TypeScript sont à contrôler ; aucun modèle réel.

**Ajout (code de l'application reçu)** : `ai-provider.ts` lu en lecture seule ; la branche `openai-compatible` est compatible, avec 4 pièges documentés dans `docs/INTEGRATION.md` (démo non détectée, `max_tokens` 1400 > 512 → 422, délai 30 s, sources). Patch additif fourni dans `integration/app-patch/`, **non appliqué**. Testé sur une copie du fournisseur contre Core de démonstration uniquement.

## Phase 09 — Custom Transformer Engine (prototype)

**État : prototype ajouté, tests ciblés réussis; pas encore entraîné sur un corpus.**

Ajouts: `custom_model/` (tokeniseur byte-level, Transformer decoder causal, Dataset texte,
script d'entraînement PyTorch avec checkpoints/reprise), config `configs/model/edgia_transformer_small.json`,
tests `tests/unit/test_custom_transformer.py`, guide `docs/PHASE_09_CUSTOM_TRANSFORMER.md`.

Validation du 04/11/2026 dans l'environnement de développement: 4 tests ciblés réussis; suite complète
346 réussis, 14 échecs liés au sandbox d'exécution de code indisponible/partiellement fonctionnel.
Aucun poids de modèle pré-entraîné n'est inclus. Les poids du prototype sont aléatoires au démarrage.
et il doit être entraîné sur des données autorisées avant de pouvoir produire du texte utile.
