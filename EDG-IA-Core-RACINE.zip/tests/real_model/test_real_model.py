"""Validation sur un VRAI modèle. Ignoré tant que EDGIA_REAL_MODEL_DESCRIPTOR n'est pas défini.

ÉTAT : ce test n'a JAMAIS été exécuté (aucun modèle ni PyTorch dans l'environnement de développement). C'est le
premier test à lancer sur la machine de l'équipe d'entraînement, une fois les poids livrés :

    pip install torch transformers          # (+ peft si adaptateur LoRA)
    EDGIA_REAL_MODEL_DESCRIPTOR=configs/model.yaml PYTHONPATH=src \\
        python3 -m unittest discover -s tests/real_model -v

Il vérifie que le modèle se charge, répond, respecte les limites, s'interrompt et diffuse en continu. Il ne mesure
PAS la qualité des réponses : c'est le rôle des évaluations (phase 5).
"""

from __future__ import annotations

import asyncio
import os
import threading
import time
import unittest
from pathlib import Path

DESCRIPTOR = os.environ.get("EDGIA_REAL_MODEL_DESCRIPTOR")


@unittest.skipUnless(DESCRIPTOR, "EDGIA_REAL_MODEL_DESCRIPTOR non défini : aucun vrai modèle à tester")
class RealModelTest(unittest.TestCase):
    engine = None

    @classmethod
    def setUpClass(cls) -> None:
        from edgia_core.config import build_serving_report, load_settings
        from edgia_core.model.loader import build_engine

        settings = load_settings(
            env={"EDGIA_MODE": "real", "EDGIA_AUTH_ENABLED": "false", "EDGIA_MODEL_DESCRIPTOR": str(Path(DESCRIPTOR))}
        )
        report = build_serving_report(settings)
        if not report.ok:
            raise AssertionError("Descripteur refusé : " + " ; ".join(report.problems))
        started = time.monotonic()
        cls.engine = build_engine(settings, report.descriptor)
        print(f"\nChargement du modèle : {time.monotonic() - started:.1f} s")

    @classmethod
    def tearDownClass(cls) -> None:
        if cls.engine is not None:
            cls.engine.close()

    def messages(self, text: str):
        from edgia_core.inference.base import Message

        return [Message("user", text)]

    def params(self, **kwargs):
        from edgia_core.inference.base import GenerationParams

        return GenerationParams(**{"max_tokens": 64, "temperature": 0.0, **kwargs})

    def test_answers_in_french(self) -> None:
        started = time.monotonic()
        result = self.engine.generate(self.messages("Explique en deux phrases ce qu'est une fraction."), self.params())
        print(f"\nRéponse ({result.completion_tokens} tokens, {time.monotonic() - started:.1f} s) : {result.text}")
        self.assertTrue(result.text.strip())
        self.assertGreater(result.prompt_tokens, 0)
        self.assertIn(result.finish_reason, ("stop", "length"))

    def test_max_tokens_is_respected(self) -> None:
        result = self.engine.generate(self.messages("Raconte une longue histoire."), self.params(max_tokens=8))
        self.assertLessEqual(result.completion_tokens, 8)

    def test_stream_matches_final_text(self) -> None:
        async def collect():
            return [c async for c in self.engine.stream(self.messages("Dis bonjour."), self.params(max_tokens=16))]

        chunks = asyncio.run(collect())
        self.assertTrue("".join(c.text for c in chunks).strip())
        self.assertIsNotNone(chunks[-1].finish_reason)

    def test_cancel_interrupts_generation(self) -> None:
        from edgia_core.inference.base import EngineError

        cancel = threading.Event()
        threading.Timer(0.5, cancel.set).start()
        started = time.monotonic()
        with self.assertRaises(EngineError):
            self.engine.generate(self.messages("Écris un très long texte."), self.params(max_tokens=2000), cancel)
        self.assertLess(time.monotonic() - started, 30)


if __name__ == "__main__":
    unittest.main()
