# Tests nécessitant un vrai modèle et/ou un GPU

Ce dossier est volontairement séparé de `tests/unit/`.

- `tests/unit/` : s'exécute partout, sans réseau, sans poids, sans GPU. C'est ce que lance `scripts/run_tests.sh`.
- `tests/real_model/` : réservé aux tests qui chargent les vrais poids livrés par l'équipe d'entraînement
  (marqueurs pytest `real_model` et `gpu`). **Aucun test n'y est écrit en phase 1** : il n'existe pas encore de
  poids à tester. Ils seront ajoutés en phase 3 et ne seront jamais lancés par défaut.
