"""Test de FUMÉE du backend Transformers avec de FAUSSES bibliothèques.

Ce test vérifie seulement l'enchaînement des appels et la logique de fin de génération. Il ne prouve PAS que le
backend fonctionne avec le vrai PyTorch / le vrai Transformers : les noms d'API y sont ceux que j'ai supposés.
La vraie validation est le premier chargement d'un vrai modèle (voir docs/GUIDE_SPECIALISTES.md).
"""

from __future__ import annotations

import queue
import sys
import tempfile
import threading
import types
import unittest
from pathlib import Path
from unittest import mock

from edgia_core.errors import ConfigurationError
from edgia_core.inference.base import GenerationParams, Message
from edgia_core.inference.llm_engine import Done, LanguageModelEngine, Piece
from edgia_core.inference.base import ModelInfo
from edgia_core.model.descriptor import ModelDescriptor

EOS = 2


class FakeTensor:
    def __init__(self, shape: tuple[int, ...], last: int = 0) -> None:
        self.shape = shape
        self._last = last

    def to(self, device: str) -> FakeTensor:
        return self

    def __getitem__(self, index):  # type: ignore[no-untyped-def]
        return self._last


def build_fake_libs(*, hit_limit: bool = False, fail: bool = False, chat_template: str | None = "tpl"):
    calls: dict[str, object] = {"model_kwargs": [], "generate_kwargs": None}

    class FakeStreamer:
        def __init__(self, tokenizer, **kwargs):  # type: ignore[no-untyped-def]
            self.queue: queue.Queue = queue.Queue()

        def put_text(self, text: str) -> None:
            self.queue.put(text)

        def end(self) -> None:
            self.queue.put(None)

        def __iter__(self):  # type: ignore[no-untyped-def]
            while True:
                item = self.queue.get()
                if item is None:
                    return
                yield item

    class FakeModel:
        generation_config = types.SimpleNamespace(eos_token_id=EOS)

        def eval(self) -> None:
            pass

        def to(self, device: str) -> FakeModel:
            calls["device"] = device
            return self

        def generate(self, **kwargs):  # type: ignore[no-untyped-def]
            calls["generate_kwargs"] = kwargs
            if fail:
                raise RuntimeError("panne GPU simulée")
            for piece in ("Bon", "jour"):
                kwargs["streamer"].put_text(piece)
            max_new = kwargs["max_new_tokens"]
            generated = max_new if hit_limit else 2
            return FakeTensor((1, 5 + generated), last=7 if hit_limit else EOS)

    class FakeTokenizer:
        pad_token_id = None
        eos_token_id = EOS

        def __init__(self) -> None:
            self.chat_template = chat_template

        def apply_chat_template(self, messages, tokenize, add_generation_prompt):  # type: ignore[no-untyped-def]
            assert tokenize is False and add_generation_prompt is True
            return "|".join(m["role"] for m in messages)

        def __call__(self, text, add_special_tokens, return_tensors=None):  # type: ignore[no-untyped-def]
            assert add_special_tokens is False
            if return_tensors == "pt":
                return {"input_ids": FakeTensor((1, 5)), "attention_mask": FakeTensor((1, 5))}
            return {"input_ids": list(range(5))}

    class AutoModelForCausalLM:
        @staticmethod
        def from_pretrained(path, **kwargs):  # type: ignore[no-untyped-def]
            calls["model_kwargs"].append(kwargs)  # type: ignore[union-attr]
            return FakeModel()

    class AutoTokenizer:
        @staticmethod
        def from_pretrained(path, **kwargs):  # type: ignore[no-untyped-def]
            calls["tokenizer_kwargs"] = kwargs
            return FakeTokenizer()

    transformers = types.SimpleNamespace(
        AutoModelForCausalLM=AutoModelForCausalLM,
        AutoTokenizer=AutoTokenizer,
        TextIteratorStreamer=FakeStreamer,
        StoppingCriteria=type("StoppingCriteria", (), {}),
        StoppingCriteriaList=list,
    )

    class _NoGrad:
        def __enter__(self) -> None:
            return None

        def __exit__(self, *exc: object) -> bool:
            return False

    torch = types.SimpleNamespace(
        cuda=types.SimpleNamespace(is_available=lambda: False, empty_cache=lambda: None),
        no_grad=_NoGrad,
        full=lambda shape, value, dtype, device: ("full", shape, value),
        bool="bool",
    )
    return torch, transformers, calls


class HfBackendSmokeTest(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        root = Path(self._tmp.name)
        (root / "weights").mkdir()
        (root / "weights" / "config.json").write_text("{}", encoding="utf-8")
        (root / "weights" / "model.safetensors").write_bytes(b"x")
        (root / "tok").mkdir()
        self.root = root

    def descriptor(self, **overrides) -> ModelDescriptor:  # type: ignore[no-untyped-def]
        data = {
            "model_id": "edgia-test",
            "version": "1",
            "weights_path": self.root / "weights",
            "tokenizer_path": self.root / "tok",
            "weights_format": "safetensors",
            "runtime": "transformers",
            "license": {"name": "t", "commercial_use_allowed": True, "reviewed": True},
        }
        data.update(overrides)
        return ModelDescriptor.model_validate(data)

    def engine(self, descriptor: ModelDescriptor, **fake_options):  # type: ignore[no-untyped-def]
        torch, transformers, calls = build_fake_libs(**fake_options)
        with mock.patch.dict(sys.modules, {"torch": torch, "transformers": transformers}):
            from edgia_core.inference.hf_backend import HuggingFaceBackend

            backend = HuggingFaceBackend(descriptor)
        info = ModelInfo(id="edgia-test", version="1", runtime="transformers", is_demo=False)
        return LanguageModelEngine(info, backend), calls

    def test_loading_is_local_and_safe(self) -> None:
        _, calls = self.engine(self.descriptor())
        self.assertTrue(calls["tokenizer_kwargs"]["local_files_only"])
        self.assertFalse(calls["tokenizer_kwargs"]["trust_remote_code"])
        kwargs = calls["model_kwargs"][0]
        self.assertTrue(kwargs["local_files_only"])
        self.assertFalse(kwargs["trust_remote_code"])
        self.assertTrue(kwargs["use_safetensors"])

    def test_generation_flow_and_natural_finish(self) -> None:
        engine, calls = self.engine(self.descriptor())
        messages = [Message("system", "s"), Message("user", "u")]
        self.assertEqual(engine.count_tokens(messages), 5)
        result = engine.generate(messages, GenerationParams(max_tokens=10, temperature=0.5, top_p=0.9))
        self.assertEqual(result.text, "Bonjour")
        self.assertEqual(result.finish_reason, "stop")
        self.assertEqual(result.completion_tokens, 2)
        kwargs = calls["generate_kwargs"]
        self.assertEqual(kwargs["max_new_tokens"], 10)
        self.assertTrue(kwargs["do_sample"])
        self.assertEqual((kwargs["temperature"], kwargs["top_p"]), (0.5, 0.9))

    def test_zero_temperature_disables_sampling(self) -> None:
        engine, calls = self.engine(self.descriptor())
        engine.generate([Message("user", "u")], GenerationParams(max_tokens=10, temperature=0.0))
        self.assertFalse(calls["generate_kwargs"]["do_sample"])
        self.assertNotIn("temperature", calls["generate_kwargs"])

    def test_length_finish_when_limit_is_hit_without_eos(self) -> None:
        engine, _ = self.engine(self.descriptor(), hit_limit=True)
        result = engine.generate([Message("user", "u")], GenerationParams(max_tokens=4))
        self.assertEqual(result.finish_reason, "length")

    def test_generation_failure_is_reported_without_details(self) -> None:
        from edgia_core.inference.base import EngineError

        engine, _ = self.engine(self.descriptor(), fail=True)
        with self.assertRaises(EngineError) as ctx:
            engine.generate([Message("user", "u")], GenerationParams(max_tokens=4))
        self.assertIn("RuntimeError", str(ctx.exception))
        self.assertNotIn("GPU", str(ctx.exception))

    def test_missing_chat_template_is_refused(self) -> None:
        with self.assertRaises(ConfigurationError) as ctx:
            self.engine(self.descriptor(), chat_template=None)
        self.assertIn("chat_template", str(ctx.exception))

    def test_weights_must_be_a_directory_with_config(self) -> None:
        single = self.root / "model.safetensors"
        single.write_bytes(b"x")
        with self.assertRaises(ConfigurationError):
            self.engine(self.descriptor(weights_path=single))

    def test_lora_without_adapter_path_is_refused(self) -> None:
        with self.assertRaises(ConfigurationError):
            self.engine(self.descriptor(adaptation={"method": "lora"}))

    def test_missing_dependencies_give_an_explicit_error(self) -> None:
        for name in ("torch", "transformers"):
            sys.modules.pop(name, None)
        with mock.patch.dict(sys.modules, {"torch": None, "transformers": None}):
            from edgia_core.inference.hf_backend import HuggingFaceBackend

            with self.assertRaises(ConfigurationError) as ctx:
                HuggingFaceBackend(self.descriptor())
        self.assertIn("Dépendance absente", str(ctx.exception))

    def test_generations_are_serialized(self) -> None:
        engine, calls = self.engine(self.descriptor())
        active = {"now": 0, "max": 0}
        lock = threading.Lock()
        model = engine._backend._model
        original = model.generate

        def tracked(**kwargs):  # type: ignore[no-untyped-def]
            with lock:
                active["now"] += 1
                active["max"] = max(active["max"], active["now"])
            try:
                import time

                time.sleep(0.05)
                return original(**kwargs)
            finally:
                with lock:
                    active["now"] -= 1

        model.generate = tracked
        threads = [
            threading.Thread(target=engine.generate, args=([Message("user", "u")], GenerationParams(max_tokens=4)))
            for _ in range(3)
        ]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        self.assertEqual(active["max"], 1)

    def test_backend_never_sets_the_callers_cancel_event(self) -> None:
        """Régression : une génération normale ne doit pas être prise pour une annulation."""
        engine, _ = self.engine(self.descriptor())
        cancel = threading.Event()
        engine.generate([Message("user", "u")], GenerationParams(max_tokens=4), cancel)
        self.assertFalse(cancel.is_set())

    def test_pieces_and_done_types(self) -> None:
        engine, _ = self.engine(self.descriptor())
        items = list(engine._backend.stream([Message("user", "u")], GenerationParams(max_tokens=4), threading.Event()))
        self.assertIsInstance(items[-1], Done)
        self.assertTrue(all(isinstance(i, Piece) for i in items[:-1]))


if __name__ == "__main__":
    unittest.main()
