"""Tests de l'API HTTP via un client ASGI (aucun réseau, aucun modèle, aucun GPU)."""

from __future__ import annotations

import asyncio
import json
import logging
import unittest

from edgia_core.api.app import AUTH_FAILURES_PER_MINUTE, create_app
from edgia_core.config import DEMO_NOTICE
from edgia_core.errors import ConfigurationError
from edgia_core.inference.base import GenerationParams, GenerationResult, InferenceEngine, Message, ModelInfo
from edgia_core.inference.demo import DEMO_MODEL_ID, DemoEngine
from tests.helpers import API_KEY, OTHER_KEY, auth, chat_body, make_settings, request

CHAT = "/v1/chat/completions"


class ApiTestCase(unittest.IsolatedAsyncioTestCase):
    def build(self, engine: InferenceEngine | None = None, **settings: str):
        app = create_app(make_settings(**settings), engine)
        self.addCleanup(app.state.ctx.close)
        return app

    def assertError(self, response, status: int, code: str) -> dict:
        self.assertEqual(response.status, status, response.text)
        error = response.json()["error"]
        self.assertEqual(error["code"], code)
        self.assertIn("type", error)
        self.assertTrue(error["message"])
        return error


class HealthTest(ApiTestCase):
    async def test_health_needs_no_authentication(self) -> None:
        response = await request(self.build(), "GET", "/health")
        self.assertEqual(response.status, 200)
        self.assertEqual(response.json()["status"], "ok")

    async def test_ready_in_demo_mode(self) -> None:
        response = await request(self.build(), "GET", "/ready")
        self.assertEqual(response.status, 200)
        body = response.json()
        self.assertEqual(body["status"], "ready")
        self.assertTrue(body["demo"])

    async def test_ready_is_503_when_model_is_not_ready(self) -> None:
        class NotReady(DemoEngine):
            def is_ready(self) -> bool:
                return False

        app = self.build(NotReady())
        self.assertError(await request(app, "GET", "/ready"), 503, "model_unavailable")
        self.assertError(await request(app, "POST", CHAT, headers=auth(), json_body=chat_body()), 503, "model_unavailable")

    async def test_every_response_has_request_id_and_security_headers(self) -> None:
        response = await request(self.build(), "GET", "/health")
        self.assertEqual(len(response.headers["x-request-id"]), 32)
        self.assertEqual(response.headers["cache-control"], "no-store")
        self.assertEqual(response.headers["x-content-type-options"], "nosniff")

    async def test_request_ids_are_unique(self) -> None:
        app = self.build()
        ids = {(await request(app, "GET", "/health")).headers["x-request-id"] for _ in range(5)}
        self.assertEqual(len(ids), 5)


class RoutingErrorsTest(ApiTestCase):
    async def test_unknown_route_is_json_404(self) -> None:
        response = await request(self.build(), "GET", "/inconnu")
        self.assertError(response, 404, "not_found")
        self.assertIn("x-request-id", response.headers)

    async def test_wrong_method_is_json_405(self) -> None:
        response = await request(self.build(), "GET", CHAT, headers=auth())
        self.assertError(response, 405, "method_not_allowed")
        self.assertIn("POST", response.headers.get("allow", ""))


class ModelsTest(ApiTestCase):
    async def test_requires_authentication(self) -> None:
        response = await request(self.build(), "GET", "/v1/models")
        self.assertError(response, 401, "unauthorized")
        self.assertEqual(response.headers["www-authenticate"], "Bearer")

    async def test_lists_the_demo_model_and_flags_it(self) -> None:
        response = await request(self.build(), "GET", "/v1/models", headers=auth())
        self.assertEqual(response.status, 200)
        body = response.json()
        self.assertEqual(body["object"], "list")
        self.assertEqual(len(body["data"]), 1)
        model = body["data"][0]
        self.assertEqual(model["id"], DEMO_MODEL_ID)
        self.assertTrue(model["edgia"]["demo"])
        self.assertEqual(model["edgia"]["notice"], DEMO_NOTICE)
        self.assertTrue(model["edgia"]["ready"])


class AuthenticationTest(ApiTestCase):
    async def test_wrong_key_is_refused_without_echoing_it(self) -> None:
        wrong = "cle-erronee-" + "z" * 20
        response = await request(self.build(), "POST", CHAT, headers=auth(wrong), json_body=chat_body())
        self.assertError(response, 401, "unauthorized")
        self.assertNotIn(wrong, response.text)

    async def test_missing_and_malformed_headers_are_refused(self) -> None:
        app = self.build()
        for headers in ({}, {"Authorization": API_KEY}, {"Authorization": f"Basic {API_KEY}"}, {"Authorization": "Bearer"}):
            response = await request(app, "POST", CHAT, headers=headers, json_body=chat_body())
            self.assertError(response, 401, "unauthorized")

    async def test_authentication_runs_before_body_validation(self) -> None:
        response = await request(self.build(), "POST", CHAT, body=b"pas du json", headers={"Content-Type": "text/plain"})
        self.assertError(response, 401, "unauthorized")

    async def test_repeated_failures_lock_the_client_out(self) -> None:
        app = self.build()
        for _ in range(AUTH_FAILURES_PER_MINUTE):
            self.assertError(await request(app, "GET", "/v1/models", headers=auth(OTHER_KEY)), 401, "unauthorized")
        locked = await request(app, "GET", "/v1/models", headers=auth(OTHER_KEY))
        self.assertError(locked, 429, "rate_limited")
        self.assertGreaterEqual(int(locked.headers["retry-after"]), 1)

    async def test_lockout_is_per_client_address(self) -> None:
        app = self.build()
        for _ in range(AUTH_FAILURES_PER_MINUTE):
            await request(app, "GET", "/v1/models", headers=auth(OTHER_KEY))
        other_client = await request(app, "GET", "/v1/models", headers=auth(), client=("198.51.100.7", 1))
        self.assertEqual(other_client.status, 200)

    async def test_auth_can_be_disabled_on_loopback(self) -> None:
        app = create_app(make_settings(auth_enabled="false"))
        self.addCleanup(app.state.ctx.close)
        response = await request(app, "POST", CHAT, json_body=chat_body())
        self.assertEqual(response.status, 200, response.text)


class ChatCompletionTest(ApiTestCase):
    async def test_happy_path(self) -> None:
        response = await request(self.build(), "POST", CHAT, headers=auth(), json_body=chat_body("Bonjour le monde"))
        self.assertEqual(response.status, 200, response.text)
        self.assertEqual(response.headers["content-type"], "application/json")
        body = response.json()
        self.assertEqual(body["object"], "chat.completion")
        self.assertTrue(body["id"].startswith("chatcmpl-"))
        self.assertEqual(body["model"], DEMO_MODEL_ID)
        choice = body["choices"][0]
        self.assertEqual(choice["message"]["role"], "assistant")
        self.assertIn("PAS générée par le modèle EDG-IA entraîné", choice["message"]["content"])
        self.assertEqual(choice["finish_reason"], "stop")
        usage = body["usage"]
        self.assertEqual(usage["prompt_tokens"], 3)
        self.assertEqual(usage["total_tokens"], usage["prompt_tokens"] + usage["completion_tokens"])
        self.assertTrue(body["edgia"]["demo"])
        self.assertEqual(body["edgia"]["notice"], DEMO_NOTICE)

    async def test_explicit_model_id_is_accepted(self) -> None:
        response = await request(
            self.build(), "POST", CHAT, headers=auth(), json_body=chat_body(model=DEMO_MODEL_ID, temperature=0, top_p=0.5)
        )
        self.assertEqual(response.status, 200, response.text)

    async def test_max_tokens_is_honored(self) -> None:
        response = await request(self.build(), "POST", CHAT, headers=auth(), json_body=chat_body(max_tokens=2))
        body = response.json()
        self.assertEqual(body["choices"][0]["finish_reason"], "length")
        self.assertEqual(body["usage"]["completion_tokens"], 2)

    async def test_unknown_model_is_404(self) -> None:
        response = await request(self.build(), "POST", CHAT, headers=auth(), json_body=chat_body(model="gpt-autre"))
        self.assertError(response, 404, "model_not_found")


class ValidationTest(ApiTestCase):
    async def post(self, **kwargs):
        return await request(self.build(), "POST", CHAT, headers=kwargs.pop("headers", auth()), **kwargs)

    async def test_invalid_json_is_400(self) -> None:
        response = await self.post(body=b"{pas du json", headers={**auth(), "Content-Type": "application/json"})
        self.assertError(response, 400, "invalid_json")

    async def test_invalid_utf8_is_400(self) -> None:
        response = await self.post(body=b"\xff\xfe\x00", headers={**auth(), "Content-Type": "application/json"})
        self.assertError(response, 400, "invalid_json")

    async def test_deeply_nested_json_is_400_not_500(self) -> None:
        response = await self.post(body=b"[" * 100_000, headers={**auth(), "Content-Type": "application/json"})
        self.assertError(response, 400, "invalid_json")

    async def test_wrong_content_type_is_415(self) -> None:
        response = await self.post(body=b"{}", headers={**auth(), "Content-Type": "text/plain"})
        self.assertError(response, 415, "unsupported_media_type")
        response = await self.post(body=b"{}", headers=auth())
        self.assertError(response, 415, "unsupported_media_type")

    async def test_content_type_with_charset_is_accepted(self) -> None:
        body = json.dumps(chat_body()).encode()
        response = await self.post(body=body, headers={**auth(), "Content-Type": "application/json; charset=utf-8"})
        self.assertEqual(response.status, 200, response.text)

    async def test_json_that_is_not_an_object_is_422(self) -> None:
        for payload in ([], "texte", 42, None):
            response = await self.post(body=json.dumps(payload).encode(), headers={**auth(), "Content-Type": "application/json"})
            self.assertError(response, 422, "invalid_request")

    async def test_invalid_payloads_are_422(self) -> None:
        invalid = [
            {},
            {"messages": []},
            {"messages": "bonjour"},
            {"messages": [{"role": "robot", "content": "x"}]},
            {"messages": [{"role": "user"}]},
            {"messages": [{"role": "user", "content": 12}]},
            {"messages": [{"role": "user", "content": "x", "extra": 1}]},
            chat_body(inconnu=True),
            chat_body(temperature=3),
            chat_body(temperature="0.5"),
            chat_body(top_p=0),
            chat_body(max_tokens=0),
            chat_body(max_tokens=1.5),
            chat_body(stream="oui"),
            chat_body(stop=["a", "b", "c", "d", "e"]),
            chat_body(stop=[""]),
            chat_body(model=""),
        ]
        app = self.build()
        for payload in invalid:
            response = await request(app, "POST", CHAT, headers=auth(), json_body=payload)
            self.assertError(response, 422, "invalid_request")

    async def test_validation_errors_never_echo_client_content(self) -> None:
        marker = "CONTENU-CONFIDENTIEL-9731"
        payload = chat_body(marker, temperature=99)
        response = await self.post(json_body=payload)
        self.assertError(response, 422, "invalid_request")
        self.assertNotIn(marker, response.text)
        self.assertIn("temperature", response.json()["error"]["message"])


class LimitsTest(ApiTestCase):
    async def test_too_many_messages_is_422(self) -> None:
        app = self.build(max_messages="2")
        messages = [{"role": "user", "content": "a"}] * 3
        self.assertError(await request(app, "POST", CHAT, headers=auth(), json_body={"messages": messages}), 422, "invalid_request")
        self.assertEqual((await request(app, "POST", CHAT, headers=auth(), json_body={"messages": messages[:2]})).status, 200)

    async def test_message_too_long_is_422(self) -> None:
        app = self.build(max_message_chars="10")
        self.assertError(await request(app, "POST", CHAT, headers=auth(), json_body=chat_body("x" * 11)), 422, "invalid_request")
        self.assertEqual((await request(app, "POST", CHAT, headers=auth(), json_body=chat_body("x" * 10))).status, 200)

    async def test_max_tokens_above_server_limit_is_422(self) -> None:
        app = self.build(max_new_tokens="50", max_context_tokens="1000")
        self.assertError(await request(app, "POST", CHAT, headers=auth(), json_body=chat_body(max_tokens=51)), 422, "invalid_request")
        self.assertEqual((await request(app, "POST", CHAT, headers=auth(), json_body=chat_body(max_tokens=50))).status, 200)

    async def test_context_window_is_enforced(self) -> None:
        app = self.build(max_context_tokens="128", max_new_tokens="64")
        long_prompt = " ".join(["mot"] * 100)
        response = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body(long_prompt))
        self.assertError(response, 422, "context_length_exceeded")
        self.assertEqual((await request(app, "POST", CHAT, headers=auth(), json_body=chat_body("court"))).status, 200)

    async def test_oversized_body_with_content_length_is_413(self) -> None:
        app = self.build(max_request_bytes="1024")
        response = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body("x" * 5000))
        self.assertError(response, 413, "request_too_large")

    async def test_oversized_chunked_body_without_content_length_is_413(self) -> None:
        app = self.build(max_request_bytes="1024")
        pieces = [b'{"messages":[{"role":"user","content":"', b"x" * 600, b"x" * 600, b'"}]}']
        response = await request(
            app, "POST", CHAT, headers={**auth(), "Content-Type": "application/json"}, body_chunks=pieces
        )
        self.assertError(response, 413, "request_too_large")

    async def test_invalid_content_length_is_400(self) -> None:
        response = await request(
            self.build(), "POST", CHAT, headers={**auth(), "Content-Type": "application/json", "Content-Length": "abc"}, body=b"{}"
        )
        self.assertError(response, 400, "invalid_request")

    async def test_rate_limit_returns_429_with_retry_after(self) -> None:
        app = self.build(rate_limit_per_minute="2")
        for _ in range(2):
            self.assertEqual((await request(app, "GET", "/v1/models", headers=auth())).status, 200)
        limited = await request(app, "GET", "/v1/models", headers=auth())
        self.assertError(limited, 429, "rate_limited")
        self.assertGreaterEqual(int(limited.headers["retry-after"]), 1)

    async def test_rate_limit_can_be_disabled(self) -> None:
        app = self.build(rate_limit_enabled="false", rate_limit_per_minute="1")
        for _ in range(5):
            self.assertEqual((await request(app, "GET", "/v1/models", headers=auth())).status, 200)


class StreamingTest(ApiTestCase):
    async def test_stream_is_sse_and_matches_non_stream(self) -> None:
        app = self.build()
        plain = (await request(app, "POST", CHAT, headers=auth(), json_body=chat_body("Salut"))).json()
        streamed = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body("Salut", stream=True))
        self.assertEqual(streamed.status, 200, streamed.text)
        self.assertTrue(streamed.headers["content-type"].startswith("text/event-stream"))
        self.assertEqual(streamed.headers["cache-control"], "no-store")

        events = streamed.sse_events()
        self.assertEqual(events[-1], "[DONE]")
        chunks = [json.loads(e) for e in events[:-1]]
        self.assertTrue(all(c["object"] == "chat.completion.chunk" for c in chunks))
        self.assertEqual(chunks[0]["choices"][0]["delta"], {"role": "assistant"})
        text = "".join(c["choices"][0]["delta"].get("content", "") for c in chunks)
        self.assertEqual(text, plain["choices"][0]["message"]["content"])
        final = chunks[-1]
        self.assertEqual(final["choices"][0]["finish_reason"], "stop")
        self.assertEqual(final["usage"]["completion_tokens"], plain["usage"]["completion_tokens"])
        self.assertTrue(final["edgia"]["demo"])

    async def test_stream_reports_length_finish(self) -> None:
        streamed = await request(self.build(), "POST", CHAT, headers=auth(), json_body=chat_body(stream=True, max_tokens=2))
        final = json.loads(streamed.sse_events()[-2])
        self.assertEqual(final["choices"][0]["finish_reason"], "length")

    async def test_streaming_can_be_disabled(self) -> None:
        app = self.build(streaming_enabled="false")
        self.assertError(await request(app, "POST", CHAT, headers=auth(), json_body=chat_body(stream=True)), 400, "streaming_disabled")
        self.assertEqual((await request(app, "POST", CHAT, headers=auth(), json_body=chat_body())).status, 200)

    async def test_engine_without_streaming_support_is_refused(self) -> None:
        class NoStream(DemoEngine):
            supports_streaming = False

        app = self.build(NoStream())
        response = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body(stream=True))
        self.assertError(response, 400, "streaming_unsupported")

    async def test_slot_is_released_after_stream(self) -> None:
        app = self.build()
        await request(app, "POST", CHAT, headers=auth(), json_body=chat_body(stream=True))
        self.assertEqual(app.state.ctx.gate.in_flight, 0)

    async def test_stream_timeout_emits_error_event(self) -> None:
        app = self.build(DemoEngine(delay_seconds=0.5), request_timeout_seconds="0.1")
        streamed = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body(stream=True))
        events = streamed.sse_events()
        self.assertEqual(json.loads(events[-1])["error"]["code"], "generation_timeout")
        self.assertNotIn("[DONE]", events)
        self.assertEqual(app.state.ctx.gate.in_flight, 0)

    async def test_stream_engine_failure_emits_generic_error_event(self) -> None:
        class Failing(DemoEngine):
            async def stream(self, messages, params):  # type: ignore[no-untyped-def]
                raise RuntimeError("détail interne SECRET-INTERNE")
                yield  # pragma: no cover

        app = self.build(Failing())
        with self.assertLogs("edgia_core.api", level="ERROR") as logs:
            streamed = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body(stream=True))
        self.assertNotIn("SECRET-INTERNE", streamed.text)
        self.assertNotIn("SECRET-INTERNE", "\n".join(logs.output))
        self.assertEqual(json.loads(streamed.sse_events()[-1])["error"]["code"], "internal_error")


class ConcurrencyAndTimeoutTest(ApiTestCase):
    async def test_excess_concurrent_requests_get_503(self) -> None:
        app = self.build(DemoEngine(delay_seconds=0.3), max_concurrent_requests="1")
        first = asyncio.create_task(request(app, "POST", CHAT, headers=auth(), json_body=chat_body()))
        await asyncio.sleep(0.1)
        second = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body())
        self.assertError(second, 503, "server_busy")
        self.assertEqual(second.headers["retry-after"], "1")
        self.assertEqual((await first).status, 200)
        self.assertEqual(app.state.ctx.gate.in_flight, 0)
        self.assertEqual((await request(app, "POST", CHAT, headers=auth(), json_body=chat_body())).status, 200)

    async def test_timeout_is_504_and_slot_is_held_until_the_worker_ends(self) -> None:
        app = self.build(DemoEngine(delay_seconds=0.4), request_timeout_seconds="0.1", max_concurrent_requests="1")
        response = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body())
        self.assertError(response, 504, "generation_timeout")
        # Le thread tourne encore : la capacité n'est pas rendue tant qu'il n'a pas fini.
        self.assertEqual(app.state.ctx.gate.in_flight, 1)
        busy = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body())
        self.assertError(busy, 503, "server_busy")
        await asyncio.sleep(0.5)
        self.assertEqual(app.state.ctx.gate.in_flight, 0)

    async def test_engine_failure_is_a_generic_500(self) -> None:
        class Failing(DemoEngine):
            def generate(self, messages, params):  # type: ignore[no-untyped-def]
                raise RuntimeError("détail interne SECRET-INTERNE")

        app = self.build(Failing())
        with self.assertLogs("edgia_core.api", level="ERROR") as logs:
            response = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body())
        self.assertError(response, 500, "internal_error")
        self.assertNotIn("SECRET-INTERNE", response.text)
        self.assertNotIn("SECRET-INTERNE", "\n".join(logs.output))
        self.assertIn("RuntimeError", "\n".join(logs.output))
        self.assertEqual(app.state.ctx.gate.in_flight, 0)


class LoggingTest(ApiTestCase):
    async def test_content_is_never_logged_by_default(self) -> None:
        marker = "MESSAGE-PRIVE-4821"
        with self.assertLogs("edgia_core.api", level="DEBUG") as logs:
            await request(self.build(log_level="DEBUG"), "POST", CHAT, headers=auth(), json_body=chat_body(marker))
        joined = "\n".join(logs.output)
        self.assertNotIn(marker, joined)
        self.assertNotIn(API_KEY, joined)
        self.assertIn("status=200", joined)
        self.assertIn("key=key-1", joined)

    async def test_content_is_logged_only_when_redaction_is_disabled(self) -> None:
        marker = "MESSAGE-PRIVE-4821"
        app = self.build(log_level="DEBUG", log_redact_content="false")
        with self.assertLogs("edgia_core.api", level="DEBUG") as logs:
            await request(app, "POST", CHAT, headers=auth(), json_body=chat_body(marker))
        self.assertIn(marker, "\n".join(logs.output))

    async def test_control_characters_in_paths_cannot_forge_log_lines(self) -> None:
        with self.assertLogs("edgia_core.api", level="INFO") as logs:
            await request(self.build(), "GET", "/v1/models\nFAUSSE-LIGNE", headers=auth())
        for line in logs.output:
            self.assertEqual(len(line.splitlines()), 1)


class CorsTest(ApiTestCase):
    async def test_no_cors_headers_by_default(self) -> None:
        response = await request(self.build(), "GET", "/health", headers={"Origin": "https://exemple.org"})
        self.assertNotIn("access-control-allow-origin", response.headers)

    async def test_allowed_origin_only(self) -> None:
        app = self.build(allowed_origins="https://app.exemple.org")
        allowed = await request(app, "GET", "/health", headers={"Origin": "https://app.exemple.org"})
        self.assertEqual(allowed.headers["access-control-allow-origin"], "https://app.exemple.org")
        denied = await request(app, "GET", "/health", headers={"Origin": "https://autre.example"})
        self.assertNotIn("access-control-allow-origin", denied.headers)


class StartupTest(unittest.TestCase):
    def test_refuses_to_start_when_auth_is_enabled_without_keys(self) -> None:
        from edgia_core.config import load_settings

        with self.assertRaises(ConfigurationError) as ctx:
            create_app(load_settings(env={}))
        self.assertTrue(any("EDGIA_API_KEYS" in p for p in ctx.exception.problems))

    def test_real_mode_with_missing_model_refuses_to_start(self) -> None:
        settings = make_settings(mode="real", model_descriptor="/nonexistent/model.yaml")
        with self.assertRaises(ConfigurationError):
            create_app(settings)

    def test_real_mode_never_falls_back_to_the_demo_model(self) -> None:
        import tempfile
        from pathlib import Path

        import yaml

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "tok").mkdir()
            (root / "model.safetensors").write_bytes(b"faux-poids")
            descriptor = {
                "model_id": "edgia-test",
                "version": "1",
                "weights_path": "model.safetensors",
                "tokenizer_path": "tok",
                "weights_format": "safetensors",
                "runtime": "transformers",
                "license": {"name": "test", "commercial_use_allowed": True, "reviewed": True},
            }
            (root / "model.yaml").write_text(yaml.safe_dump(descriptor), encoding="utf-8")
            settings = make_settings(mode="real", model_descriptor=str(root / "model.yaml"))
            # Sans PyTorch (ou avec de faux poids), le chargement échoue : le serveur doit refuser de démarrer,
            # et surtout ne pas servir le modèle de démonstration à la place.
            with self.assertRaises(ConfigurationError) as ctx:
                create_app(settings)
        message = " ".join(ctx.exception.problems)
        self.assertTrue("Dépendance absente" in message or "Chargement du modèle impossible" in message or "weights_path" in message, message)

    def test_real_mode_accepts_an_injected_engine(self) -> None:
        """Le point d'extension de la phase 3 : un moteur réel fourni explicitement est servi tel quel."""
        import tempfile
        from pathlib import Path

        import yaml

        class FakeReal(InferenceEngine):
            @property
            def info(self) -> ModelInfo:
                return ModelInfo(id="edgia-test", version="1", runtime="transformers", is_demo=False)

            def is_ready(self) -> bool:
                return True

            def count_tokens(self, messages):  # type: ignore[no-untyped-def]
                return 1

            def generate(self, messages: list[Message], params: GenerationParams) -> GenerationResult:
                return GenerationResult("réponse de test", "stop", 1, 3)

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "tok").mkdir()
            (root / "w.safetensors").write_bytes(b"x")
            descriptor = {
                "model_id": "edgia-test",
                "version": "1",
                "weights_path": "w.safetensors",
                "tokenizer_path": "tok",
                "weights_format": "safetensors",
                "runtime": "transformers",
                "license": {"name": "test", "commercial_use_allowed": True, "reviewed": True},
            }
            (root / "m.yaml").write_text(yaml.safe_dump(descriptor), encoding="utf-8")
            app = create_app(make_settings(mode="real", model_descriptor=str(root / "m.yaml")), FakeReal())
            try:
                response = asyncio.run(request(app, "POST", CHAT, headers=auth(), json_body=chat_body()))
            finally:
                app.state.ctx.close()
        self.assertEqual(response.status, 200, response.text)
        body = response.json()
        self.assertEqual(body["model"], "edgia-test")
        self.assertFalse(body["edgia"]["demo"])
        self.assertNotIn("notice", body["edgia"])


if __name__ == "__main__":
    logging.disable(logging.NOTSET)
    unittest.main()
