"""Tests de la préparation des données d'adaptation (aucun entraînement, aucun modèle)."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from edgia_core.errors import ConfigurationError
from edgia_core.evaluation.schema import load_suite
from edgia_core.training.data import DataRecord, load_records
from edgia_core.training.pii import scrub
from edgia_core.training.prepare import PrepareOptions, prepare, write_outputs

ROOT = Path(__file__).resolve().parents[2]
SUITE = ROOT / "configs" / "eval" / "starter"


def rec(rid: str, user: str, answer: str, **extra) -> dict:
    base = {
        "id": rid,
        "messages": [{"role": "user", "content": user}, {"role": "assistant", "content": answer}],
        "source": "test",
        "license": "CC0-1.0",
        "origin": "synthetic",
    }
    base.update(extra)
    return base


def build(*items: dict) -> list[DataRecord]:
    return [DataRecord.model_validate(i) for i in items]


class SchemaTest(unittest.TestCase):
    def write(self, tmp: str, lines: list[str]) -> Path:
        path = Path(tmp) / "d.jsonl"
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return path

    def test_valid_and_invalid_lines_are_reported_without_content(self) -> None:
        secret = "CONTENU-CONFIDENTIEL-XYZ"
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write(
                tmp,
                [
                    json.dumps(rec("a", "question", "réponse")),
                    "pas du json " + secret,
                    json.dumps(rec("b", "q", secret, license="inconnue")),
                    json.dumps({**rec("c", "q", "r"), "extra": 1}),
                    json.dumps({**rec("d", "q", "r"), "messages": [{"role": "user", "content": "q"}, {"role": "user", "content": "q2"}]}),
                    json.dumps(rec("a", "autre", "doublon d'id")),
                    json.dumps(rec("e", "q", "r", origin="user_conversation")),
                    json.dumps(rec("Mauvais Id", "q", "r")),
                ],
            )
            records, problems = load_records([path])
        self.assertEqual([r.id for r in records], ["a"])
        self.assertEqual(len(problems), 7)
        self.assertNotIn(secret, " ".join(problems))
        text = " ".join(problems)
        for expected in ("ligne 2", "licence inconnue", "dupliqué", "consent", "identifiant invalide", "réponse de l'assistant"):
            self.assertIn(expected, text)

    def test_missing_file_is_a_configuration_error(self) -> None:
        with self.assertRaises(ConfigurationError):
            load_records([Path("/chemin/absent.jsonl")])

    def test_example_dataset_is_valid(self) -> None:
        records, problems = load_records([ROOT / "configs" / "data" / "exemple.jsonl"])
        self.assertEqual(problems, [])
        self.assertEqual(len(records), 4)


class PiiTest(unittest.TestCase):
    def test_scrub(self) -> None:
        text, report = scrub("Écris à awa@exemple.cm ou appelle le +237 6 99 12 34 56 ; IBAN FR76 3000 6000 0112 3456 7890 189.")
        self.assertNotIn("awa@", text)
        self.assertNotIn("99 12", text)
        self.assertNotIn("FR76", text)
        self.assertEqual(report.counts, {"email": 1, "numero": 1, "iban": 1})

    def test_amounts_and_small_numbers_are_kept(self) -> None:
        for text in ("Il paie 24 000 FCFA", "Total : 150 000 000 FCFA", "En 2025, 12 élèves ont 3,5 de moyenne", "15 × 12 = 180"):
            self.assertEqual(scrub(text)[0], text)

    def test_url_credentials(self) -> None:
        self.assertNotIn("motdepasse", scrub("ftp://admin:motdepasse@serveur.exemple/fichier")[0])


class PrepareTest(unittest.TestCase):
    def test_user_conversations_need_both_consent_and_explicit_permission(self) -> None:
        data = build(rec("u1", "bonjour tout le monde ici", "salut à toi aussi mon ami", origin="user_conversation", consent=True))
        self.assertEqual(prepare(data).rejected[0][0], "u1")
        self.assertIn("non autorisée", prepare(data).rejected[0][1])
        allowed = prepare(data, PrepareOptions(allow_user_conversations=True, val_fraction=0))
        self.assertEqual(len(allowed.train), 1)

    def test_pii_is_redacted_or_rejected(self) -> None:
        data = build(rec("p1", "Mon courriel est awa@exemple.cm, que faire ?", "Ne partagez pas votre courriel publiquement."))
        result = prepare(data, PrepareOptions(val_fraction=0))
        self.assertNotIn("awa@", json.dumps(result.train[0].model_dump()))
        self.assertEqual(result.pii["email"], 1)
        self.assertTrue(any("noms" in w for w in result.warnings))
        rejected = prepare(data, PrepareOptions(pii_mode="reject", val_fraction=0))
        self.assertEqual(rejected.rejected, [("p1", "données personnelles détectées")])

    def test_quality_filters(self) -> None:
        data = build(
            rec("q1", "question valable ici", "x"),
            rec("q2", "question valable ici deux", "a" * 60),
            rec("q3", "   ", "réponse"),
            rec("q4", "question trop longue", "mot " * 5000),
            rec("q5", "question normale pour test", "Une réponse tout à fait correcte et utile."),
        )
        result = prepare(data, PrepareOptions(val_fraction=0))
        self.assertEqual([r.id for r in result.train], ["q5"])
        reasons = dict(result.rejected)
        self.assertEqual(reasons["q1"], "réponse trop courte")
        self.assertEqual(reasons["q2"], "répétition anormale")
        self.assertEqual(reasons["q3"], "message vide")
        self.assertIn("trop long", reasons["q4"])

    def test_exact_and_near_duplicates(self) -> None:
        base = "Explique la photosynthèse aux élèves du collège avec un exemple concret tiré de la vie quotidienne au village, en insistant sur le rôle des feuilles, de la lumière, de l'eau puisée par les racines et du gaz carbonique présent dans l'air"
        answer = "Les plantes captent la lumière du soleil grâce à la chlorophylle contenue dans leurs feuilles vertes, puis elles utilisent cette énergie pour transformer l'eau puisée dans le sol et le gaz carbonique de l'air en sucres qui nourrissent toute la plante et en oxygène qui est rejeté dans l'atmosphère que nous respirons chaque jour."
        data = build(
            rec("d1", base, answer),
            rec("d2", base.upper(), answer),  # même texte, casse différente : doublon exact après normalisation
            rec("d3", base, answer[:-1] + " ici."),  # un seul mot ajouté en fin de réponse : quasi-doublon (similarité > 0,9)
            rec("d4", "Quelle est la capitale du Sénégal et quelle est sa population approximative aujourd'hui", "Dakar est la capitale du Sénégal."),
        )
        result = prepare(data, PrepareOptions(val_fraction=0))
        self.assertEqual([r.id for r in result.train], ["d1", "d4"])
        reasons = dict(result.rejected)
        self.assertIn("doublon exact", reasons["d2"])
        self.assertIn("quasi-doublon", reasons["d3"])

    def test_contamination_with_eval_suite(self) -> None:
        suite = load_suite(SUITE)
        data = build(
            rec("c1", "Combien font 15 × 12 ?", "180"),  # invite identique à un cas d'évaluation
            rec("c2", "Résolvons ensemble : « Quelle est la capitale du Cameroun ? » est une question classique de géographie.", "Yaoundé."),
            rec("c3", "Peux-tu m'aider à comprendre les verbes du troisième groupe en français ?", "Bien sûr, voyons les terminaisons ensemble."),
        )
        result = prepare(data, PrepareOptions(val_fraction=0), eval_suite=suite)
        self.assertEqual([r.id for r in result.train], ["c3"])
        self.assertEqual({i for i, _ in result.rejected}, {"c1", "c2"})
        self.assertTrue(result.contamination_checked)
        self.assertEqual(result.suite_sha256, suite.sha256)

    def test_without_suite_contamination_is_flagged_unchecked(self) -> None:
        result = prepare(build(rec("n1", "question valable pour test", "Une réponse suffisante pour le test.")))
        self.assertFalse(result.contamination_checked)
        self.assertTrue(any("NON vérifiée" in w for w in result.warnings))

    def test_split_is_deterministic_grouped_and_roughly_proportional(self) -> None:
        topics = ["mathématiques", "histoire", "biologie", "chimie", "géographie", "physique", "grammaire", "musique", "sport", "cuisine"]
        items = [
            rec(f"s{i:03d}", f"Parle-moi du sujet numéro {i} : {topics[i % 10]} {topics[(i * 3) % 10]} {i * 7919}", f"Voici une explication détaillée {i} sur {topics[(i * 7) % 10]} et {i * 31}.")
            for i in range(200)
        ]
        options = PrepareOptions(val_fraction=0.2, seed=3)
        a, b = prepare(build(*items), options), prepare(build(*items), options)
        self.assertEqual([r.id for r in a.validation], [r.id for r in b.validation])
        self.assertEqual(len(a.train) + len(a.validation) + len(a.rejected), 200)
        self.assertTrue(20 <= len(a.validation) <= 60, len(a.validation))
        grouped = [rec(f"g{i}", f"Question distincte numéro {i} sur le thème {topics[i % 10]} {i * 101}", f"Réponse distincte {i} avec {topics[(i + 4) % 10]} {i * 13}", group="G") for i in range(20)]
        sides = {("val" if r in prepare(build(*grouped), options).validation else "train") for r in build(*grouped)}
        part = prepare(build(*grouped), options)
        self.assertTrue(not part.train or not part.validation, "un groupe ne doit pas être coupé entre entraînement et validation")
        self.assertTrue(sides)

    def test_options_are_validated(self) -> None:
        for bad in (PrepareOptions(val_fraction=0.9), PrepareOptions(pii_mode="x"), PrepareOptions(contamination_ngram=1)):
            with self.assertRaises(ConfigurationError):
                prepare([], bad)


class OutputsTest(unittest.TestCase):
    def test_outputs_manifest_and_no_overwrite(self) -> None:
        data = build(
            rec("o1", "Question numéro un assez longue pour passer", "Réponse numéro un assez longue pour passer."),
            rec("o2", "Mon numéro est 699123456, aide-moi", "Ne partagez pas votre numéro en public, c'est risqué."),
            rec("o3", "x", "y"),
        )
        options = PrepareOptions(val_fraction=0)
        result = prepare(data, options, eval_suite=load_suite(SUITE))
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "in.jsonl"
            source.write_text("{}\n", encoding="utf-8")
            out = Path(tmp) / "out"
            manifest = write_outputs(result, out, options, input_files=[source])
            self.assertTrue(manifest["contamination_checked"])
            self.assertEqual(manifest["train"]["records"], 2)
            self.assertEqual(manifest["rejected"]["total"], 1)
            self.assertEqual(manifest["pii_masked"], {"numero": 1})
            self.assertEqual(json.loads((out / "manifest.json").read_text())["files"], manifest["files"])
            rejected_text = (out / "rejected.jsonl").read_text(encoding="utf-8")
            self.assertNotIn("Question", rejected_text)  # raisons seulement, jamais le contenu
            self.assertNotIn("699123456", (out / "train.jsonl").read_text(encoding="utf-8"))
            with self.assertRaises(ConfigurationError):
                write_outputs(result, out, options, input_files=[source])


if __name__ == "__main__":
    unittest.main()
