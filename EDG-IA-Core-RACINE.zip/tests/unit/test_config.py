"""Tests unitaires de la configuration (aucun réseau, aucun modèle, aucun GPU)."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from edgia_core.config import (
    DEMO_NOTICE,
    MIN_API_KEY_LENGTH,
    Mode,
    build_serving_report,
    load_settings,
    parse_env_file,
)
from edgia_core.errors import ConfigurationError

ROOT = Path(__file__).resolve().parents[2]
GOOD_KEY = "k" * MIN_API_KEY_LENGTH
OTHER_KEY = "z" * MIN_API_KEY_LENGTH


class DefaultsTest(unittest.TestCase):
    def test_defaults_are_secure(self) -> None:
        settings = load_settings(env={})
        self.assertEqual(settings.mode, Mode.DEMO)
        self.assertEqual(settings.host, "127.0.0.1")
        self.assertTrue(settings.auth_enabled)
        self.assertTrue(settings.rate_limit_enabled)
        self.assertTrue(settings.log_redact_content)
        self.assertEqual(settings.allowed_origins, ())
        self.assertEqual(settings.api_keys, ())

    def test_valid_configuration_is_loaded(self) -> None:
        settings = load_settings(
            env={
                "EDGIA_MODE": "demo",
                "EDGIA_PORT": "9001",
                "EDGIA_MAX_CONTEXT_TOKENS": "2048",
                "EDGIA_MAX_NEW_TOKENS": "256",
                "EDGIA_STREAMING_ENABLED": "false",
                "EDGIA_API_KEYS": f"{GOOD_KEY}, {OTHER_KEY}",
                "EDGIA_ALLOWED_ORIGINS": "https://a.example, https://b.example",
                "EDGIA_LOG_LEVEL": "DEBUG",
            }
        )
        self.assertEqual(settings.port, 9001)
        self.assertEqual(settings.max_context_tokens, 2048)
        self.assertEqual(settings.max_new_tokens, 256)
        self.assertFalse(settings.streaming_enabled)
        self.assertEqual(len(settings.api_keys), 2)
        self.assertEqual(settings.allowed_origins, ("https://a.example", "https://b.example"))

    def test_env_example_is_valid(self) -> None:
        settings = load_settings(env={}, env_file=ROOT / ".env.example")
        self.assertEqual(settings.mode, Mode.DEMO)
        self.assertEqual(settings.api_keys, ())

    def test_non_edgia_variables_are_ignored(self) -> None:
        settings = load_settings(env={"PATH": "/usr/bin", "OTHER_PORT": "1"})
        self.assertEqual(settings.port, 8000)

    def test_empty_value_means_unset(self) -> None:
        settings = load_settings(env={"EDGIA_MODEL_DESCRIPTOR": "", "EDGIA_API_KEYS": ""})
        self.assertIsNone(settings.model_descriptor)


class RejectionTest(unittest.TestCase):
    def assertRejected(self, env: dict[str, str]) -> ConfigurationError:
        with self.assertRaises(ConfigurationError) as ctx:
            load_settings(env=env)
        return ctx.exception

    def test_unknown_variable_is_rejected(self) -> None:
        error = self.assertRejected({"EDGIA_AUTH_ENABLD": "false"})
        self.assertIn("EDGIA_AUTH_ENABLD", " ".join(error.problems))

    def test_invalid_port_is_rejected(self) -> None:
        self.assertRejected({"EDGIA_PORT": "70000"})
        self.assertRejected({"EDGIA_PORT": "abc"})

    def test_invalid_mode_is_rejected(self) -> None:
        self.assertRejected({"EDGIA_MODE": "prod"})

    def test_max_new_tokens_must_fit_in_context(self) -> None:
        self.assertRejected({"EDGIA_MAX_CONTEXT_TOKENS": "512", "EDGIA_MAX_NEW_TOKENS": "512"})

    def test_non_positive_limits_are_rejected(self) -> None:
        self.assertRejected({"EDGIA_REQUEST_TIMEOUT_SECONDS": "0"})
        self.assertRejected({"EDGIA_MAX_CONCURRENT_REQUESTS": "0"})
        self.assertRejected({"EDGIA_RATE_LIMIT_PER_MINUTE": "0"})

    def test_short_api_key_is_rejected_without_leaking_it(self) -> None:
        secret = "tropcourte"
        error = self.assertRejected({"EDGIA_API_KEYS": secret})
        self.assertNotIn(secret, str(error))
        self.assertNotIn(secret, " ".join(error.problems))

    def test_duplicate_api_keys_are_rejected(self) -> None:
        self.assertRejected({"EDGIA_API_KEYS": f"{GOOD_KEY},{GOOD_KEY}"})

    def test_auth_cannot_be_disabled_on_public_interface(self) -> None:
        self.assertRejected({"EDGIA_AUTH_ENABLED": "false", "EDGIA_HOST": "0.0.0.0"})
        self.assertRejected({"EDGIA_AUTH_ENABLED": "false", "EDGIA_HOST": "192.168.1.10"})

    def test_auth_can_be_disabled_on_loopback_only(self) -> None:
        for host in ("127.0.0.1", "localhost", "::1"):
            settings = load_settings(env={"EDGIA_AUTH_ENABLED": "false", "EDGIA_HOST": host})
            self.assertFalse(settings.auth_enabled)


class SecretHandlingTest(unittest.TestCase):
    def test_api_keys_are_masked_in_repr_and_dump(self) -> None:
        settings = load_settings(env={"EDGIA_API_KEYS": GOOD_KEY})
        self.assertNotIn(GOOD_KEY, repr(settings))
        self.assertNotIn(GOOD_KEY, str(settings))
        self.assertNotIn(GOOD_KEY, settings.model_dump_json())
        self.assertEqual(settings.api_keys[0].get_secret_value(), GOOD_KEY)


class EnvFileTest(unittest.TestCase):
    def write(self, directory: str, content: str) -> Path:
        path = Path(directory) / ".env"
        path.write_text(content, encoding="utf-8")
        return path

    def test_parsing_handles_comments_quotes_and_export(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write(
                tmp,
                "# commentaire\n\nEDGIA_PORT=9100  # inline\nexport EDGIA_HOST='127.0.0.1'\nEDGIA_LOG_LEVEL=\"WARNING\"\n",
            )
            self.assertEqual(
                parse_env_file(path),
                {"EDGIA_PORT": "9100", "EDGIA_HOST": "127.0.0.1", "EDGIA_LOG_LEVEL": "WARNING"},
            )

    def test_real_environment_overrides_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write(tmp, "EDGIA_PORT=9100\nEDGIA_LOG_LEVEL=ERROR\n")
            settings = load_settings(env={"EDGIA_PORT": "9200"}, env_file=path)
            self.assertEqual(settings.port, 9200)
            self.assertEqual(settings.log_level.value, "ERROR")

    def test_malformed_line_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write(tmp, "pas une affectation\n")
            with self.assertRaises(ConfigurationError):
                parse_env_file(path)

    def test_missing_file_is_rejected(self) -> None:
        with self.assertRaises(ConfigurationError):
            parse_env_file(Path("/nonexistent/.env"))


class ServingReportTest(unittest.TestCase):
    def test_demo_mode_is_explicitly_flagged(self) -> None:
        report = build_serving_report(load_settings(env={"EDGIA_API_KEYS": GOOD_KEY}))
        self.assertTrue(report.ok)
        self.assertIn(DEMO_NOTICE, report.warnings)
        self.assertIsNone(report.descriptor)

    def test_auth_without_keys_blocks_startup(self) -> None:
        report = build_serving_report(load_settings(env={}))
        self.assertFalse(report.ok)
        self.assertTrue(any("EDGIA_API_KEYS" in p for p in report.problems))

    def test_real_mode_without_descriptor_blocks_startup(self) -> None:
        report = build_serving_report(load_settings(env={"EDGIA_MODE": "real", "EDGIA_API_KEYS": GOOD_KEY}))
        self.assertFalse(report.ok)
        self.assertTrue(any("EDGIA_MODEL_DESCRIPTOR" in p for p in report.problems))

    def test_real_mode_with_missing_descriptor_file_blocks_startup(self) -> None:
        settings = load_settings(
            env={"EDGIA_MODE": "real", "EDGIA_API_KEYS": GOOD_KEY, "EDGIA_MODEL_DESCRIPTOR": "/nonexistent/model.yaml"}
        )
        report = build_serving_report(settings)
        self.assertFalse(report.ok)

    def test_example_descriptor_is_refused_in_real_mode(self) -> None:
        """Le modèle d'exemple (valeurs fictives) ne doit jamais pouvoir être servi."""
        settings = load_settings(
            env={
                "EDGIA_MODE": "real",
                "EDGIA_API_KEYS": GOOD_KEY,
                "EDGIA_MODEL_DESCRIPTOR": str(ROOT / "configs" / "model.example.yaml"),
            }
        )
        report = build_serving_report(settings)
        self.assertFalse(report.ok)
        joined = " ".join(report.problems)
        self.assertIn("Poids introuvables", joined)
        self.assertIn("Licence non vérifiée", joined)


if __name__ == "__main__":
    unittest.main()
