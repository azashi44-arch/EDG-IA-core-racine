"""Tests unitaires du registre de modèles (fichiers factices, SQLite en mémoire ou temporaire)."""

from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path

from edgia_core.model.descriptor import ModelDescriptor
from edgia_core.model.registry import (
    ACTIVE,
    FAILED,
    REGISTERED,
    RETIRED,
    VALIDATED,
    ModelRegistry,
    RegistryError,
)


class RegistryFixture(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.registry = ModelRegistry(":memory:")

    def descriptor(self, version: str = "1.0.0", *, reviewed: bool = True, content: bytes = b"poids") -> ModelDescriptor:
        directory = self.root / version
        directory.mkdir(exist_ok=True)
        weights = directory / "model.safetensors"
        weights.write_bytes(content)
        (directory / "tok").mkdir(exist_ok=True)
        return ModelDescriptor.model_validate(
            {
                "model_id": "edgia-test",
                "version": version,
                "weights_path": weights,
                "tokenizer_path": directory / "tok",
                "weights_format": "safetensors",
                "runtime": "transformers",
                "license": {"name": "test", "commercial_use_allowed": True, "reviewed": reviewed},
                "sha256": {"model.safetensors": hashlib.sha256(content).hexdigest()},
            }
        )


class LifecycleTest(RegistryFixture):
    def test_register_starts_unvalidated(self) -> None:
        record = self.registry.register(self.descriptor())
        self.assertEqual(record.status, REGISTERED)
        self.assertIsNone(self.registry.active())

    def test_versions_are_immutable(self) -> None:
        self.registry.register(self.descriptor())
        with self.assertRaises(RegistryError):
            self.registry.register(self.descriptor())

    def test_descriptor_survives_a_round_trip(self) -> None:
        original = self.descriptor()
        self.registry.register(original)
        self.assertEqual(self.registry.get("edgia-test", "1.0.0").descriptor, original)

    def test_unknown_version_is_refused(self) -> None:
        with self.assertRaises(RegistryError):
            self.registry.get("edgia-test", "9.9.9")

    def test_validation_success_and_failure(self) -> None:
        self.registry.register(self.descriptor("1.0.0"))
        self.registry.register(self.descriptor("2.0.0", reviewed=False))
        self.assertEqual(self.registry.validate("edgia-test", "1.0.0").status, VALIDATED)
        failed = self.registry.validate("edgia-test", "2.0.0")
        self.assertEqual(failed.status, FAILED)
        self.assertTrue(any("Licence non vérifiée" in p for p in failed.problems))

    def test_activation_requires_validation(self) -> None:
        self.registry.register(self.descriptor())
        with self.assertRaises(RegistryError):
            self.registry.activate("edgia-test", "1.0.0")

    def test_failed_version_cannot_be_activated(self) -> None:
        self.registry.register(self.descriptor(reviewed=False))
        self.registry.validate("edgia-test", "1.0.0")
        with self.assertRaises(RegistryError):
            self.registry.activate("edgia-test", "1.0.0")

    def test_only_one_version_is_active_and_previous_is_retired(self) -> None:
        for version in ("1.0.0", "2.0.0"):
            self.registry.register(self.descriptor(version))
            self.registry.validate("edgia-test", version)
        self.registry.activate("edgia-test", "1.0.0")
        self.registry.activate("edgia-test", "2.0.0")
        self.assertEqual(self.registry.active().version, "2.0.0")
        self.assertEqual(self.registry.get("edgia-test", "1.0.0").status, RETIRED)
        self.assertEqual(sum(r.status == ACTIVE for r in self.registry.list_versions()), 1)

    def test_activating_the_active_version_is_a_no_op(self) -> None:
        self.registry.register(self.descriptor())
        self.registry.validate("edgia-test", "1.0.0")
        self.registry.activate("edgia-test", "1.0.0")
        self.assertEqual(self.registry.activate("edgia-test", "1.0.0").status, ACTIVE)
        self.assertEqual(sum(1 for h in self.registry.history() if h[1] == "activate"), 1)


class IntegrityTest(RegistryFixture):
    def test_activation_revalidates_and_refuses_if_files_changed(self) -> None:
        descriptor = self.descriptor()
        self.registry.register(descriptor)
        self.registry.validate("edgia-test", "1.0.0")
        descriptor.weights_path.write_bytes(b"fichier corrompu apres validation")
        with self.assertRaises(RegistryError) as ctx:
            self.registry.activate("edgia-test", "1.0.0")
        self.assertIn("Somme de contrôle", str(ctx.exception))
        self.assertEqual(self.registry.get("edgia-test", "1.0.0").status, FAILED)
        self.assertIsNone(self.registry.active())

    def test_revalidation_of_active_version_that_broke_takes_it_out_of_service(self) -> None:
        descriptor = self.descriptor()
        self.registry.register(descriptor)
        self.registry.validate("edgia-test", "1.0.0")
        self.registry.activate("edgia-test", "1.0.0")
        descriptor.weights_path.unlink()
        self.assertEqual(self.registry.validate("edgia-test", "1.0.0").status, FAILED)
        self.assertIsNone(self.registry.active())

    def test_revalidation_keeps_active_status_when_still_valid(self) -> None:
        self.registry.register(self.descriptor())
        self.registry.validate("edgia-test", "1.0.0")
        self.registry.activate("edgia-test", "1.0.0")
        self.assertEqual(self.registry.validate("edgia-test", "1.0.0").status, ACTIVE)


class RollbackTest(RegistryFixture):
    def setUp(self) -> None:
        super().setUp()
        for version in ("1.0.0", "2.0.0", "3.0.0"):
            self.registry.register(self.descriptor(version))
            self.registry.validate("edgia-test", version)

    def test_rollback_returns_to_the_replaced_version(self) -> None:
        self.registry.activate("edgia-test", "1.0.0")
        self.registry.activate("edgia-test", "2.0.0")
        self.assertEqual(self.registry.rollback().version, "1.0.0")
        self.assertEqual(self.registry.active().version, "1.0.0")
        self.assertEqual(self.registry.get("edgia-test", "2.0.0").status, RETIRED)

    def test_second_rollback_goes_back_forward(self) -> None:
        self.registry.activate("edgia-test", "1.0.0")
        self.registry.activate("edgia-test", "2.0.0")
        self.registry.rollback()
        self.assertEqual(self.registry.rollback().version, "2.0.0")

    def test_rollback_follows_the_actual_replacement_chain(self) -> None:
        self.registry.activate("edgia-test", "1.0.0")
        self.registry.activate("edgia-test", "2.0.0")
        self.registry.activate("edgia-test", "3.0.0")
        self.assertEqual(self.registry.rollback().version, "2.0.0")

    def test_rollback_without_active_or_previous_is_refused(self) -> None:
        with self.assertRaises(RegistryError):
            self.registry.rollback()
        self.registry.activate("edgia-test", "1.0.0")
        with self.assertRaises(RegistryError):
            self.registry.rollback()

    def test_rollback_is_refused_if_previous_files_are_gone(self) -> None:
        self.registry.activate("edgia-test", "1.0.0")
        self.registry.activate("edgia-test", "2.0.0")
        self.registry.get("edgia-test", "1.0.0").descriptor.weights_path.unlink()
        with self.assertRaises(RegistryError):
            self.registry.rollback()
        self.assertEqual(self.registry.active().version, "2.0.0")

    def test_history_records_actions(self) -> None:
        self.registry.activate("edgia-test", "1.0.0")
        self.registry.activate("edgia-test", "2.0.0")
        self.registry.rollback()
        actions = [h[1] for h in self.registry.history()]
        self.assertEqual(actions.count("register"), 3)
        self.assertEqual(actions.count("activate"), 2)
        self.assertEqual(actions.count("rollback"), 1)

    def test_retire_removes_the_active_version(self) -> None:
        self.registry.activate("edgia-test", "1.0.0")
        self.assertEqual(self.registry.retire("edgia-test", "1.0.0").status, RETIRED)
        self.assertIsNone(self.registry.active())
        with self.assertRaises(RegistryError):
            self.registry.retire("edgia-test", "1.0.0")


class PersistenceTest(RegistryFixture):
    def test_state_persists_in_a_file(self) -> None:
        path = self.root / "sub" / "registry.sqlite3"
        first = ModelRegistry(path)
        first.register(self.descriptor())
        first.validate("edgia-test", "1.0.0")
        first.activate("edgia-test", "1.0.0")
        reopened = ModelRegistry(path)
        self.assertEqual(reopened.active().version, "1.0.0")
        self.assertEqual(len(reopened.history()), 3)


if __name__ == "__main__":
    unittest.main()
