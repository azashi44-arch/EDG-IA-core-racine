"""Tests unitaires du modèle de démonstration."""

from __future__ import annotations

import unittest

from edgia_core.inference.base import EngineError, GenerationParams, InferenceEngine, Message
from edgia_core.inference.demo import DEMO_MODEL_ID, DEMO_REPLY_NOTICE, DemoEngine

MESSAGES = [Message("system", "Tu es utile."), Message("user", "Bonjour tout le monde")]
PARAMS = GenerationParams(max_tokens=200)


class DemoEngineTest(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.engine = DemoEngine()

    def test_declares_itself_as_demo(self) -> None:
        self.assertTrue(self.engine.info.is_demo)
        self.assertEqual(self.engine.info.id, DEMO_MODEL_ID)
        self.assertTrue(self.engine.is_ready())

    def test_reply_states_it_is_not_the_trained_model(self) -> None:
        result = self.engine.generate(MESSAGES, PARAMS)
        self.assertIn("PAS générée par le modèle EDG-IA entraîné", result.text)
        self.assertEqual(result.finish_reason, "stop")

    def test_reply_never_echoes_message_content(self) -> None:
        secret = "SECRET-À-NE-PAS-REPRODUIRE"
        result = self.engine.generate([Message("user", secret)], PARAMS)
        self.assertNotIn(secret, result.text)

    def test_is_deterministic(self) -> None:
        self.assertEqual(self.engine.generate(MESSAGES, PARAMS), self.engine.generate(MESSAGES, PARAMS))

    def test_max_tokens_truncates_and_reports_length(self) -> None:
        result = self.engine.generate(MESSAGES, GenerationParams(max_tokens=3))
        self.assertEqual(result.completion_tokens, 3)
        self.assertEqual(result.finish_reason, "length")
        self.assertTrue(DEMO_REPLY_NOTICE.startswith(result.text.strip().rsplit(" ", 1)[0]))

    def test_stop_sequence_cuts_the_reply(self) -> None:
        result = self.engine.generate(MESSAGES, GenerationParams(max_tokens=200, stop=("PAS",)))
        self.assertNotIn("PAS", result.text)
        self.assertEqual(result.finish_reason, "stop")

    def test_prompt_token_count_is_an_approximation_per_word(self) -> None:
        self.assertEqual(self.engine.count_tokens(MESSAGES), 3 + 4)  # « Tu es utile. » + « Bonjour tout le monde »
        self.assertEqual(self.engine.count_tokens([Message("user", "")]), 1)

    async def test_stream_matches_generate(self) -> None:
        expected = self.engine.generate(MESSAGES, PARAMS)
        chunks = [chunk async for chunk in self.engine.stream(MESSAGES, PARAMS)]
        self.assertEqual("".join(c.text for c in chunks), expected.text)
        self.assertEqual(chunks[-1].finish_reason, expected.finish_reason)
        self.assertEqual(chunks[-1].completion_tokens, expected.completion_tokens)
        self.assertTrue(all(c.finish_reason is None for c in chunks[:-1]))

    async def test_stream_respects_max_tokens(self) -> None:
        chunks = [c async for c in self.engine.stream(MESSAGES, GenerationParams(max_tokens=2))]
        self.assertEqual(chunks[-1].finish_reason, "length")
        self.assertEqual(chunks[-1].completion_tokens, 2)

    async def test_base_engine_refuses_streaming_by_default(self) -> None:
        class Minimal(InferenceEngine):
            info = None  # type: ignore[assignment]

            def is_ready(self) -> bool:
                return True

            def count_tokens(self, messages):  # type: ignore[no-untyped-def]
                return 0

            def generate(self, messages, params):  # type: ignore[no-untyped-def]
                raise NotImplementedError

        self.assertFalse(Minimal.supports_streaming)
        with self.assertRaises(EngineError):
            Minimal().stream(MESSAGES, PARAMS)


if __name__ == "__main__":
    unittest.main()
