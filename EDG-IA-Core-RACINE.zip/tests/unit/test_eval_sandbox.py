"""Tests du bac à sable d'exécution de code (ils exécutent réellement du code Python dans un sous-processus)."""

from __future__ import annotations

import os
import tempfile
import time
import json
import stat
import subprocess
import sys
import unittest
from pathlib import Path
from unittest import mock

from edgia_core.evaluation.checks import FAIL, PASS, SKIPPED
from edgia_core.evaluation.sandbox import SandboxLimits, extract_python, run_code_tests, sandbox_available
from edgia_core.evaluation.schema import CheckSpec

SPEC = CheckSpec(kind="code_tests", function="est_pair", tests=["est_pair(2) is True", "est_pair(3) is False"])


@unittest.skipUnless(sandbox_available(), "bac à sable indisponible")
class SandboxTest(unittest.TestCase):
    def test_correct_code_passes(self) -> None:
        out = "Voici :\n```python\ndef est_pair(n):\n    return n % 2 == 0\n```\nVoilà."
        self.assertEqual(run_code_tests(SPEC, out).status, PASS)

    def test_wrong_code_fails_with_test_numbers(self) -> None:
        result = run_code_tests(SPEC, "def est_pair(n):\n    return True")
        self.assertEqual(result.status, FAIL)
        self.assertIn("2", result.detail)

    def test_missing_function_syntax_error_and_no_code(self) -> None:
        self.assertEqual(run_code_tests(SPEC, "def autre(): pass").status, FAIL)
        self.assertEqual(run_code_tests(SPEC, "def est_pair(:").status, FAIL)
        self.assertEqual(run_code_tests(SPEC, "").status, FAIL)

    def test_failing_test_expression_is_a_failure_not_a_crash(self) -> None:
        spec = CheckSpec(kind="code_tests", function="f", tests=["f(1) == 1", "f(None) == 1"])
        self.assertEqual(run_code_tests(spec, "def f(x): return x + 0").status, FAIL)

    def test_infinite_loop_is_killed_by_timeout(self) -> None:
        started = time.monotonic()
        result = run_code_tests(SPEC, "def est_pair(n):\n    while True: pass", SandboxLimits(timeout_seconds=1.0, cpu_seconds=3))
        self.assertEqual(result.status, FAIL)
        self.assertLess(time.monotonic() - started, 6)

    def test_import_time_infinite_loop_is_killed(self) -> None:
        result = run_code_tests(SPEC, "while True: pass", SandboxLimits(timeout_seconds=1.0, cpu_seconds=3))
        self.assertEqual(result.status, FAIL)

    def test_memory_hog_is_stopped(self) -> None:
        code = "def est_pair(n):\n    x = bytearray(2 * 1024**3)\n    return n % 2 == 0"
        self.assertEqual(run_code_tests(SPEC, code, SandboxLimits(memory_mb=128)).status, FAIL)

    def test_large_file_write_is_limited_and_stays_in_temp_dir(self) -> None:
        marker = Path(tempfile.gettempdir()) / "edgia_sandbox_escape_marker"
        marker.unlink(missing_ok=True)
        code = (
            "def est_pair(n):\n"
            "    open('relatif.bin', 'wb').write(b'x' * (50 * 1024 * 1024))\n"
            "    return n % 2 == 0\n"
        )
        self.assertEqual(run_code_tests(SPEC, code).status, FAIL)
        self.assertFalse(marker.exists())
        self.assertFalse(Path("relatif.bin").exists())

    def test_environment_is_cleared(self) -> None:
        os.environ["EDGIA_SANDBOX_SECRET"] = "valeur-secrete"
        self.addCleanup(os.environ.pop, "EDGIA_SANDBOX_SECRET", None)
        spec = CheckSpec(kind="code_tests", function="f", tests=["f() is True"])
        code = "import os\ndef f():\n    return 'EDGIA_SANDBOX_SECRET' not in os.environ"
        self.assertEqual(run_code_tests(spec, code).status, PASS)

    def test_forged_result_line_is_not_trusted(self) -> None:
        code = "print('EDGIA_RESULT_0000:{\"results\": [true, true]}')\ndef est_pair(n):\n    return True"
        self.assertEqual(run_code_tests(SPEC, code).status, FAIL)

    def test_noisy_output_does_not_break_parsing(self) -> None:
        code = "print('x' * 200000)\ndef est_pair(n):\n    return n % 2 == 0"
        self.assertEqual(run_code_tests(SPEC, code).status, PASS)


@unittest.skipUnless(sandbox_available(), "bac à sable indisponible")
class SandboxStartFailureTest(unittest.TestCase):
    """Si le bac à sable ne peut pas démarrer, le code n'est JAMAIS exécuté sans limites ni déclaré réussi."""

    CODE = "def est_pair(n):\n    return n % 2 == 0"

    def test_refused_limit_means_not_executed(self) -> None:
        from edgia_core.evaluation import sandbox

        # Comportement observé sous macOS : le système refuse RLIMIT_AS (ValueError levée dans le processus fils).
        real = sandbox.resource.setrlimit

        def refuse_address_space(which, limits):
            if which == sandbox.resource.RLIMIT_AS:
                raise ValueError("current limit exceeds maximum limit")
            return real(which, limits)

        with mock.patch.object(sandbox.resource, "setrlimit", side_effect=refuse_address_space):
            result = run_code_tests(SPEC, self.CODE)
        self.assertEqual(result.status, SKIPPED)
        self.assertIn("non exécuté", result.detail)

    def test_launch_failure_means_not_executed(self) -> None:
        for error in (OSError("fork impossible"), subprocess.SubprocessError("échec")):
            with self.subTest(error=type(error).__name__), mock.patch.object(subprocess, "Popen", side_effect=error):
                result = run_code_tests(SPEC, self.CODE)
            self.assertEqual(result.status, SKIPPED)
            self.assertNotEqual(result.status, PASS)


@unittest.skipUnless(sandbox_available(), "bac à sable indisponible")
class SandboxBrokenInterpreterTest(unittest.TestCase):
    """Un interpréteur inutilisable est une PANNE (non exécuté), pas un échec du modèle ; un plantage du code reste un échec."""

    CODE = "def est_pair(n):\n    return n % 2 == 0"

    def _fake_interpreter(self, body: str) -> str:
        directory = tempfile.mkdtemp(prefix="edgia-fake-python-")
        self.addCleanup(__import__("shutil").rmtree, directory, True)
        path = Path(directory) / "python-casse"
        path.write_text("#!/bin/sh\n" + body + "\n")
        path.chmod(path.stat().st_mode | stat.S_IXUSR)
        return str(path)

    def test_interpreter_exiting_255_is_not_executed_not_failed(self) -> None:
        with mock.patch.object(sys, "executable", self._fake_interpreter("exit 255")):
            result = run_code_tests(SPEC, self.CODE)
        self.assertEqual(result.status, SKIPPED)
        self.assertIn("255", result.detail)
        self.assertIn("non exécuté", result.detail)
        self.assertIn("sandbox_diagnose.py", result.detail)

    def test_code_crashing_after_startup_is_still_a_failure(self) -> None:
        # Le harnais a démarré, c'est le code du modèle qui quitte brutalement : échec du modèle, pas panne.
        result = run_code_tests(SPEC, "import os\nos._exit(255)")
        self.assertEqual(result.status, FAIL)
        self.assertIn("interrompu", result.detail)

    def test_diagnostic_tool_runs_and_reports_healthy_sandbox(self) -> None:
        tool = Path(__file__).resolve().parents[2] / "tools" / "sandbox_diagnose.py"
        done = subprocess.run([sys.executable, str(tool), "--json"], capture_output=True, text=True, timeout=120)
        self.assertEqual(done.returncode, 0, done.stderr)
        report = json.loads(done.stdout)
        stages = {item["stage"]: item["ok"] for item in report["stages"]}
        self.assertTrue(stages["C tout ensemble (comme le bac à sable)"])


class ExtractTest(unittest.TestCase):
    def test_extract_python(self) -> None:
        self.assertEqual(extract_python("a\n```python\nx = 1\n```\nb"), "x = 1")
        self.assertEqual(extract_python("```\ny = 2\n```"), "y = 2")
        self.assertEqual(extract_python("z = 3"), "z = 3")


if __name__ == "__main__":
    unittest.main()
