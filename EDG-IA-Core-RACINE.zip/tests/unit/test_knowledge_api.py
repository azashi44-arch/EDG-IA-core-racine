"""Tests de l'API documentaire : POST /v1/knowledge/search et champ `knowledge` du chat (aucun modèle réel)."""

from __future__ import annotations

import contextlib
import io
import json
import tempfile
import threading
import unittest
from pathlib import Path

from edgia_core.api.app import create_app
from edgia_core.cli import main
from edgia_core.errors import ConfigurationError
from edgia_core.inference.base import GenerationParams, GenerationResult, Message
from edgia_core.inference.demo import DemoEngine
from edgia_core.knowledge.store import KnowledgeBase
from tests.helpers import auth, chat_body, make_settings, request

CHAT = "/v1/chat/completions"
SEARCH = "/v1/knowledge/search"
COURSE = "# Géographie\n\nLa capitale politique du Cameroun est Yaoundé. La capitale économique est Douala.\n"


class CapturingEngine(DemoEngine):
    def __init__(self) -> None:
        super().__init__()
        self.seen: list[Message] = []

    def generate(self, messages, params: GenerationParams, cancel: threading.Event | None = None) -> GenerationResult:
        self.seen = list(messages)
        return super().generate(messages, params, cancel)


class KnowledgeApiCase(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.db = Path(self._tmp.name) / "kb.sqlite3"
        kb = KnowledgeBase(self.db)
        kb.add_document("g.md", COURSE.encode(), title="Cours de géographie", source="Manuel", rights="CC0-1.0", collection="geo")
        kb.close()

    def build(self, engine=None, with_kb: bool = True):
        extra = {"knowledge_db": str(self.db)} if with_kb else {}
        app = create_app(make_settings(**extra), engine)
        self.addCleanup(app.state.ctx.close)
        return app


class SearchEndpointTest(KnowledgeApiCase):
    async def test_search_returns_passages_with_citation_fields(self) -> None:
        response = await request(self.build(), "POST", SEARCH, headers=auth(), json_body={"query": "capitale du Cameroun"})
        self.assertEqual(response.status, 200, response.text)
        item = response.json()["data"][0]
        self.assertIn("Yaoundé", item["text"])
        self.assertEqual((item["title"], item["source"], item["collection"]), ("Cours de géographie", "Manuel", "geo"))

    async def test_no_match_gives_empty_list(self) -> None:
        response = await request(self.build(), "POST", SEARCH, headers=auth(), json_body={"query": "recette du gâteau"})
        self.assertEqual(response.json(), {"object": "list", "data": []})

    async def test_requires_authentication(self) -> None:
        response = await request(self.build(), "POST", SEARCH, json_body={"query": "capitale"})
        self.assertEqual(response.status, 401)

    async def test_disabled_without_database(self) -> None:
        response = await request(self.build(with_kb=False), "POST", SEARCH, headers=auth(), json_body={"query": "capitale"})
        self.assertEqual(response.status, 404)
        self.assertEqual(response.json()["error"]["code"], "knowledge_disabled")

    async def test_validation_errors_never_echo_content(self) -> None:
        app = self.build()
        secret = "CONTENU-SECRET-42"
        for body in ({"query": ""}, {"query": secret, "top_k": 99}, {"query": secret, "collection": "Mauvaise Collection"}, {"query": secret, "x": 1}, {"query": 5}):
            response = await request(app, "POST", SEARCH, headers=auth(), json_body=body)
            self.assertEqual(response.status, 422, body)
            self.assertNotIn(secret, response.text)
        bad_json = await request(app, "POST", SEARCH, headers={**auth(), "Content-Type": "application/json"}, body=b"{pas du json")
        self.assertEqual(bad_json.status, 400)
        wrong_type = await request(app, "POST", SEARCH, headers={**auth(), "Content-Type": "text/plain"}, body=b"x")
        self.assertEqual(wrong_type.status, 415)

    async def test_fts_syntax_injection_is_harmless(self) -> None:
        app = self.build()
        for query in ('capitale" OR *', "NEAR(a b)", "col:text", '"'):
            response = await request(app, "POST", SEARCH, headers=auth(), json_body={"query": query})
            self.assertEqual(response.status, 200, query)

    async def test_collection_filter(self) -> None:
        app = self.build()
        other = await request(app, "POST", SEARCH, headers=auth(), json_body={"query": "capitale", "collection": "maths"})
        self.assertEqual(other.json()["data"], [])


class ChatGroundingTest(KnowledgeApiCase):
    async def test_extracts_are_injected_as_untrusted_data_and_sources_returned(self) -> None:
        engine = CapturingEngine()
        body = chat_body(messages=[{"role": "user", "content": "Quelle est la capitale du Cameroun ?"}], knowledge={"top_k": 2})
        response = await request(self.build(engine), "POST", CHAT, headers=auth(), json_body=body)
        self.assertEqual(response.status, 200, response.text)
        self.assertEqual(engine.seen[0].role, "system")
        self.assertIn("Yaoundé", engine.seen[0].content)
        self.assertIn("DONNÉES", engine.seen[0].content)
        self.assertEqual(engine.seen[-1].content, "Quelle est la capitale du Cameroun ?")
        sources = response.json()["edgia"]["sources"]
        self.assertEqual(sources[0]["n"], 1)
        self.assertEqual(sources[0]["title"], "Cours de géographie")
        self.assertNotIn("text", sources[0])  # les sources désignent, elles ne recopient pas les passages

    async def test_no_extract_found_means_empty_sources_and_unchanged_conversation(self) -> None:
        engine = CapturingEngine()
        body = chat_body(messages=[{"role": "user", "content": "recette du gâteau au chocolat ?"}], knowledge={})
        response = await request(self.build(engine), "POST", CHAT, headers=auth(), json_body=body)
        self.assertEqual(response.status, 200)
        self.assertEqual(response.json()["edgia"]["sources"], [])
        self.assertEqual([m.role for m in engine.seen], ["user"])

    async def test_without_knowledge_field_nothing_changes(self) -> None:
        engine = CapturingEngine()
        response = await request(self.build(engine), "POST", CHAT, headers=auth(), json_body=chat_body())
        self.assertNotIn("sources", response.json()["edgia"])
        self.assertEqual(len(engine.seen), 1)

    async def test_auto_search_uses_database_without_request_flag(self) -> None:
        engine = CapturingEngine()
        app = create_app(make_settings(knowledge_db=str(self.db), knowledge_auto_search=True), engine)
        self.addCleanup(app.state.ctx.close)
        body = chat_body(messages=[{"role": "user", "content": "Quelle est la capitale du Cameroun ?"}])
        response = await request(app, "POST", CHAT, headers=auth(), json_body=body)
        self.assertEqual(response.status, 200, response.text)
        self.assertEqual(engine.seen[0].role, "system")
        self.assertIn("Yaoundé", engine.seen[0].content)
        self.assertEqual(response.json()["edgia"]["sources"][0]["title"], "Cours de géographie")

    async def test_knowledge_without_database_is_refused(self) -> None:
        response = await request(self.build(with_kb=False), "POST", CHAT, headers=auth(), json_body=chat_body(knowledge={}))
        self.assertEqual(response.status, 400)
        self.assertEqual(response.json()["error"]["code"], "knowledge_disabled")

    async def test_auto_search_requires_a_database_at_startup(self) -> None:
        with self.assertRaises(ConfigurationError):
            create_app(make_settings(knowledge_auto_search="true"), DemoEngine())

    async def test_invalid_knowledge_options_are_refused(self) -> None:
        app = self.build()
        for knowledge in ({"top_k": 0}, {"top_k": 9}, {"collection": "Mauvaise"}, {"inconnu": 1}, "oui"):
            response = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body(knowledge=knowledge))
            self.assertEqual(response.status, 422, knowledge)

    async def test_streaming_final_chunk_carries_sources(self) -> None:
        body = chat_body(messages=[{"role": "user", "content": "capitale du Cameroun ?"}], knowledge={}, stream=True)
        response = await request(self.build(), "POST", CHAT, headers=auth(), json_body=body)
        events = [json.loads(e) for e in response.sse_events() if e != "[DONE]"]
        self.assertEqual(events[-1]["edgia"]["sources"][0]["title"], "Cours de géographie")

    async def test_context_window_still_applies_after_grounding(self) -> None:
        app = create_app(make_settings(knowledge_db=str(self.db), max_context_tokens="128", max_new_tokens="64"), None)
        self.addCleanup(app.state.ctx.close)
        body = chat_body(messages=[{"role": "user", "content": "capitale du Cameroun ?"}], knowledge={}, max_tokens=60)
        response = await request(app, "POST", CHAT, headers=auth(), json_body=body)
        self.assertEqual(response.status, 422)
        self.assertEqual(response.json()["error"]["code"], "context_length_exceeded")


class StartupAndCliTest(unittest.TestCase):
    def test_missing_database_prevents_startup(self) -> None:
        with self.assertRaises(ConfigurationError) as ctx:
            create_app(make_settings(knowledge_db="/chemin/absent/kb.sqlite3"))
        self.assertIn("Base documentaire introuvable", str(ctx.exception))

    def test_cli_add_search_list_delete(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db, doc = Path(tmp) / "kb.sqlite3", Path(tmp) / "cours.md"
            doc.write_text(COURSE, encoding="utf-8")

            def run(*argv: str) -> tuple[int, str]:
                buffer = io.StringIO()
                with contextlib.redirect_stdout(buffer):
                    code = main(["knowledge", "--db", str(db), *argv])
                return code, buffer.getvalue()

            self.assertEqual(run("add", str(doc), "--source", "Manuel", "--rights", "inconnue")[0], 2)
            code, text = run("add", str(doc), "--source", "Manuel", "--rights", "CC0-1.0", "--id", "cours-geo", "--collection", "geo")
            self.assertEqual(code, 0, text)
            self.assertEqual(run("add", str(doc), "--source", "Manuel", "--rights", "CC0-1.0", "--id", "autre")[0], 2)  # doublon
            self.assertIn("Yaoundé", run("search", "capitale du Cameroun")[1])
            self.assertIn("Aucun passage", run("search", "recette gâteau")[1])
            self.assertIn("cours-geo", run("list")[1])
            self.assertIn('"documents": 1', run("stats")[1])
            self.assertEqual(run("delete", "cours-geo")[0], 0)
            self.assertIn("Base vide", run("list")[1])
            self.assertEqual(run("delete", "cours-geo")[0], 2)


if __name__ == "__main__":
    unittest.main()
