"""Tests du plan d'entraînement, de la configuration, des fonctions pures du SFT et de la CLI (aucun entraînement)."""

from __future__ import annotations

import contextlib
import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import yaml

from edgia_core.cli import main
from edgia_core.errors import ConfigurationError
from edgia_core.evaluation.schema import load_suite
from edgia_core.model.descriptor import load_descriptor
from edgia_core.training.config import TrainingConfig, load_training_config
from edgia_core.training.data import DataRecord
from edgia_core.training.plan import build_plan
from edgia_core.training.prepare import PrepareOptions, prepare, write_outputs
from edgia_core.training.sft import IGNORE_INDEX, build_example, descriptor_suggestion, learning_rate_at

ROOT = Path(__file__).resolve().parents[2]
SUITE = ROOT / "configs" / "eval" / "starter"


def fake_find_spec(present: bool = True):
    return mock.patch("edgia_core.training.plan.importlib.util.find_spec", lambda name: object() if present else None)


class Workspace:
    """Modèle de base fictif (faux fichiers de poids) et jeu préparé, dans un dossier temporaire."""

    def __init__(self, root: Path, *, records: int = 120, with_suite: bool = True, reviewed: bool = True) -> None:
        self.root = root
        weights = root / "weights"
        weights.mkdir()
        (weights / "model.safetensors").write_bytes(b"faux poids")
        tok = root / "tok"
        tok.mkdir()
        (tok / "tokenizer.json").write_text("{}")
        self.descriptor_path = root / "model.yaml"
        self.descriptor_path.write_text(
            yaml.safe_dump(
                {
                    "model_id": "base-test", "version": "1.0", "weights_path": "weights", "tokenizer_path": "tok",
                    "weights_format": "safetensors", "runtime": "transformers",
                    "license": {"name": "Apache-2.0", "commercial_use_allowed": True, "reviewed": reviewed},
                    "sha256": {"model.safetensors": hashlib.sha256(b"faux poids").hexdigest()},
                }
            ),
            encoding="utf-8",
        )
        topics = ["mathématiques", "histoire", "biologie", "chimie", "géographie", "physique", "grammaire", "musique", "sport", "cuisine"]
        items = [
            DataRecord.model_validate(
                {
                    "id": f"r{i:04d}",
                    "messages": [
                        {"role": "user", "content": f"Parle-moi du sujet {i} : {topics[i % 10]} et {topics[(i * 3) % 10]} {i * 7919}"},
                        {"role": "assistant", "content": f"Voici une explication {i} sur {topics[(i * 7) % 10]} avec le nombre {i * 31}."},
                    ],
                    "source": "test", "license": "CC0-1.0", "origin": "synthetic",
                }
            )
            for i in range(records)
        ]
        options = PrepareOptions(val_fraction=0.1)
        result = prepare(items, options, eval_suite=load_suite(SUITE) if with_suite else None)
        self.dataset = root / "data"
        source = root / "in.jsonl"
        source.write_text("{}\n")
        write_outputs(result, self.dataset, options, input_files=[source])
        self.out = root / "runs" / "x"

    def config(self, **overrides) -> TrainingConfig:
        values = dict(base_descriptor=self.descriptor_path, dataset_dir=self.dataset, output_dir=self.out, min_train_records=50)
        values.update(overrides)
        return TrainingConfig(**values)


class PlanTest(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)

    def test_valid_plan(self) -> None:
        ws = Workspace(self.root)
        with fake_find_spec():
            plan = build_plan(ws.config())
        self.assertTrue(plan.ok, plan.problems)
        self.assertGreater(plan.summary["train_records"], 80)
        self.assertGreater(plan.summary["optimizer_steps"], 0)
        self.assertIn("cost_notice", plan.summary)
        self.assertTrue(any("GROSSIÈRE" in w for w in plan.warnings))

    def test_missing_dependencies_block(self) -> None:
        ws = Workspace(self.root)
        with fake_find_spec(False):
            plan = build_plan(ws.config())
        self.assertFalse(plan.ok)
        self.assertTrue(any("Dépendance absente" in p for p in plan.problems))

    def test_unchecked_contamination_blocks(self) -> None:
        ws = Workspace(self.root, with_suite=False)
        with fake_find_spec():
            plan = build_plan(ws.config())
        self.assertFalse(plan.ok)
        self.assertTrue(any("Contamination" in p for p in plan.problems))

    def test_unreviewed_license_blocks(self) -> None:
        ws = Workspace(self.root, reviewed=False)
        with fake_find_spec():
            plan = build_plan(ws.config())
        self.assertFalse(plan.ok)
        self.assertTrue(any("Licence non vérifiée" in p for p in plan.problems))

    def test_modified_dataset_blocks(self) -> None:
        ws = Workspace(self.root)
        with (ws.dataset / "train.jsonl").open("a", encoding="utf-8") as handle:
            handle.write("\n")
        with fake_find_spec():
            plan = build_plan(ws.config())
        self.assertFalse(plan.ok)
        self.assertTrue(any("modifié depuis la préparation" in p for p in plan.problems))

    def test_corrupted_base_weights_block(self) -> None:
        ws = Workspace(self.root)
        (self.root / "weights" / "model.safetensors").write_bytes(b"autre contenu")
        with fake_find_spec():
            plan = build_plan(ws.config())
        self.assertFalse(plan.ok)
        self.assertTrue(any("Somme de contrôle incorrecte" in p for p in plan.problems))

    def test_too_few_records_and_missing_dataset(self) -> None:
        ws = Workspace(self.root, records=30)
        with fake_find_spec():
            self.assertTrue(any("Trop peu d'exemples" in p for p in build_plan(ws.config(min_train_records=100)).problems))
            missing = build_plan(ws.config(dataset_dir=self.root / "absent"))
        self.assertTrue(any("non préparé" in p for p in missing.problems))

    def test_non_empty_output_dir_blocks(self) -> None:
        ws = Workspace(self.root)
        ws.out.mkdir(parents=True)
        (ws.out / "ancien.txt").write_text("x")
        with fake_find_spec():
            plan = build_plan(ws.config())
        self.assertTrue(any("pas vide" in p for p in plan.problems))

    def test_already_adapted_base_is_refused(self) -> None:
        ws = Workspace(self.root)
        raw = yaml.safe_load(ws.descriptor_path.read_text())
        raw["adaptation"] = {"method": "lora", "base_model_id": "x"}
        ws.descriptor_path.write_text(yaml.safe_dump(raw))
        with fake_find_spec():
            plan = build_plan(ws.config())
        self.assertTrue(any("déjà un modèle adapté" in p for p in plan.problems))


class ConfigTest(unittest.TestCase):
    def test_example_config_loads_and_resolves_relative_paths(self) -> None:
        config = load_training_config(ROOT / "configs" / "training" / "exemple.yaml")
        self.assertTrue(config.base_descriptor.is_absolute())
        self.assertEqual(config.method, "lora")

    def test_invalid_values_are_refused(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            for body in ("method: qlora\n", "epochs: 0\n", "inconnu: 1\n", "learning_rate: 5\n", "- liste\n", "x: [\n"):
                path = Path(tmp) / "c.yaml"
                path.write_text("base_descriptor: a\ndataset_dir: b\noutput_dir: c\n" + body if body[0] != "-" and body[0] != "x" else body)
                with self.assertRaises(ConfigurationError, msg=body):
                    load_training_config(path)
            with self.assertRaises(ConfigurationError):
                load_training_config(Path(tmp) / "absent.yaml")


class FakeTokenizer:
    """Faux tokenizer : un token par caractère, modèle de conversation simple (jamais un vrai modèle)."""

    def apply_chat_template(self, messages, add_generation_prompt=False, tokenize=True):
        text = "".join(f"<{m['role']}>{m['content']}</s>" for m in messages)
        if add_generation_prompt:
            text += "<assistant>"
        return [ord(c) for c in text]


class SftPureFunctionsTest(unittest.TestCase):
    def test_only_the_final_answer_is_learned(self) -> None:
        messages = [{"role": "user", "content": "Salut"}, {"role": "assistant", "content": "Bonjour"}]
        example = build_example(FakeTokenizer(), messages, max_len=1000)
        learned = [t for t, label in zip(example["input_ids"], example["labels"]) if label != IGNORE_INDEX]
        self.assertEqual("".join(map(chr, learned)), "Bonjour</s>")
        prompt_length = len(FakeTokenizer().apply_chat_template(messages[:-1], add_generation_prompt=True))
        self.assertTrue(all(label == IGNORE_INDEX for label in example["labels"][:prompt_length]))
        self.assertEqual(len(example["input_ids"]), len(example["labels"]))

    def test_truncation_dropping_the_answer_returns_none(self) -> None:
        messages = [{"role": "user", "content": "x" * 100}, {"role": "assistant", "content": "réponse"}]
        self.assertIsNone(build_example(FakeTokenizer(), messages, max_len=50))
        self.assertIsNotNone(build_example(FakeTokenizer(), messages, max_len=140))

    def test_missing_chat_template_is_refused(self) -> None:
        with self.assertRaises(ConfigurationError):
            build_example(object(), [{"role": "user", "content": "a"}, {"role": "assistant", "content": "b"}], 100)

    def test_learning_rate_schedule(self) -> None:
        total = 100
        rates = [learning_rate_at(s, total, 1e-4, 0.1) for s in range(total)]
        self.assertLess(rates[0], rates[5])
        self.assertAlmostEqual(max(rates), 1e-4, places=9)
        self.assertGreater(rates[-1], 0.09e-4)  # ne tombe jamais à zéro : plancher à 10 %
        self.assertTrue(all(a >= b - 1e-12 for a, b in zip(rates[10:], rates[11:])))

    def test_descriptor_suggestion_resets_license_review(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            ws = Workspace(Path(tmp))
            descriptor = load_descriptor(ws.descriptor_path)
            suggestion = descriptor_suggestion(descriptor, ws.config())
        self.assertFalse(suggestion["license"]["reviewed"])
        self.assertEqual(suggestion["adaptation"]["method"], "lora")
        self.assertEqual(suggestion["adaptation"]["base_model_id"], "base-test")
        self.assertTrue(suggestion["version"].endswith("+lora"))
        self.assertTrue(suggestion["adaptation"]["adapter_path"].endswith("adapter"))


class CliTest(unittest.TestCase):
    def run_cli(self, *argv: str) -> tuple[int, str]:
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = main(list(argv))
        return code, buffer.getvalue()

    def test_data_validate_prepare_and_train_plan_end_to_end(self) -> None:
        example = ROOT / "configs" / "data" / "exemple.jsonl"
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "prep"
            code, text = self.run_cli("data", "validate", str(example))
            self.assertEqual(code, 0, text)
            code, text = self.run_cli("data", "prepare", str(example), "--out", str(out), "--eval-suite", str(SUITE), "--val-fraction", "0")
            self.assertEqual(code, 0, text)
            manifest = json.loads((out / "manifest.json").read_text(encoding="utf-8"))
            self.assertTrue(manifest["contamination_checked"])
            self.assertEqual(self.run_cli("data", "prepare", str(example), "--out", str(out))[0], 2)  # n'écrase rien
            bad = Path(tmp) / "bad.jsonl"
            bad.write_text("pas du json\n")
            self.assertEqual(self.run_cli("data", "validate", str(bad))[0], 2)
            self.assertEqual(self.run_cli("data", "prepare", str(bad), "--out", str(Path(tmp) / "o2"))[0], 2)

    def test_train_run_refused_without_confirmation_and_with_invalid_plan(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            ws = Workspace(Path(tmp))
            config_path = Path(tmp) / "train.yaml"
            config_path.write_text(
                yaml.safe_dump(
                    {"base_descriptor": str(ws.descriptor_path), "dataset_dir": str(ws.dataset), "output_dir": str(ws.out), "min_train_records": 50}
                )
            )
            with fake_find_spec():
                code, text = self.run_cli("train", "plan", str(config_path))
                self.assertEqual(code, 0, text)
                self.assertIn("Plan valide", text)
                code, text = self.run_cli("train", "run", str(config_path))  # pas de --confirm-training
                self.assertEqual(code, 2)
                self.assertIn("--confirm-training", text)
                self.assertFalse(ws.out.exists())
            code, text = self.run_cli("train", "run", str(config_path), "--confirm-training")  # dépendances absentes (réel)
            self.assertEqual(code, 2)
            self.assertIn("REFUSÉ", text)
            self.assertFalse(ws.out.exists())


if __name__ == "__main__":
    unittest.main()
