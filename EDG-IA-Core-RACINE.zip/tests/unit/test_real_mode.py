"""Mode réel : chargement via une fabrique de moteur factice, registre, annulation sur délai dépassé."""

from __future__ import annotations

import asyncio
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import yaml

from edgia_core.api.app import create_app
from edgia_core.errors import ConfigurationError
from edgia_core.inference.base import ModelInfo
from edgia_core.inference.llm_engine import LanguageModelEngine
from edgia_core.model.descriptor import ModelDescriptor, load_descriptor
from edgia_core.model.registry import ModelRegistry
from tests.helpers import auth, chat_body, make_settings, request
from tests.unit.test_llm_engine import ScriptedBackend

CHAT = "/v1/chat/completions"
WEIGHTS = b"faux-poids"


class RealModeFixture(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        model_dir = self.root / "weights"
        model_dir.mkdir()
        (model_dir / "config.json").write_text("{}", encoding="utf-8")
        (model_dir / "model.safetensors").write_bytes(WEIGHTS)
        (self.root / "tok").mkdir()
        self.descriptor_path = self.root / "model.yaml"
        self.descriptor_path.write_text(
            yaml.safe_dump(
                {
                    "model_id": "edgia-test",
                    "version": "1.0.0",
                    "weights_path": "weights",
                    "tokenizer_path": "tok",
                    "weights_format": "safetensors",
                    "runtime": "transformers",
                    "license": {"name": "test", "commercial_use_allowed": True, "reviewed": True},
                    "sha256": {"model.safetensors": hashlib.sha256(WEIGHTS).hexdigest()},
                }
            ),
            encoding="utf-8",
        )
        self.backend = ScriptedBackend(["Bonjour", " depuis", " le modèle", " de test"])
        self.loaded: list[ModelDescriptor] = []

    def factory(self, settings, descriptor):  # type: ignore[no-untyped-def]
        self.loaded.append(descriptor)
        info = ModelInfo(id=descriptor.model_id, version=descriptor.version, runtime="fake", is_demo=False)
        return LanguageModelEngine(info, self.backend)

    def real_app(self, **settings: str):
        app = create_app(
            make_settings(mode="real", model_descriptor=str(self.descriptor_path), **settings), engine_factory=self.factory
        )
        self.addCleanup(app.state.ctx.close)
        return app


class ServingTest(RealModeFixture):
    async def test_real_model_is_served_and_not_flagged_as_demo(self) -> None:
        app = self.real_app()
        self.assertEqual(self.loaded[0].model_id, "edgia-test")
        response = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body())
        self.assertEqual(response.status, 200, response.text)
        body = response.json()
        self.assertEqual(body["model"], "edgia-test")
        self.assertEqual(body["choices"][0]["message"]["content"], "Bonjour depuis le modèle de test")
        self.assertFalse(body["edgia"]["demo"])
        self.assertNotIn("notice", body["edgia"])
        self.assertEqual(body["usage"]["prompt_tokens"], 7)
        models = (await request(app, "GET", "/v1/models", headers=auth())).json()
        self.assertFalse(models["data"][0]["edgia"]["demo"])

    async def test_streaming_with_the_real_engine(self) -> None:
        response = await request(self.real_app(), "POST", CHAT, headers=auth(), json_body=chat_body(stream=True))
        events = response.sse_events()
        self.assertEqual(events[-1], "[DONE]")
        text = "".join(json.loads(e)["choices"][0]["delta"].get("content", "") for e in events[:-1])
        self.assertEqual(text, "Bonjour depuis le modèle de test")

    async def test_stop_sequences_reach_the_engine(self) -> None:
        response = await request(
            self.real_app(), "POST", CHAT, headers=auth(), json_body=chat_body(stop=[" le modèle"])
        )
        self.assertEqual(response.json()["choices"][0]["message"]["content"], "Bonjour depuis")

    async def test_timeout_cancels_the_generation_and_frees_the_slot(self) -> None:
        self.backend = ScriptedBackend(["x"] * 300, delay=0.01)
        app = self.real_app(request_timeout_seconds="0.1", max_concurrent_requests="1")
        response = await request(app, "POST", CHAT, headers=auth(), json_body=chat_body())
        self.assertEqual(response.status, 504)
        for _ in range(30):  # le thread de génération s'arrête vite grâce à l'annulation
            if app.state.ctx.gate.in_flight == 0:
                break
            await asyncio.sleep(0.02)
        self.assertEqual(app.state.ctx.gate.in_flight, 0)
        self.assertLess(self.backend.produced, 300)
        self.assertTrue(self.backend.closed_stream)  # le flux du backend a été fermé, pas laissé tourner

    async def test_shutdown_closes_the_model(self) -> None:
        app = self.real_app()
        app.state.ctx.close()
        self.assertTrue(self.backend.closed)

    async def test_loader_failure_prevents_startup(self) -> None:
        def broken(settings, descriptor):  # type: ignore[no-untyped-def]
            raise ConfigurationError("Chargement du modèle impossible (test).")

        with self.assertRaises(ConfigurationError):
            create_app(make_settings(mode="real", model_descriptor=str(self.descriptor_path)), engine_factory=broken)

    async def test_invalid_descriptor_never_reaches_the_loader(self) -> None:
        (self.root / "weights" / "model.safetensors").write_bytes(b"autre contenu")  # somme SHA-256 incorrecte
        with self.assertRaises(ConfigurationError):
            create_app(make_settings(mode="real", model_descriptor=str(self.descriptor_path)), engine_factory=self.factory)
        self.assertEqual(self.loaded, [])


class RegistryStartupTest(RealModeFixture):
    def registry_with_active(self) -> Path:
        path = self.root / "registry.sqlite3"
        registry = ModelRegistry(path)
        descriptor = load_descriptor(self.descriptor_path)
        registry.register(descriptor)
        registry.validate(descriptor.model_id, descriptor.version)
        registry.activate(descriptor.model_id, descriptor.version)
        return path

    def test_serves_the_active_registry_version(self) -> None:
        path = self.registry_with_active()
        app = create_app(make_settings(mode="real", registry_path=str(path)), engine_factory=self.factory)
        app.state.ctx.close()
        self.assertEqual(self.loaded[0].version, "1.0.0")

    def test_registry_without_active_version_refuses_to_start(self) -> None:
        path = self.root / "registry.sqlite3"
        ModelRegistry(path)
        with self.assertRaises(ConfigurationError) as ctx:
            create_app(make_settings(mode="real", registry_path=str(path)), engine_factory=self.factory)
        self.assertIn("aucune version active", " ".join(ctx.exception.problems))

    def test_missing_registry_file_refuses_to_start(self) -> None:
        with self.assertRaises(ConfigurationError):
            create_app(make_settings(mode="real", registry_path=str(self.root / "absent.sqlite3")), engine_factory=self.factory)

    def test_descriptor_and_registry_together_are_refused(self) -> None:
        path = self.registry_with_active()
        settings = make_settings(mode="real", registry_path=str(path), model_descriptor=str(self.descriptor_path))
        with self.assertRaises(ConfigurationError) as ctx:
            create_app(settings, engine_factory=self.factory)
        self.assertIn("pas les deux", " ".join(ctx.exception.problems))

    def test_active_version_whose_files_vanished_refuses_to_start(self) -> None:
        path = self.registry_with_active()
        (self.root / "weights" / "model.safetensors").unlink()
        with self.assertRaises(ConfigurationError):
            create_app(make_settings(mode="real", registry_path=str(path)), engine_factory=self.factory)
        self.assertEqual(self.loaded, [])


if __name__ == "__main__":
    unittest.main()
