"""Tests unitaires du descripteur de modèle (fichiers factices, aucun vrai modèle)."""

from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path

import yaml

from edgia_core.config import MIN_API_KEY_LENGTH, build_serving_report, load_settings
from edgia_core.errors import ConfigurationError
from edgia_core.model.descriptor import (
    Runtime,
    apply_overrides,
    check_model,
    load_descriptor,
)

WEIGHTS_BYTES = b"faux-poids-pour-les-tests"
KEY = "k" * MIN_API_KEY_LENGTH


def descriptor_dict(**overrides: object) -> dict[str, object]:
    base: dict[str, object] = {
        "model_id": "edgia-test",
        "version": "1.0.0",
        "weights_path": "weights/model.safetensors",
        "tokenizer_path": "tokenizer",
        "weights_format": "safetensors",
        "runtime": "transformers",
        "license": {"name": "Licence de test", "commercial_use_allowed": True, "reviewed": True},
    }
    base.update(overrides)
    return base


class DescriptorFixture(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        (self.root / "weights").mkdir()
        (self.root / "tokenizer").mkdir()
        self.weights = self.root / "weights" / "model.safetensors"
        self.weights.write_bytes(WEIGHTS_BYTES)

    def write_descriptor(self, **overrides: object) -> Path:
        path = self.root / "model.yaml"
        path.write_text(yaml.safe_dump(descriptor_dict(**overrides)), encoding="utf-8")
        return path


class LoadingTest(DescriptorFixture):
    def test_valid_descriptor_loads_and_resolves_relative_paths(self) -> None:
        descriptor = load_descriptor(self.write_descriptor())
        self.assertEqual(descriptor.model_id, "edgia-test")
        self.assertEqual(descriptor.weights_path, self.weights.resolve())
        self.assertEqual(descriptor.tokenizer_path, (self.root / "tokenizer").resolve())

    def test_valid_descriptor_passes_checks(self) -> None:
        problems, warnings = check_model(load_descriptor(self.write_descriptor()))
        self.assertEqual(problems, [])
        self.assertTrue(any("SHA-256" in w for w in warnings))

    def test_missing_file_is_rejected(self) -> None:
        with self.assertRaises(ConfigurationError):
            load_descriptor(self.root / "absent.yaml")

    def test_invalid_yaml_is_rejected(self) -> None:
        path = self.root / "model.yaml"
        path.write_text("model_id: [pas fermé", encoding="utf-8")
        with self.assertRaises(ConfigurationError):
            load_descriptor(path)

    def test_non_mapping_yaml_is_rejected(self) -> None:
        path = self.root / "model.yaml"
        path.write_text("- une\n- liste\n", encoding="utf-8")
        with self.assertRaises(ConfigurationError):
            load_descriptor(path)

    def test_unknown_field_is_rejected(self) -> None:
        with self.assertRaises(ConfigurationError):
            load_descriptor(self.write_descriptor(champ_inconnu=1))

    def test_invalid_model_id_is_rejected(self) -> None:
        with self.assertRaises(ConfigurationError):
            load_descriptor(self.write_descriptor(model_id="../evil id"))

    def test_format_runtime_mismatch_is_rejected(self) -> None:
        with self.assertRaises(ConfigurationError):
            load_descriptor(self.write_descriptor(weights_format="gguf", runtime="transformers"))

    def test_pickle_format_is_rejected(self) -> None:
        with self.assertRaises(ConfigurationError):
            load_descriptor(self.write_descriptor(weights_format="pytorch_bin"))

    def test_tokenizer_required_for_transformers(self) -> None:
        data = descriptor_dict()
        del data["tokenizer_path"]
        path = self.root / "model.yaml"
        path.write_text(yaml.safe_dump(data), encoding="utf-8")
        with self.assertRaises(ConfigurationError):
            load_descriptor(path)

    def test_invalid_checksum_format_is_rejected(self) -> None:
        with self.assertRaises(ConfigurationError):
            load_descriptor(self.write_descriptor(sha256={"model.safetensors": "pas-un-hash"}))


class ChecksTest(DescriptorFixture):
    def test_missing_weights_are_reported(self) -> None:
        self.weights.unlink()
        problems, _ = check_model(load_descriptor(self.write_descriptor()))
        self.assertTrue(any("Poids introuvables" in p for p in problems))

    def test_empty_weights_are_reported(self) -> None:
        self.weights.write_bytes(b"")
        problems, _ = check_model(load_descriptor(self.write_descriptor()))
        self.assertTrue(any("vide" in p for p in problems))

    def test_missing_tokenizer_is_reported(self) -> None:
        (self.root / "tokenizer").rmdir()
        problems, _ = check_model(load_descriptor(self.write_descriptor()))
        self.assertTrue(any("Tokenizer introuvable" in p for p in problems))

    def test_unreviewed_license_blocks(self) -> None:
        data = {"name": "L", "commercial_use_allowed": True, "reviewed": False}
        problems, _ = check_model(load_descriptor(self.write_descriptor(license=data)))
        self.assertTrue(any("Licence non vérifiée" in p for p in problems))

    def test_unconfirmed_commercial_use_blocks(self) -> None:
        for value in (None, False):
            data = {"name": "L", "commercial_use_allowed": value, "reviewed": True}
            problems, _ = check_model(load_descriptor(self.write_descriptor(license=data)))
            self.assertTrue(any("Usage commercial" in p for p in problems), value)

    def test_correct_checksum_passes(self) -> None:
        digest = hashlib.sha256(WEIGHTS_BYTES).hexdigest()
        descriptor = load_descriptor(self.write_descriptor(sha256={"model.safetensors": digest}))
        problems, warnings = check_model(descriptor)
        self.assertEqual(problems, [])
        self.assertEqual(warnings, [])

    def test_wrong_checksum_blocks(self) -> None:
        descriptor = load_descriptor(self.write_descriptor(sha256={"model.safetensors": "0" * 64}))
        problems, _ = check_model(descriptor)
        self.assertTrue(any("Somme de contrôle incorrecte" in p for p in problems))

    def test_checksum_path_traversal_is_refused(self) -> None:
        (self.root / "secret.txt").write_text("x", encoding="utf-8")
        descriptor = load_descriptor(self.write_descriptor(sha256={"../secret.txt": "0" * 64}))
        problems, _ = check_model(descriptor)
        self.assertTrue(any("hors du dossier" in p for p in problems))

    def test_gguf_requires_gguf_file(self) -> None:
        path = self.write_descriptor(
            weights_format="gguf", runtime="llama_cpp", weights_path="weights/model.safetensors"
        )
        problems, _ = check_model(load_descriptor(path))
        self.assertTrue(any("gguf" in p for p in problems))

    def test_safetensors_directory_without_files_is_reported(self) -> None:
        path = self.write_descriptor(weights_path="weights")
        self.weights.unlink()
        problems, _ = check_model(load_descriptor(path))
        self.assertTrue(any("aucun fichier .safetensors" in p for p in problems))

    def test_missing_adapter_is_reported(self) -> None:
        adaptation = {"method": "lora", "adapter_path": "adapter-absent"}
        problems, _ = check_model(load_descriptor(self.write_descriptor(adaptation=adaptation)))
        self.assertTrue(any("Adaptateur introuvable" in p for p in problems))


class OverridesTest(DescriptorFixture):
    def test_weights_override_replaces_path(self) -> None:
        descriptor = load_descriptor(self.write_descriptor())
        other = self.root / "elsewhere.safetensors"
        updated = apply_overrides(descriptor, weights_path=other)
        self.assertEqual(updated.weights_path, other)

    def test_incompatible_runtime_override_is_rejected(self) -> None:
        descriptor = load_descriptor(self.write_descriptor())
        with self.assertRaises(ConfigurationError):
            apply_overrides(descriptor, runtime=Runtime.LLAMA_CPP)

    def test_no_override_returns_same_descriptor(self) -> None:
        descriptor = load_descriptor(self.write_descriptor())
        self.assertIs(apply_overrides(descriptor), descriptor)


class RealModeEndToEndTest(DescriptorFixture):
    """Vérifie, à travers la configuration, qu'un modèle complet est accepté et qu'un modèle absent est refusé."""

    def settings(self, descriptor_path: Path):
        return load_settings(
            env={"EDGIA_MODE": "real", "EDGIA_API_KEYS": KEY, "EDGIA_MODEL_DESCRIPTOR": str(descriptor_path)}
        )

    def test_complete_model_is_accepted(self) -> None:
        report = build_serving_report(self.settings(self.write_descriptor()))
        self.assertTrue(report.ok, report.problems)
        self.assertEqual(report.descriptor.model_id, "edgia-test")

    def test_absent_model_refuses_startup(self) -> None:
        path = self.write_descriptor()
        self.weights.unlink()
        report = build_serving_report(self.settings(path))
        self.assertFalse(report.ok)
        self.assertTrue(any("Poids introuvables" in p for p in report.problems))

    def test_env_override_points_to_another_weights_file(self) -> None:
        path = self.write_descriptor()
        self.weights.unlink()
        relocated = self.root / "relocated.safetensors"
        relocated.write_bytes(WEIGHTS_BYTES)
        settings = load_settings(
            env={
                "EDGIA_MODE": "real",
                "EDGIA_API_KEYS": KEY,
                "EDGIA_MODEL_DESCRIPTOR": str(path),
                "EDGIA_MODEL_PATH": str(relocated),
            }
        )
        self.assertTrue(build_serving_report(settings).ok)


if __name__ == "__main__":
    unittest.main()
