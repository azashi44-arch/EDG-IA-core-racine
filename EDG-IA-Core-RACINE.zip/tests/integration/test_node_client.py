"""Le client de référence Node (integration/edgia-core-client.mjs) contre un vrai serveur lancé en processus.

Ignoré si Node n'est pas installé. Vérifie le client de référence, pas l'application EDG-IA elle-même.
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KEY = "node-client-key-" + "x" * 16


@unittest.skipUnless(shutil.which("node"), "Node absent : client de référence non vérifié")
class NodeClientTest(unittest.TestCase):
    def test_client_against_real_server(self) -> None:
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        env = {**os.environ, "PYTHONPATH": str(ROOT / "src"), "EDGIA_PORT": str(port), "EDGIA_API_KEYS": KEY}
        server = subprocess.Popen([sys.executable, "-m", "edgia_core", "serve"], env=env, cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.addCleanup(server.wait)
        self.addCleanup(server.terminate)
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                    break
            except OSError:
                time.sleep(0.1)
        else:
            self.fail("serveur non démarré")
        result = subprocess.run(
            ["node", str(ROOT / "integration" / "smoke.mjs")],
            env={**os.environ, "EDGIA_URL": f"http://127.0.0.1:{port}", "EDGIA_CHECK_API_KEY": KEY},
            capture_output=True, text=True, timeout=60, cwd=ROOT,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        out = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertTrue(out["demoRefused"], "le client doit refuser le mode démonstration par défaut")
        self.assertTrue(out["chat"]["hasText"] and out["chat"]["demo"] and out["chat"]["requestId"] and out["chat"]["usage"])
        self.assertIsNone(out["chat"]["sources"])
        self.assertGreater(out["stream"]["deltas"], 0)
        self.assertTrue(out["stream"]["joinedMatches"])
        self.assertEqual(out["stream"]["finish"], out["stream"]["fullFinish"])
        self.assertIn(out["stream"]["finish"], ("stop", "length"))
        self.assertEqual(out["unknownModel"], {"code": "model_not_found", "status": 404, "requestId": True})
        self.assertEqual(out["badKey"], {"code": "unauthorized", "status": 401})
        self.assertEqual(out["unreachable"], "network_error")


if __name__ == "__main__":
    unittest.main()
