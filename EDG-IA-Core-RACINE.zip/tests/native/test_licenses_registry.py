"""Licences, registre de sources et portes 1 / 2 (spécification v1.1 §5.1–5.2) — S6, S6d."""

import json
import tempfile
import unittest
from pathlib import Path

import _bootstrap  # noqa: F401
import datafixtures as fx

from edgia_core.native.data import licenses
from edgia_core.native.data.registry import SourceRegistry, gate_document
from edgia_core.native.errors import DataError, LicenseError


class TestClasses(unittest.TestCase):
    def test_classification_and_no_equivalence(self):
        self.assertEqual(licenses.license_class("CC0-1.0"), "A")
        self.assertEqual(licenses.license_class("public-domain"), "A")
        for lic in ("CC-BY-4.0", "LO-2.0", "MIT", "BSD-3-Clause", "Apache-2.0"):
            self.assertEqual(licenses.license_class(lic), "B", lic)
        for lic in ("CC-BY-SA-4.0", "GPL-3.0-only", "ODbL-1.0"):
            self.assertEqual(licenses.license_class(lic), "C", lic)
        for lic in ("CC-BY-NC-4.0", "CC-BY-ND-4.0", "proprietary", "ai-service-output"):
            self.assertEqual(licenses.license_class(lic), "D", lic)
        self.assertEqual(licenses.license_class("jamais-vu"), "E")
        self.assertEqual(licenses.canonical_license_id("etalab-2.0"), "LO-2.0")
        # chaque licence de classe B a sa propre fiche d'obligations, et elles sont toutes différentes
        sheets = [tuple(licenses.OBLIGATIONS[x]) for x in ("CC-BY-4.0", "LO-2.0", "MIT", "BSD-2-Clause", "BSD-3-Clause", "Apache-2.0")]
        self.assertEqual(len(set(sheets)), 6)


class TestGate1(unittest.TestCase):
    def test_class_a_with_full_dossier_is_admitted(self):
        self.assertEqual(fx.source("x").training_problems(), [])

    def test_each_missing_requirement_blocks(self):
        cases = {
            "décision": dict(decision_training="pending"), "blocked": dict(decision_training="blocked"),
            "validateur": dict(validator=""), "date": dict(validated_at=""), "licence_sha": dict(license_text_sha256=""),
            "licence_sha_mal_formé": dict(license_text_sha256="xyz"), "archive_sha": dict(archive_sha256=""), "url": dict(url=""),
            "version": dict(collection_version=""), "id_invalide": dict(source_id="a b"),
            "classe_déclarée_fausse": dict(license_class="B"),
            "confiance_déléguée_sans_audit": dict(provenance_basis="publisher_claim"),
        }
        for label, kw in cases.items():
            kw = dict(kw)
            self.assertTrue(fx.source(kw.pop("source_id", "x"), **kw).training_problems(), label)
        self.assertEqual(fx.source("x", provenance_basis="publisher_claim", audit_sample_ref="audit-12").training_problems(), [])

    def test_class_b_requires_written_review(self):
        self.assertTrue(fx.source("b", "CC-BY-4.0").training_problems())
        self.assertEqual(fx.source("b", "CC-BY-4.0", training_review_ref="avis-1").training_problems(), [])
        for lic in ("LO-2.0", "MIT", "BSD-2-Clause", "Apache-2.0"):
            self.assertTrue(fx.source("b", lic).training_problems(), lic)

    def test_class_c_needs_legal_exception_and_d_e_never(self):
        self.assertTrue(fx.source("c", "CC-BY-SA-4.0").training_problems())
        self.assertEqual(fx.source("c", "CC-BY-SA-4.0", legal_exception_ref="décision-juridique-3").training_problems(), [])
        for lic in ("CC-BY-NC-4.0", "proprietary", "inconnue"):
            self.assertTrue(fx.source("d", lic, legal_exception_ref="x", training_review_ref="x").training_problems(), lic)

    def test_gate_document(self):
        reg = fx.registry()
        self.assertIsNone(gate_document(reg, "pd", "CC0-1.0"))
        self.assertIsNone(gate_document(reg, "by", "CC-BY-4.0"))
        self.assertIn("licence du document", gate_document(reg, "by", "CC0-1.0"))
        self.assertIn("inconnue", gate_document(reg, "absente", "CC0-1.0"))
        for sid in ("sa", "nc", "unk", "pending"):
            self.assertIn("non admise", gate_document(reg, sid, reg.get(sid).license_id), sid)


class TestGate2(unittest.TestCase):
    def test_distribution_needs_second_review(self):
        s = fx.source("x")
        self.assertTrue(s.distribution_problems())
        ok = fx.source("x", decision_distribution="approved_distribution", distribution_review_ref="avis-dist-1")
        self.assertEqual(ok.distribution_problems(), [])
        self.assertTrue(fx.source("x", decision_distribution="approved_distribution").distribution_problems())
        self.assertTrue(fx.source("x", decision_training="pending", decision_distribution="approved_distribution",
                                  distribution_review_ref="r").distribution_problems())


class TestRegistryFiles(unittest.TestCase):
    def test_duplicates_unknown_fields_and_hash(self):
        with self.assertRaises(DataError):
            SourceRegistry([fx.source("a"), fx.source("a")])
        with self.assertRaises(DataError):
            SourceRegistry.from_dicts([{**fx.source("a").to_dict(), "bogus": 1}])
        with self.assertRaises(LicenseError):
            fx.registry().get("absente")
        self.assertEqual(fx.registry().registry_hash(), fx.registry().registry_hash())
        self.assertNotEqual(fx.registry().registry_hash(), SourceRegistry([fx.source("pd")]).registry_hash())

    def test_json_and_yaml_loading(self):
        sources = [fx.source("pd").to_dict(), fx.source("by", "CC-BY-4.0", training_review_ref="r").to_dict()]
        with tempfile.TemporaryDirectory() as d:
            j, y = Path(d) / "r.json", Path(d) / "r.yaml"
            j.write_text(json.dumps({"sources": sources}))
            import yaml

            y.write_text(yaml.safe_dump({"sources": sources}))
            self.assertEqual(SourceRegistry.load(j).registry_hash(), SourceRegistry.load(y).registry_hash())
            (Path(d) / "bad.json").write_text('{"x": 1}')
            with self.assertRaises(DataError):
                SourceRegistry.load(Path(d) / "bad.json")
            with self.assertRaises(DataError):
                SourceRegistry.load(Path(d) / "absent.json")

    def test_example_registry_is_not_approved(self):
        example = Path(__file__).resolve().parents[2] / "configs" / "native" / "sources.example.yaml"
        report = SourceRegistry.load(example).training_report()
        self.assertTrue(report)
        self.assertTrue(all(problems for problems in report.values()))  # l'exemple n'admet AUCUNE source : à compléter à la main


if __name__ == "__main__":
    unittest.main()
