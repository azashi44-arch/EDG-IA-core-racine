"""S2 : aller-retour exact, lecture défensive des fichiers safetensors (jamais de pickle)."""

import json
import os
import tempfile
import unittest
from pathlib import Path

import _bootstrap  # noqa: F401
import numpy as np

from edgia_core.native import safetensors_io as st
from edgia_core.native.errors import FormatError


def _file(header: dict, data: bytes, pad: int = 0) -> bytes:
    blob = json.dumps(header, separators=(",", ":")).encode() + b" " * pad
    return len(blob).to_bytes(8, "little") + blob + data


class TestRoundTrip(unittest.TestCase):
    def test_exact_round_trip_all_dtypes(self):
        rng = np.random.default_rng(0)
        tensors = {
            "f32": rng.normal(size=(3, 4)).astype(np.float32), "f64": rng.normal(size=(5,)), "i64": np.arange(7, dtype=np.int64),
            "u16": np.arange(10, dtype=np.uint16), "u8": np.arange(5, dtype=np.uint8), "bool": np.array([True, False]),
            "empty": np.zeros((0, 3), dtype=np.float32), "scalar": np.array(3.5, dtype=np.float32),
        }
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "m.safetensors"
            st.save(path, tensors, {"a": "b"})
            out, meta = st.load_numpy(path)
        self.assertEqual(meta, {"a": "b"})
        for name, value in tensors.items():
            self.assertEqual(out[name].dtype, value.dtype, name)
            self.assertTrue(np.array_equal(out[name], value), name)

    def test_deterministic_bytes_and_alignment(self):
        t = {"b": np.ones(3, dtype=np.float32), "a": np.zeros(2, dtype=np.int64)}
        one, two = st.serialize(t), st.serialize(dict(reversed(list(t.items()))))
        self.assertEqual(one, two)
        self.assertEqual((8 + int.from_bytes(one[:8], "little")) % 8, 0)

    def test_bf16_raw(self):
        raw = st.RawTensor("BF16", (2,), b"\x00\x3f\x80\x3f")
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "x.safetensors"
            st.save(path, {"w": raw})
            with self.assertRaises(FormatError):
                st.load_numpy(path)
            out, _ = st.load_numpy(path, allow_bf16_as_uint16=True)
        self.assertEqual(out["w"].dtype, np.uint16)

    def test_atomic_write_leaves_no_tmp(self):
        with tempfile.TemporaryDirectory() as d:
            st.save(Path(d) / "x.safetensors", {"a": np.ones(2, dtype=np.float32)})
            self.assertEqual(sorted(os.listdir(d)), ["x.safetensors"])

    def test_known_layout(self):
        """Octets construits à la main d'après la spécification publique du format."""
        header = {"w": {"dtype": "F32", "shape": [2], "data_offsets": [0, 8]}}
        blob = _file(header, np.array([1.0, 2.0], dtype="<f4").tobytes(), pad=(-len(json.dumps(header, separators=(",", ":")))) % 8)
        entries, meta, start = st.parse(blob)
        self.assertEqual(entries["w"], st.TensorEntry("F32", (2,), 0, 8))
        self.assertEqual(start % 8, 0)


class TestMalformed(unittest.TestCase):
    def check(self, blob: bytes):
        with self.assertRaises(FormatError):
            st.parse(blob)

    def test_rejections(self):
        ok = {"w": {"dtype": "F32", "shape": [2], "data_offsets": [0, 8]}}
        data = bytes(8)
        self.check(b"")
        self.check((10**12).to_bytes(8, "little"))  # en-tête gigantesque
        self.check((50).to_bytes(8, "little") + b"{}")  # tronqué
        self.check(_file({}, b"")[:8] + b"[1]")  # pas un objet
        self.check(_file({"w": {**ok["w"], "dtype": "F99"}}, data))
        self.check(_file({"w": {**ok["w"], "shape": [3]}}, data))  # taille ≠ forme
        self.check(_file({"w": {**ok["w"], "shape": [-2]}}, data))
        self.check(_file({"w": {**ok["w"], "data_offsets": [0, 99]}}, data))  # hors fichier
        self.check(_file({"w": {**ok["w"], "data_offsets": [4, 0]}}, data))
        self.check(_file(ok, data + b"x"))  # octets en trop
        self.check(_file({"w": {"dtype": "F32", "shape": [1], "data_offsets": [4, 8]}}, data))  # trou au début
        overlap = {"a": {"dtype": "F32", "shape": [2], "data_offsets": [0, 8]}, "b": {"dtype": "F32", "shape": [1], "data_offsets": [4, 8]}}
        self.check(_file(overlap, data))
        self.check(_file({"__metadata__": {"k": 1}, **ok}, data))  # métadonnée non chaîne
        self.check(_file({"w": {"dtype": "F32", "shape": [2]}}, data))  # clés manquantes

    def test_reserved_name_refused_on_write(self):
        with self.assertRaises(FormatError):
            st.serialize({"__metadata__": np.ones(1)})


if __name__ == "__main__":
    unittest.main()
