"""Boucle de génération (cache KV, arrêts, masque de sortie, contexte, annulation, UTF-8) et échantillonnage — T11, F3, F4 —
exécutés avec la RÉFÉRENCE NumPy comme « modèle » (le backend PyTorch réutilise exactement `generate_stream`)."""

import unittest

import _bootstrap  # noqa: F401
import numpy as np
import synthetic

from edgia_core.native import naming
from edgia_core.native.config import PRESETS
from edgia_core.native.errors import NativeError
from edgia_core.native.generation import DoneEvent, GenerationParams, PromptTooLong, TextEvent, generate_stream
from edgia_core.native.reference import numpy_model as R
from edgia_core.native.sampling import sample_next
from edgia_core.native.tokenizer import specials
from edgia_core.native.tokenizer.tokenizer import TrainCorpus, train_tokenizer

TOK = train_tokenizer(TrainCorpus("train", [synthetic.make_text(120_000)]), profile="smoke")
CFG = PRESETS["smoke"]


def numpy_engine(params, cfg):
    state = {"cache": None}

    def forward(ids, reset):
        if reset or state["cache"] is None:
            state["cache"] = R.new_cache(cfg)
        return R.forward(params, cfg, np.asarray(ids), state["cache"])[-1]

    return forward


def scripted(tokens, vocab=1024, high=50.0, fallback=None):
    """« Modèle » factice qui produit exactement la séquence `tokens` (puis END). `fallback` : second meilleur token (utile
    quand le premier choix est interdit : sans lui, l'égalité des autres logits ferait choisir le plus petit identifiant autorisé, EOS)."""
    state = {"i": 0}

    def forward(ids, reset):
        if reset:
            state["i"] = 0
        logits = np.zeros(vocab)
        if fallback is not None:
            logits[fallback] = 1.0
        want = tokens[state["i"]] if state["i"] < len(tokens) else specials.END
        logits[want] = high
        state["i"] += 1
        return logits

    return forward


def collect(events):
    text, done = "", None
    for e in events:
        if isinstance(e, TextEvent):
            text += e.text
        else:
            done = e
    return text, done


class TestSampling(unittest.TestCase):
    def test_greedy_picks_argmax_and_breaks_ties_low(self):
        self.assertEqual(sample_next(np.array([0.1, 3.0, 2.0]), temperature=0, top_p=1.0, rng=None, forbidden=()), 1)
        self.assertEqual(sample_next(np.array([5.0, 5.0, 1.0]), temperature=0, top_p=1.0, rng=None, forbidden=()), 0)

    def test_t11_forbidden_ids_never_returned(self):
        logits = np.zeros(300)
        logits[5] = 1e9  # <|assistant|> : valeur énorme
        logits[200] = 10.0
        rng = np.random.default_rng(0)
        for temp in (0.0, 0.7, 5.0):
            for top_p in (1.0, 0.9, 0.01):
                tok = sample_next(logits, temperature=temp, top_p=top_p, rng=rng, forbidden=specials.FORBIDDEN_OUTPUT_IDS)
                self.assertNotIn(tok, specials.FORBIDDEN_OUTPUT_IDS)
        flat = np.zeros(400)
        draws = {sample_next(flat, temperature=1.0, top_p=1.0, rng=rng, forbidden=specials.FORBIDDEN_OUTPUT_IDS) for _ in range(3000)}
        self.assertFalse(draws & specials.FORBIDDEN_OUTPUT_IDS)
        self.assertTrue(draws & specials.TERMINATOR_IDS)  # END et EOS restent possibles

    def test_all_forbidden_raises(self):
        with self.assertRaises(NativeError):
            sample_next(np.zeros(4), temperature=0, top_p=1.0, rng=None, forbidden={0, 1, 2, 3})
        with self.assertRaises(NativeError):
            sample_next(np.array([np.nan, np.nan]), temperature=0, top_p=1.0, rng=None, forbidden=())

    def test_seeded_sampling_is_reproducible_and_follows_probabilities(self):
        logits = np.log(np.array([0.5, 0.3, 0.2]))
        a = [sample_next(logits, temperature=1.0, top_p=1.0, rng=np.random.default_rng(7), forbidden=()) for _ in range(5)]
        b = [sample_next(logits, temperature=1.0, top_p=1.0, rng=np.random.default_rng(7), forbidden=()) for _ in range(5)]
        self.assertEqual(a, b)
        rng = np.random.default_rng(1)
        counts = np.bincount([sample_next(logits, temperature=1.0, top_p=1.0, rng=rng, forbidden=()) for _ in range(20_000)], minlength=3) / 20_000
        np.testing.assert_allclose(counts, [0.5, 0.3, 0.2], atol=0.02)

    def test_top_p_keeps_the_nucleus(self):
        logits = np.log(np.array([0.6, 0.25, 0.1, 0.05]))
        rng = np.random.default_rng(2)
        draws = {sample_next(logits, temperature=1.0, top_p=0.8, rng=rng, forbidden=()) for _ in range(2000)}
        self.assertEqual(draws, {0, 1})  # 0.6 + 0.25 ≥ 0.8
        only_top = {sample_next(logits, temperature=1.0, top_p=0.01, rng=rng, forbidden=()) for _ in range(200)}
        self.assertEqual(only_top, {0})

    def test_temperature_requires_rng(self):
        with self.assertRaises(NativeError):
            sample_next(np.zeros(3), temperature=1.0, top_p=1.0, rng=None, forbidden=())


class TestGenerationLoop(unittest.TestCase):
    def test_greedy_with_cache_equals_naive_full_recompute(self):
        params = R.init_params(CFG, seed=4)
        for k in params:
            if k.endswith("proj.weight"):
                params[k] = params[k] * 10
        prompt = TOK.encode_chat([{"role": "user", "content": "bonjour le monde"}])
        # référence naïve : à chaque pas, on recalcule TOUT le passé sans cache
        seq, expected = list(prompt), []
        for _ in range(12):
            logits = R.forward(params, CFG, np.array(seq))[-1].copy()
            logits[list(specials.FORBIDDEN_OUTPUT_IDS)] = -np.inf
            nxt = int(np.argmax(logits))
            if nxt in specials.TERMINATOR_IDS:
                break
            expected.append(nxt)
            seq.append(nxt)
        text, done = collect(generate_stream(numpy_engine(params, CFG), TOK, prompt, GenerationParams(max_new_tokens=12), max_seq_len=CFG.max_seq_len))
        self.assertEqual(text, TOK.decode(expected))
        self.assertEqual(done.completion_tokens, len(expected))

    def test_stop_on_end_token(self):
        text, done = collect(generate_stream(scripted([300, 301, 302, specials.END]), TOK, [1, 2, 3], GenerationParams(max_new_tokens=50), max_seq_len=128))
        self.assertEqual(done, DoneEvent("stop", 3))
        self.assertEqual(text, TOK.decode([300, 301, 302]))
        self.assertNotIn("<|end|>", text)

    def test_eos_also_stops_and_forbidden_are_skipped(self):
        # le « modèle » veut d'abord <|assistant|> (interdit) : il doit être remplacé, jamais émis
        forward = scripted([specials.ASSISTANT, specials.EOS], fallback=300)
        text, done = collect(generate_stream(forward, TOK, [1, 2], GenerationParams(max_new_tokens=5), max_seq_len=128))
        self.assertEqual(text, TOK.decode([300]))  # <|assistant|> refusé → remplacé par le meilleur token autorisé
        self.assertEqual(done, DoneEvent("stop", 1))  # puis le « modèle » demande EOS : arrêt
        # sans second choix, l'égalité des logits restants fait choisir le plus petit identifiant autorisé : EOS (comportement défini)
        _, tie_done = collect(generate_stream(scripted([specials.ASSISTANT]), TOK, [1, 2], GenerationParams(max_new_tokens=5), max_seq_len=128))
        self.assertEqual(tie_done, DoneEvent("stop", 0))
        eos_text, eos_done = collect(generate_stream(scripted([300, specials.EOS]), TOK, [1, 2], GenerationParams(max_new_tokens=5), max_seq_len=128))
        self.assertEqual(eos_done, DoneEvent("stop", 1))

    def test_length_limit(self):
        text, done = collect(generate_stream(scripted([300] * 20), TOK, [1, 2], GenerationParams(max_new_tokens=7), max_seq_len=128))
        self.assertEqual(done, DoneEvent("length", 7))
        self.assertEqual(text, TOK.decode([300] * 7))

    def test_context_full_stops_with_length_and_never_overflows(self):
        params = R.init_params(CFG, seed=5)
        prompt = [1] + [300 + i % 50 for i in range(CFG.max_seq_len - 2)]  # ctx − 1 tokens
        self.assertEqual(len(prompt), CFG.max_seq_len - 1)
        text, done = collect(generate_stream(numpy_engine(params, CFG), TOK, prompt, GenerationParams(max_new_tokens=500), max_seq_len=CFG.max_seq_len))
        self.assertEqual(done.finish_reason, "length")  # la référence lève ValueError si le contexte déborde : elle n'a pas levé
        self.assertLessEqual(done.completion_tokens, 2)

    def test_prompt_limits(self):
        with self.assertRaises(PromptTooLong):
            list(generate_stream(scripted([300]), TOK, [], GenerationParams(), max_seq_len=128))
        with self.assertRaises(PromptTooLong):
            list(generate_stream(scripted([300]), TOK, [300] * 128, GenerationParams(), max_seq_len=128))
        ok = list(generate_stream(scripted([300]), TOK, [300] * 127, GenerationParams(max_new_tokens=1), max_seq_len=128))
        self.assertIsInstance(ok[-1], DoneEvent)

    def test_cancellation_ends_without_done(self):
        count = {"n": 0}

        def cancel():
            count["n"] += 1
            return count["n"] > 3

        events = list(generate_stream(scripted([300] * 50), TOK, [1], GenerationParams(max_new_tokens=50), max_seq_len=128, cancel=cancel))
        self.assertTrue(events)
        self.assertFalse(any(isinstance(e, DoneEvent) for e in events))
        self.assertLessEqual(len(events), 3)

    def test_f3_utf8_streaming_through_the_loop(self):
        raw = "é🙂日".encode()
        tokens = [128 + b for b in raw]  # un token par octet : les caractères sont coupés entre deux tokens
        events = list(generate_stream(scripted(tokens + [specials.END]), TOK, [1], GenerationParams(max_new_tokens=50), max_seq_len=128))
        texts = [e.text for e in events if isinstance(e, TextEvent)]
        self.assertEqual("".join(texts), "é🙂日")
        for piece in texts:
            self.assertNotIn("\ufffd", piece)
        self.assertEqual(len(texts), 3)  # un morceau par caractère complet, jamais plus

    def test_invalid_utf8_tail_is_flushed_as_replacement(self):
        events = list(generate_stream(scripted([128 + 0xC3, specials.END]), TOK, [1], GenerationParams(max_new_tokens=5), max_seq_len=128))
        self.assertEqual("".join(e.text for e in events if isinstance(e, TextEvent)), "\ufffd")

    def test_f4_greedy_is_deterministic_and_seed_reproducible(self):
        params = R.init_params(CFG, seed=6)
        for k in params:
            if k.endswith("proj.weight"):
                params[k] = params[k] * 10
        prompt = TOK.encode_chat([{"role": "user", "content": "essai"}])
        run = lambda p: collect(generate_stream(numpy_engine(params, CFG), TOK, prompt, p, max_seq_len=CFG.max_seq_len))  # noqa: E731
        self.assertEqual(run(GenerationParams(max_new_tokens=10)), run(GenerationParams(max_new_tokens=10)))
        hot = GenerationParams(max_new_tokens=10, temperature=1.0, top_p=0.95, seed=42)
        self.assertEqual(run(hot), run(hot))


if __name__ == "__main__":
    unittest.main()
