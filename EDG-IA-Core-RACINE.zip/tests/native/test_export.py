"""Export, vérification, statuts et garde-fous de distribution / de service — S6d, M15 (nommage), F2 (partie sans PyTorch)."""

import json
import tempfile
import unittest
from pathlib import Path

import _bootstrap  # noqa: F401
import datafixtures as fx
import numpy as np
import synthetic

from edgia_core.native import naming
from edgia_core.native.config import PRESETS, PROFILE_TEST, ModelConfig
from edgia_core.native.data.pipeline import DataConfig, build_dataset
from edgia_core.native.errors import ExportError
from edgia_core.native.hashing import sha256_file
from edgia_core.native.reference.numpy_model import init_params
from edgia_core.native.tokenizer.tokenizer import EdgiaTokenizer, TrainCorpus, train_tokenizer
from edgia_core.native.train import export as X

SMOKE = PRESETS["smoke"]
TOK = train_tokenizer(TrainCorpus("train", [synthetic.make_text(120_000)]), profile="smoke")
TENSORS = init_params(SMOKE, dtype=np.float32)


def rehash(directory):
    """Recalcule export_manifest.json après une modification volontaire (pour atteindre les contrôles plus profonds)."""
    manifest = json.loads((directory / "export_manifest.json").read_text())
    manifest["files"] = {n: sha256_file(directory / n) for n in manifest["files"]}
    (directory / "export_manifest.json").write_text(json.dumps(manifest))


class TestExportBasics(unittest.TestCase):
    def test_export_verify_and_untrained_guard(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d) / "m"
            config = X.export_model(TENSORS, SMOKE, TOK, out, status="smoke_test")
            self.assertEqual((config["training_status"], config["distribution_cleared"]), ("smoke_test", False))
            self.assertEqual(config["param_count"], SMOKE.param_count())
            self.assertEqual(X.verify_export(out), [])
            self.assertIn("PAS entraîné", (out / "MODEL_CARD.md").read_text(encoding="utf-8"))
            with self.assertRaises(ExportError):
                X.check_servable(config, allow_untrained=False)
            X.check_servable(config, allow_untrained=True)
            for status in ("pilot", "trained"):
                X.check_servable({"training_status": status}, allow_untrained=False)
            for bad in ({}, {"training_status": "magique"}):
                with self.assertRaises(ExportError):
                    X.check_servable(bad, allow_untrained=True)
            self.assertEqual({p.name for p in out.iterdir()}, {"model.safetensors", "config.json", "tokenizer.json", "tokenizer_config.json",
                                                              "tokenizer_manifest.json", "MODEL_CARD.md", "export_manifest.json"})
            with self.assertRaises(ExportError):                                # jamais d'écrasement
                X.export_model(TENSORS, SMOKE, TOK, out, status="smoke_test")

    def test_export_is_deterministic(self):
        with tempfile.TemporaryDirectory() as d:
            for name in ("a", "b"):
                X.export_model(TENSORS, SMOKE, TOK, Path(d) / name, status="smoke_test")
            self.assertEqual(json.loads((Path(d) / "a" / "export_manifest.json").read_text()),
                             json.loads((Path(d) / "b" / "export_manifest.json").read_text()))

    def test_status_rules(self):
        with tempfile.TemporaryDirectory() as d:
            for status in ("pilot", "trained", "random_init"):
                with self.assertRaises(ExportError, msg=status):                # profil smoke ⇒ uniquement smoke_test
                    X.export_model(TENSORS, SMOKE, TOK, Path(d) / status, status=status)
            with self.assertRaises(ExportError):
                X.export_model(TENSORS, SMOKE, TOK, Path(d) / "x", status="inconnu")
        prod = PRESETS["xs"]
        with self.assertRaises(ExportError):
            X.check_status(prod, "smoke_test")                                  # smoke_test réservé au profil smoke

    def test_tensor_validation(self):
        good = dict(TENSORS)
        cases = {
            "manquant": {k: v for k, v in good.items() if k != naming.FINAL_NORM},
            "lm_head séparé": {**good, "lm_head.weight": good[naming.EMBEDDING]},   # jamais de matrice de sortie séparée
            "mauvaise forme": {**good, naming.EMBEDDING: good[naming.EMBEDDING][:-1]},
            "NaN": {**good, naming.FINAL_NORM: np.full(SMOKE.d_model, np.nan, dtype=np.float32)},
            "entiers": {**good, naming.FINAL_NORM: np.ones(SMOKE.d_model, dtype=np.int64)},
        }
        with tempfile.TemporaryDirectory() as d:
            for label, tensors in cases.items():
                with self.assertRaises(ExportError, msg=label):
                    X.export_model(tensors, SMOKE, TOK, Path(d) / label.replace(" ", "_"), status="smoke_test")

    def test_tokenizer_mismatch_refused(self):
        other = ModelConfig("t", PROFILE_TEST, 500, 32, 2, 4, 2, 8, 64, 40)
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ExportError):
                X.export_model(init_params(other, dtype=np.float32), other, TOK, Path(d) / "x", status="pilot")


class TestVerifyDetectsTampering(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.out = Path(self.tmp.name) / "m"
        X.export_model(TENSORS, SMOKE, TOK, self.out, status="smoke_test")

    def tearDown(self):
        self.tmp.cleanup()

    def test_byte_flip_missing_file_and_empty(self):
        raw = bytearray((self.out / "model.safetensors").read_bytes()); raw[-2] ^= 1; (self.out / "model.safetensors").write_bytes(bytes(raw))
        self.assertTrue(any("empreinte" in p for p in X.verify_export(self.out)))
        (self.out / "tokenizer.json").unlink()
        self.assertTrue(any("absent" in p for p in X.verify_export(self.out)))
        self.assertTrue(X.verify_export(Path(self.tmp.name) / "vide"))

    def test_deeper_checks_with_consistent_hashes(self):
        cfg_path = self.out / "config.json"
        original = json.loads(cfg_path.read_text())
        def mutate(**kw):
            cfg_path.write_text(json.dumps({**original, **kw})); rehash(self.out)
            return X.verify_export(self.out)
        self.assertEqual(mutate(), [])
        self.assertTrue(mutate(param_count=1))
        self.assertTrue(mutate(special_tokens_sha256="0" * 64))
        self.assertTrue(mutate(tokenizer_sha256="0" * 64))
        self.assertTrue(mutate(model_config_sha256="0" * 64))
        self.assertTrue(mutate(architecture="autre"))
        self.assertTrue(mutate(training_status="trained"))                       # profil smoke ⇒ smoke_test seulement
        self.assertTrue(mutate(distribution_cleared=True, training_status="smoke_test"))

    def test_extra_or_misshapen_tensor_in_weights_file(self):
        from edgia_core.native import safetensors_io as st

        tensors, meta = st.load_numpy(self.out / "model.safetensors")
        tensors["lm_head.weight"] = tensors[naming.EMBEDDING]
        st.save(self.out / "model.safetensors", tensors, meta); rehash(self.out)
        self.assertTrue(X.verify_export(self.out))


class TestDistributionGate(unittest.TestCase):
    """S6d : `distribution_cleared` ne devient vrai que si TOUTES les sources ont franchi la porte 2 et que le modèle est `trained`."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        root = Path(cls.tmp.name)
        cls.tok = train_tokenizer(TrainCorpus("train", [synthetic.make_text(120_000)]), profile="test", vocab_size=500)
        cls.cfg = ModelConfig("t", PROFILE_TEST, 500, 32, 2, 4, 2, 8, 64, 40)
        cls.tensors = init_params(cls.cfg, dtype=np.float32)
        cls.cleared = fx.source("pd", decision_distribution="approved_distribution", distribution_review_ref="avis-dist-1")
        cls.not_cleared = fx.source("pd")
        recs = fx.records(40, words=250, seed=12)
        cls.datasets = {}
        for label, src in (("cleared", cls.cleared), ("not_cleared", cls.not_cleared)):
            from edgia_core.native.data.registry import SourceRegistry

            reg = SourceRegistry([src])
            cls.datasets[label] = (reg, root / label)
            build_dataset(recs, reg, DataConfig(val_rate=0.1, test_rate=0.1, min_chars=50, tokenizer_profile="test"), root / label, tokenizer=cls.tok)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def export(self, label, name, **kw):
        reg, ds = self.datasets[label]
        return X.export_model(self.tensors, self.cfg, self.tok, Path(self.tmp.name) / name, dataset_dir=ds, registry=reg, **kw)

    def test_default_is_never_cleared(self):
        config = self.export("cleared", "e1", status="trained")
        self.assertFalse(config["distribution_cleared"])
        self.assertEqual(config["sources_used"], ["pd"])
        self.assertTrue((Path(self.tmp.name) / "e1" / "lineage.json").exists())
        self.assertTrue((Path(self.tmp.name) / "e1" / "DATA_CARD.md").exists())
        self.assertEqual(X.verify_export(Path(self.tmp.name) / "e1"), [])

    def test_gate_2_missing_blocks(self):
        with self.assertRaisesRegex(ExportError, "porte 2"):
            self.export("not_cleared", "e2", status="trained", for_distribution=True)

    def test_only_trained_models_can_be_distributed(self):
        with self.assertRaisesRegex(ExportError, "seule une version"):
            self.export("cleared", "e3", status="pilot", for_distribution=True)

    def test_registry_required_and_success_path(self):
        with self.assertRaises(ExportError):
            X.export_model(self.tensors, self.cfg, self.tok, Path(self.tmp.name) / "e4", status="trained", for_distribution=True)
        config = self.export("cleared", "e5", status="trained", for_distribution=True)
        self.assertTrue(config["distribution_cleared"])
        self.assertEqual(X.verify_export(Path(self.tmp.name) / "e5"), [])

    def test_dataset_tokenizer_mismatch(self):
        other = train_tokenizer(TrainCorpus("train", [synthetic.make_text(120_000, seed=5)]), profile="test", vocab_size=500)
        reg, ds = self.datasets["cleared"]
        with self.assertRaises(ExportError):
            X.export_model(self.tensors, self.cfg, other, Path(self.tmp.name) / "e6", dataset_dir=ds, registry=reg, status="trained")


if __name__ == "__main__":
    unittest.main()
