"""Mini-entraîneur NumPy (régression softmax « bigramme » à embeddings, AdamW écrit à la main, gradients manuels).

Il n'a aucun intérêt comme modèle : il sert à tester, SANS PyTorch, la MÉCANIQUE de reprise commune à la vraie boucle :
chargeur sans état + planificateur + AdamW (moments ET compteur de pas) + checkpoints atomiques + RNG + empreintes.
La règle de mise à jour est celle de `torch.optim.AdamW` (décroissance découplée, correction de biais par compteur de pas).
"""

import math
import random

import numpy as np

from edgia_core.native.config import TrainConfig
from edgia_core.native.train import checkpoint as ckpt
from edgia_core.native.train.schedule import lr_at

FINGERPRINTS = {"model_config": "m", "train_config": "t", "tokenizer": "k", "special_tokens": "s", "dataset": "d"}


def capture_rng():
    py, npst = random.getstate(), np.random.get_state()
    return {"python": [py[0], list(py[1]), py[2]], "numpy_global": [npst[0], [int(x) for x in npst[1]], int(npst[2]), int(npst[3]), float(npst[4])]}


def restore_rng(state):
    py, ns = state["python"], state["numpy_global"]
    random.setstate((py[0], tuple(py[1]), py[2]))
    np.random.set_state((ns[0], np.array(ns[1], dtype=np.uint32), ns[2], ns[3], ns[4]))


class ToyTrainer:
    def __init__(self, loader, cfg: TrainConfig, root, *, vocab=1024, dim=8, seed=0, restore_adam_step=True, perturb_rng=False):
        self.loader, self.cfg, self.root = loader, cfg, root
        self.restore_adam_step, self.perturb_rng = restore_adam_step, perturb_rng
        rng = np.random.default_rng(seed)
        self.p = {"W1": rng.normal(0, 0.02, (vocab, dim)), "W2": rng.normal(0, 0.02, (dim, vocab))}
        self.m = {k: np.zeros_like(v) for k, v in self.p.items()}
        self.v = {k: np.zeros_like(v) for k, v in self.p.items()}
        self.t = {k: 0 for k in self.p}
        self.step = 0
        self.losses = []

    def loss_and_grads(self, batch):
        x, y = batch[:, :-1].reshape(-1), batch[:, 1:].reshape(-1)
        h = self.p["W1"][x]
        logits = h @ self.p["W2"]
        logits -= logits.max(axis=1, keepdims=True)
        prob = np.exp(logits)
        prob /= prob.sum(axis=1, keepdims=True)
        loss = float(-np.log(prob[np.arange(len(y)), y]).mean())
        d = prob
        d[np.arange(len(y)), y] -= 1.0
        d /= len(y)
        g2 = h.T @ d
        g1 = np.zeros_like(self.p["W1"])
        np.add.at(g1, x, d @ self.p["W2"].T)
        return loss, {"W1": g1, "W2": g2}

    def run_to(self, stop):
        cfg = self.cfg
        while self.step < stop:
            if self.perturb_rng:  # S13 : l'aléa global ne doit avoir AUCUNE influence
                random.seed(self.step * 7 + 1); random.random(); np.random.seed(self.step); np.random.rand(5)
            loss, grads = self.loss_and_grads(self.loader.get_batch(self.step))
            norm = math.sqrt(sum(float((g ** 2).sum()) for g in grads.values()))
            scale = min(1.0, cfg.grad_clip / (norm + 1e-6))
            lr = lr_at(self.step, cfg)
            for k in self.p:
                g = grads[k] * scale
                if k == "W2":  # groupe « décroissance » : matrice hors embeddings
                    self.p[k] *= 1 - lr * cfg.weight_decay
                self.t[k] += 1
                self.m[k] = cfg.beta1 * self.m[k] + (1 - cfg.beta1) * g
                self.v[k] = cfg.beta2 * self.v[k] + (1 - cfg.beta2) * g * g
                bc1, bc2 = 1 - cfg.beta1 ** self.t[k], 1 - cfg.beta2 ** self.t[k]
                self.p[k] = self.p[k] - (lr / bc1) * self.m[k] / (np.sqrt(self.v[k]) / math.sqrt(bc2) + cfg.adam_eps)
            self.step += 1
            self.losses.append(loss)

    def save(self, **kw):
        opt = {f"{k}.exp_avg": self.m[k] for k in self.p} | {f"{k}.exp_avg_sq": self.v[k] for k in self.p}
        state = {"adam_steps": dict(self.t), "fingerprints": FINGERPRINTS, "environment": {}, "train_config": self.cfg.to_dict()}
        return ckpt.save_checkpoint(self.root, self.step, model=dict(self.p), optimizer=opt, trainer_state=state, rng_state=capture_rng(), **kw)

    def load_latest(self):
        steps = ckpt.list_checkpoints(self.root)
        loaded = ckpt.load_checkpoint(self.root / ckpt.step_dir_name(steps[-1]))
        ckpt.check_resume_compatibility(loaded["trainer_state"], FINGERPRINTS)
        self.p = {k: loaded["model"][k].copy() for k in self.p}
        self.m = {k: loaded["optimizer"][f"{k}.exp_avg"].copy() for k in self.p}
        self.v = {k: loaded["optimizer"][f"{k}.exp_avg_sq"].copy() for k in self.p}
        if self.restore_adam_step:
            self.t = dict(loaded["trainer_state"]["adam_steps"])
        else:  # ERREUR VOLONTAIRE (test de sensibilité S4b) : compteur de pas d'Adam non restauré
            self.t = {k: 0 for k in self.p}
        restore_rng(loaded["rng_state"])
        self.step = int(loaded["trainer_state"]["step"])
