"""Non-régression du projet EXISTANT (au sens de l'intégrité des fichiers) : le prototype phase 9 et tous les fichiers d'origine
sont inchangés ; seules les 3 modifications déclarées (patches) existent ; elles sont réversibles."""

import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import _bootstrap  # noqa: F401

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))
import verify_untouched  # noqa: E402
from baseline_manifest import sha256_file  # noqa: E402


class TestUntouched(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = verify_untouched.verify(ROOT)

    def test_overall(self):
        self.assertTrue(self.report["ok"], verify_untouched.render(self.report))
        self.assertEqual(self.report["baseline_files"], 230)
        self.assertEqual(self.report["deleted"], [])
        self.assertEqual(self.report["modified_unexpected"], [])
        self.assertEqual(sorted(self.report["modified_declared"]),
                         ["pyproject.toml", "src/edgia_core/model/descriptor.py", "src/edgia_core/model/loader.py"])

    def test_phase9_prototype_is_byte_identical(self):
        baseline = dict(line.split("  ", 1)[::-1] for line in (ROOT / "native_baseline" / "BASELINE_SHA256.txt").read_text().splitlines())
        proto = {rel: sha for rel, sha in baseline.items() if rel.startswith("src/edgia_core/custom_model/") or rel.startswith("tests/unit/test_custom")}
        self.assertTrue(proto)
        for rel, sha in proto.items():
            self.assertEqual(sha256_file(ROOT / rel), sha, rel)

    def test_originals_match_baseline_and_patched_files_differ(self):
        import json

        declared = json.loads((ROOT / "native_baseline" / "PATCHED_FILES.json").read_text())
        for info in declared["modified_files"]:
            self.assertEqual(sha256_file(ROOT / info["original_copy"]), info["baseline_sha256"])
            self.assertEqual(sha256_file(ROOT / info["path"]), info["patched_sha256"])
            self.assertNotEqual(info["baseline_sha256"], info["patched_sha256"])

    def test_reverse_patches_restore_the_originals(self):
        if shutil.which("patch") is None:
            self.skipTest("commande `patch` absente")
        import json

        declared = json.loads((ROOT / "native_baseline" / "PATCHED_FILES.json").read_text())
        with tempfile.TemporaryDirectory() as d:
            for info in declared["modified_files"]:
                target = Path(d) / info["path"]
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(ROOT / info["path"], target)
            for info in declared["modified_files"]:
                result = subprocess.run(["patch", "-R", "-p1", "-d", d, "-i", str(ROOT / info["patch"])], capture_output=True, text=True)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            for info in declared["modified_files"]:
                self.assertEqual(sha256_file(Path(d) / info["path"]), info["baseline_sha256"], info["path"])

    def test_the_checker_detects_violations(self):
        """Test de sensibilité : une modification non déclarée, une suppression et un ajout hors zone doivent être signalés."""
        with tempfile.TemporaryDirectory() as d:
            copy = Path(d) / "p"
            # NB : le ZIP d'origine CONTIENT des .pyc (Python 3.13) et un dossier .pytest_cache : ils font partie de la référence (230 fichiers).
            shutil.copytree(ROOT, copy, ignore=shutil.ignore_patterns("*.cpython-312.pyc", "*.cpython-311.pyc"))
            self.assertTrue(verify_untouched.verify(copy)["ok"])
            (copy / "src/edgia_core/api/app.py").write_text("# modifié\n")
            (copy / "src/edgia_core/custom_model/__init__.py").unlink()
            (copy / "intrus.txt").write_text("x")
            report = verify_untouched.verify(copy)
            self.assertFalse(report["ok"])
            self.assertIn("src/edgia_core/api/app.py", report["modified_unexpected"])
            self.assertIn("src/edgia_core/custom_model/__init__.py", report["deleted"])
            self.assertIn("intrus.txt", report["added_unexpected"])
            (copy / "src/edgia_core/model/loader.py").write_text("# patch non déclaré\n")
            self.assertIn("src/edgia_core/model/loader.py", verify_untouched.verify(copy)["modified_unexpected"])


if __name__ == "__main__":
    unittest.main()
