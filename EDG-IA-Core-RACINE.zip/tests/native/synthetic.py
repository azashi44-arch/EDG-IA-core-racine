"""Corpus SYNTHÉTIQUE déterministe pour les tests (aucune donnée réelle, aucun droit d'auteur).

Les « mots » sont assemblés à partir de syllabes pseudo-françaises ; l'échantillonnage est de type Zipf. Le texte n'a
aucun sens : il sert uniquement à exercer le code (statistiques de fusions, accents, chiffres, ponctuation, sauts de ligne).
"""

from __future__ import annotations

import random

_CONS = ["b", "c", "d", "f", "g", "l", "m", "n", "p", "r", "s", "t", "v", "ch", "qu", "gn", "tr", "pr"]
_VOW = ["a", "e", "i", "o", "u", "é", "è", "ê", "à", "ou", "on", "an", "in", "eau"]
_PUNCT = [",", ".", " !", " ?", " ;", " :", "'", "-"]


def make_vocabulary(size: int, seed: int = 7) -> list[str]:
    rng = random.Random(seed)
    words: set[str] = set()
    while len(words) < size:
        n = rng.choice([1, 2, 2, 3, 3, 4])
        words.add("".join(rng.choice(_CONS) + rng.choice(_VOW) for _ in range(n)))
    return sorted(words)


def make_text(n_words: int, *, vocab_size: int = 3000, seed: int = 11, paragraph: int = 40) -> str:
    rng = random.Random(seed)
    vocab = make_vocabulary(vocab_size, seed=7)
    weights = [1.0 / (rank + 1) for rank in range(len(vocab))]
    pieces: list[str] = []
    for i in range(n_words):
        word = rng.choices(vocab, weights)[0]
        if rng.random() < 0.08:
            word = word.capitalize()
        if rng.random() < 0.03:
            word += str(rng.randint(0, 2099))
        pieces.append(word)
        if rng.random() < 0.1:
            pieces.append(rng.choice(_PUNCT).strip() if rng.random() < 0.5 else rng.choice(_PUNCT))
        if (i + 1) % paragraph == 0:
            pieces.append("\n\n")
    return " ".join(pieces)


def make_documents(n_docs: int, *, words_per_doc: int = 120, seed: int = 3) -> list[str]:
    return [make_text(words_per_doc, seed=seed * 100_003 + i) for i in range(n_docs)]
