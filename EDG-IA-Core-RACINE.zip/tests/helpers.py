"""Outils de test : client ASGI minimal (httpx n'est pas installable dans l'environnement de développement)."""

from __future__ import annotations

import asyncio
import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from edgia_core.config import MIN_API_KEY_LENGTH, Settings, load_settings

API_KEY = "a" * MIN_API_KEY_LENGTH
OTHER_KEY = "b" * MIN_API_KEY_LENGTH


def make_settings(**overrides: str) -> Settings:
    """Configuration de test : mode démo, une clé valide, valeurs modifiables via `EDGIA_*` sans préfixe."""
    env = {"EDGIA_API_KEYS": API_KEY}
    env.update({f"EDGIA_{key.upper()}": value for key, value in overrides.items()})
    return load_settings(env=env)


@dataclass
class Response:
    status: int
    headers: dict[str, str]
    chunks: list[bytes] = field(default_factory=list)

    @property
    def body(self) -> bytes:
        return b"".join(self.chunks)

    @property
    def text(self) -> str:
        return self.body.decode("utf-8")

    def json(self) -> Any:
        return json.loads(self.body)

    def sse_events(self) -> list[str]:
        """Charges utiles des événements `data:` d'une réponse SSE (y compris `[DONE]`)."""
        return [block[len("data: ") :] for block in self.text.split("\n\n") if block.startswith("data: ")]


def auth(key: str = API_KEY) -> dict[str, str]:
    return {"Authorization": f"Bearer {key}"}


async def request(
    app: Any,
    method: str,
    path: str,
    *,
    headers: Mapping[str, str] | None = None,
    body: bytes = b"",
    json_body: Any = None,
    body_chunks: Sequence[bytes] | None = None,
    client: tuple[str, int] = ("203.0.113.9", 50000),
) -> Response:
    """Appelle l'application ASGI directement.

    `body_chunks` envoie un corps en plusieurs morceaux, sans en-tête Content-Length.
    """
    sent_headers = dict(headers or {})
    if json_body is not None:
        body = json.dumps(json_body).encode("utf-8")
        sent_headers.setdefault("Content-Type", "application/json")
    if body_chunks is None and "content-length" not in {k.lower() for k in sent_headers}:
        sent_headers["Content-Length"] = str(len(body))
    pieces = list(body_chunks) if body_chunks is not None else [body]

    incoming: list[dict[str, Any]] = [
        {"type": "http.request", "body": piece, "more_body": index < len(pieces) - 1} for index, piece in enumerate(pieces)
    ]
    done = asyncio.Event()
    response = Response(status=0, headers={})

    async def receive() -> dict[str, Any]:
        if incoming:
            return incoming.pop(0)
        await done.wait()
        return {"type": "http.disconnect"}

    async def send(message: dict[str, Any]) -> None:
        if message["type"] == "http.response.start":
            response.status = message["status"]
            response.headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in message["headers"]}
        elif message["type"] == "http.response.body":
            if message.get("body"):
                response.chunks.append(message["body"])
            if not message.get("more_body", False):
                done.set()

    scope = {
        "type": "http",
        "asgi": {"version": "3.0", "spec_version": "2.3"},
        "http_version": "1.1",
        "method": method,
        "scheme": "http",
        "path": path,
        "raw_path": path.encode("ascii"),
        "root_path": "",
        "query_string": b"",
        "headers": [(k.lower().encode("latin-1"), v.encode("latin-1")) for k, v in sent_headers.items()],
        "client": client,
        "server": ("testserver", 80),
    }
    try:
        await app(scope, receive, send)
    finally:
        done.set()
    return response


def chat_body(content: str = "Bonjour", **extra: Any) -> dict[str, Any]:
    body: dict[str, Any] = {"messages": [{"role": "user", "content": content}]}
    body.update(extra)
    return body
