"""Prototype expérimental du modèle Transformer natif EDG-IA (phase 9)."""
from .tokenizer import ByteTokenizer

__all__ = ["ByteTokenizer"]
