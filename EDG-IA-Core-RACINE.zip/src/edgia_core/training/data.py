"""Format des données d'adaptation : une conversation par ligne (JSONL), avec provenance et licence obligatoires.

Règles qui découlent des principes du projet :
- aucune donnée sans source ni licence connues ;
- les conversations d'utilisateurs ne sont jamais utilisées automatiquement : elles exigent un consentement explicite
  inscrit dans la donnée ET une autorisation explicite à la préparation (voir `prepare.py`) ;
- la dernière réponse est celle que le modèle doit apprendre (rôle « assistant »).
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterator
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from edgia_core.errors import ConfigurationError, format_validation_error

MAX_LINE_BYTES = 256 * 1024
_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:\-]{0,127}$")
UNKNOWN_LICENSES = frozenset({"", "inconnue", "inconnu", "unknown", "n/a", "na", "none", "aucune", "?", "tbd", "à compléter", "a completer"})

Origin = Literal["curated", "synthetic", "licensed", "public_domain", "user_conversation"]


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class DataTurn(_Strict):
    role: Literal["system", "user", "assistant"]
    content: str


class DataRecord(_Strict):
    id: str
    messages: list[DataTurn] = Field(min_length=2)
    source: str = Field(min_length=1, description="D'où vient la donnée (livre, équipe, jeu de données, outil…)")
    license: str = Field(min_length=1, description="Licence ou base légale d'utilisation pour l'entraînement")
    origin: Origin
    consent: bool = False  # consentement explicite (obligatoire pour user_conversation)
    group: str | None = None  # données apparentées : elles restent du même côté du découpage
    lang: str | None = None
    tags: list[str] = Field(default_factory=list)

    @field_validator("id")
    @classmethod
    def _check_id(cls, value: str) -> str:
        if not _ID_RE.match(value):
            raise ValueError("identifiant invalide (lettres, chiffres, « _ . : - », 128 caractères au plus)")
        return value

    @field_validator("license")
    @classmethod
    def _check_license(cls, value: str) -> str:
        if value.strip().lower() in UNKNOWN_LICENSES:
            raise ValueError("licence inconnue : une donnée sans licence connue est refusée")
        return value

    @model_validator(mode="after")
    def _check_conversation(self) -> DataRecord:
        if self.messages[-1].role != "assistant":
            raise ValueError("le dernier message doit être la réponse de l'assistant")
        if not any(m.role == "user" for m in self.messages):
            raise ValueError("au moins un message de l'utilisateur est requis")
        if self.origin == "user_conversation" and not self.consent:
            raise ValueError("une conversation d'utilisateur exige consent=true (consentement explicite et vérifiable)")
        return self


def iter_records(path: Path | str) -> Iterator[tuple[int, DataRecord | list[str]]]:
    """Lit un fichier JSONL. Produit (numéro de ligne, enregistrement) ou (numéro de ligne, liste de problèmes)."""
    file = Path(path)
    try:
        handle = file.open("rb")
    except OSError as exc:
        raise ConfigurationError(f"Fichier de données illisible : {file} ({type(exc).__name__})") from None
    with handle:
        for number, raw in enumerate(handle, start=1):
            if not raw.strip():
                continue
            if len(raw) > MAX_LINE_BYTES:
                yield number, [f"ligne trop longue (> {MAX_LINE_BYTES} octets)"]
                continue
            try:
                payload = json.loads(raw.decode("utf-8"))
            except (ValueError, RecursionError):
                yield number, ["JSON ou UTF-8 invalide"]
                continue
            try:
                yield number, DataRecord.model_validate(payload)
            except ValidationError as exc:
                yield number, format_validation_error(exc)


def load_records(paths: list[Path] | Path) -> tuple[list[DataRecord], list[str]]:
    """Charge un ou plusieurs fichiers. Retourne (enregistrements valides, problèmes avec fichier et ligne).

    Les problèmes ne recopient jamais le contenu des conversations. Un identifiant dupliqué est un problème.
    """
    files = [paths] if isinstance(paths, Path) else list(paths)
    records: list[DataRecord] = []
    problems: list[str] = []
    seen: set[str] = set()
    for file in files:
        for number, item in iter_records(file):
            if isinstance(item, list):
                problems.extend(f"{file.name} ligne {number} : {p}" for p in item)
                continue
            if item.id in seen:
                problems.append(f"{file.name} ligne {number} : identifiant dupliqué « {item.id} »")
                continue
            seen.add(item.id)
            records.append(item)
    return records, problems
