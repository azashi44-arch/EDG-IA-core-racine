"""Entraînement d'adaptation SFT/LoRA.

ÉTAT : ÉCRIT MAIS JAMAIS EXÉCUTÉ. Ni PyTorch, ni Transformers, ni PEFT ne sont installables dans l'environnement de
développement. Les fonctions pures (préparation d'un exemple, calendrier du taux d'apprentissage) sont testées avec un
faux tokenizer ; la boucle d'entraînement, elle, est une première version à valider chez l'équipe d'entraînement, sur un
très petit jeu de données, avant tout long entraînement.

Principes : bibliothèques importées au dernier moment ; `local_files_only` et `trust_remote_code=False` ; seule la
dernière réponse de l'assistant est apprise (le reste du prompt est masqué) ; rien n'est lancé sans que le plan soit
valide ; le descripteur produit garde `license.reviewed = false` (l'équipe doit relire la licence du modèle adapté).
"""

from __future__ import annotations

import hashlib
import json
import math
import time
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from edgia_core.errors import ConfigurationError
from edgia_core.training.config import TrainingConfig
from edgia_core.training.plan import TrainingPlan

IGNORE_INDEX = -100


def build_example(tokenizer: Any, messages: Sequence[dict], max_len: int) -> dict | None:
    """Transforme une conversation en (input_ids, labels). Seule la dernière réponse est apprise.

    Retourne None si, après troncature à `max_len`, plus aucun token de la réponse n'est conservé (exemple inutilisable).
    Le tokenizer doit fournir `apply_chat_template` ; sinon l'erreur est explicite (pas de format inventé).
    """
    if not hasattr(tokenizer, "apply_chat_template"):
        raise ConfigurationError("Le tokenizer n'a pas de modèle de conversation (chat_template) : entraînement refusé.")
    prompt = list(tokenizer.apply_chat_template(list(messages[:-1]), add_generation_prompt=True, tokenize=True))
    full = list(tokenizer.apply_chat_template(list(messages), add_generation_prompt=False, tokenize=True))
    if full[: len(prompt)] != prompt:
        raise ConfigurationError("Le modèle de conversation du tokenizer n'est pas cohérent (le prompt n'est pas un préfixe).")
    labels = [IGNORE_INDEX] * len(prompt) + full[len(prompt) :]
    full, labels = full[:max_len], labels[:max_len]
    if all(label == IGNORE_INDEX for label in labels):
        return None
    return {"input_ids": full, "labels": labels}


def learning_rate_at(step: int, total_steps: int, base_lr: float, warmup_ratio: float) -> float:
    """Montée linéaire puis décroissance en cosinus jusqu'à 10 % du taux de base."""
    warmup = int(total_steps * warmup_ratio)
    if warmup and step < warmup:
        return base_lr * (step + 1) / warmup
    progress = (step - warmup) / max(1, total_steps - warmup)
    return base_lr * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * min(1.0, progress))))


def descriptor_suggestion(descriptor: Any, config: TrainingConfig) -> dict:
    """Descripteur proposé pour le modèle adapté. La licence est REMISE À « non vérifiée » : un humain doit la relire."""
    data = descriptor.model_dump(mode="json")
    data["version"] = f"{descriptor.version}+lora"
    data["display_name"] = f"{descriptor.display_name or descriptor.model_id} (adapté LoRA, à valider)"
    data["adaptation"] = {
        "method": "lora",
        "base_model_id": descriptor.model_id,
        "adapter_path": str((config.output_dir / "adapter").resolve()),
    }
    data["license"] = {**data["license"], "reviewed": False, "notes": "Licence du modèle adapté à relire par un humain avant tout déploiement."}
    return data


def _read_jsonl(path: Path) -> list[list[dict]]:
    return [json.loads(line)["messages"] for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_sft(config: TrainingConfig, plan: TrainingPlan) -> dict:  # pragma: no cover - nécessite torch, transformers, peft
    """Lance l'entraînement. Refuse si le plan n'est pas valide. Retourne le rapport (aussi écrit dans output_dir)."""
    if not plan.ok or plan.descriptor is None:
        raise ConfigurationError(["Entraînement refusé : le plan n'est pas valide."] + plan.problems)

    import torch  # noqa: PLC0415
    from peft import LoraConfig, get_peft_model  # noqa: PLC0415
    from transformers import AutoModelForCausalLM, AutoTokenizer  # noqa: PLC0415

    descriptor = plan.descriptor
    torch.manual_seed(config.seed)
    tokenizer = AutoTokenizer.from_pretrained(str(descriptor.tokenizer_path), local_files_only=True, trust_remote_code=False)
    dtype = torch.bfloat16 if config.bf16 else torch.float32
    model = AutoModelForCausalLM.from_pretrained(
        str(descriptor.weights_path), local_files_only=True, trust_remote_code=False, use_safetensors=True, torch_dtype=dtype
    )
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)
    model.gradient_checkpointing_enable()
    model.enable_input_require_grads()
    model = get_peft_model(
        model,
        LoraConfig(
            r=config.lora.r, lora_alpha=config.lora.alpha, lora_dropout=config.lora.dropout,
            target_modules=config.lora.target_modules, task_type="CAUSAL_LM",
        ),
    )

    def load(name: str) -> tuple[list[dict], int]:
        examples, skipped = [], 0
        for messages in _read_jsonl(config.dataset_dir / name):
            example = build_example(tokenizer, messages, config.max_seq_len)
            if example is None:
                skipped += 1
            else:
                examples.append(example)
        return examples, skipped

    train, skipped_train = load("train.jsonl")
    validation, _ = load("validation.jsonl")
    if len(train) < config.min_train_records:
        raise ConfigurationError(f"Trop peu d'exemples utilisables après troncature : {len(train)}.")

    def collate(batch: list[dict]) -> dict:
        width = max(len(e["input_ids"]) for e in batch)
        pad = tokenizer.pad_token_id if tokenizer.pad_token_id is not None else 0
        ids = [e["input_ids"] + [pad] * (width - len(e["input_ids"])) for e in batch]
        labels = [e["labels"] + [IGNORE_INDEX] * (width - len(e["labels"])) for e in batch]
        mask = [[1] * len(e["input_ids"]) + [0] * (width - len(e["input_ids"])) for e in batch]
        return {k: torch.tensor(v, device=device) for k, v in (("input_ids", ids), ("labels", labels), ("attention_mask", mask))}

    optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=config.learning_rate, weight_decay=config.weight_decay)
    generator = torch.Generator().manual_seed(config.seed)
    batch_size, accumulation = config.per_device_batch_size, config.gradient_accumulation_steps
    steps_per_epoch = math.ceil(len(train) / (batch_size * accumulation))
    total_steps = steps_per_epoch * config.epochs
    losses: list[dict] = []
    started = time.monotonic()
    step = 0

    def evaluate() -> float | None:
        if not validation:
            return None
        model.eval()
        total, count = 0.0, 0
        with torch.no_grad():
            for i in range(0, len(validation), batch_size):
                out = model(**collate(validation[i : i + batch_size]))
                total += float(out.loss)
                count += 1
        model.train()
        return total / max(1, count)

    model.train()
    for epoch in range(config.epochs):
        order = torch.randperm(len(train), generator=generator).tolist()
        micro = [order[i : i + batch_size] for i in range(0, len(order), batch_size)]
        for start in range(0, len(micro), accumulation):
            group = micro[start : start + accumulation]
            running = 0.0
            for indexes in group:
                loss = model(**collate([train[i] for i in indexes])).loss / len(group)
                loss.backward()
                running += float(loss)
            torch.nn.utils.clip_grad_norm_(model.parameters(), config.max_grad_norm)
            for param_group in optimizer.param_groups:
                param_group["lr"] = learning_rate_at(step, total_steps, config.learning_rate, config.warmup_ratio)
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
            step += 1
            if not math.isfinite(running):
                raise RuntimeError("Perte non finie : entraînement interrompu (taux d'apprentissage trop élevé ou données invalides).")
            losses.append({"step": step, "train_loss": round(running, 5)})
        losses.append({"epoch": epoch + 1, "validation_loss": evaluate()})

    config.output_dir.mkdir(parents=True, exist_ok=True)
    adapter_dir = config.output_dir / "adapter"
    model.save_pretrained(str(adapter_dir))
    report = {
        "status": "terminé",
        "duration_s": round(time.monotonic() - started, 1),
        "optimizer_steps": step,
        "train_examples": len(train),
        "skipped_train_examples": skipped_train,
        "validation_examples": len(validation),
        "losses": losses,
        "dataset_manifest_sha256": _sha256(config.dataset_dir / "manifest.json"),
        "base_model": f"{descriptor.model_id} {descriptor.version}",
        "adapter_files": {f.name: _sha256(f) for f in sorted(adapter_dir.glob("*")) if f.is_file()},
        "libraries": {"torch": torch.__version__},
        "note": "Adaptateur NON évalué et NON approuvé : évaluez-le avec `edgia-core eval` puis faites relire la licence avant tout déploiement.",
    }
    (config.output_dir / "training_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    import yaml  # noqa: PLC0415

    (config.output_dir / "descriptor_suggestion.yaml").write_text(
        yaml.safe_dump(descriptor_suggestion(descriptor, config), allow_unicode=True, sort_keys=False), encoding="utf-8"
    )
    return report
