"""Détection et masquage de données personnelles évidentes dans les textes d'entraînement.

Limite assumée : ce sont des motifs (courriel, téléphone, longues suites de chiffres, IBAN, adresses web avec
identifiants). Ils NE détectent PAS les noms, adresses postales, ni les informations personnelles décrites en toutes
lettres. Une relecture humaine d'un échantillon reste nécessaire avant tout entraînement.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

_EMAIL = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
_IBAN = re.compile(r"\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){3,7}(?:[ ]?[A-Z0-9]{1,4})?\b")
_URL_CREDENTIALS = re.compile(r"\b[a-z][a-z0-9+.\-]*://[^\s/:@]+:[^\s/@]+@\S+", re.IGNORECASE)
# Suite de chiffres (avec espaces, points, tirets) d'au moins 9 chiffres : téléphones, cartes, comptes.
_DIGIT_RUN = re.compile(r"(?<![\d])(?:\+|00)?\d(?:[ .\-]?\d){8,}(?![\d])")
_CURRENCY_AFTER = re.compile(r"\s*(?:f\s?cfa|xaf|xof|cfa|francs?|€|eur|\$|usd)\b", re.IGNORECASE)


@dataclass
class PiiReport:
    counts: dict[str, int] = field(default_factory=dict)

    def add(self, kind: str) -> None:
        self.counts[kind] = self.counts.get(kind, 0) + 1

    @property
    def total(self) -> int:
        return sum(self.counts.values())


def scrub(text: str) -> tuple[str, PiiReport]:
    """Retourne le texte masqué (`[EMAIL]`, `[TELEPHONE_OU_NUMERO]`, `[IBAN]`, `[URL_AVEC_IDENTIFIANTS]`) et le compte."""
    report = PiiReport()

    def sub(pattern: re.Pattern[str], placeholder: str, kind: str, value: str) -> str:
        def repl(match: re.Match[str]) -> str:
            report.add(kind)
            return placeholder

        return pattern.sub(repl, value)

    text = sub(_URL_CREDENTIALS, "[URL_AVEC_IDENTIFIANTS]", "url_identifiants", text)
    text = sub(_EMAIL, "[EMAIL]", "email", text)
    text = sub(_IBAN, "[IBAN]", "iban", text)

    def digits(match: re.Match[str]) -> str:
        # Un montant (« 150 000 000 FCFA ») n'est pas un numéro de téléphone.
        if _CURRENCY_AFTER.match(text_holder[0], match.end()):
            return match.group(0)
        report.add("numero")
        return "[TELEPHONE_OU_NUMERO]"

    text_holder = [text]
    text = _DIGIT_RUN.sub(digits, text)
    return text, report


def contains_pii(text: str) -> bool:
    return scrub(text)[1].total > 0
