"""Authentification, limites de débit et protections. Implémentation prévue en phase 2."""
