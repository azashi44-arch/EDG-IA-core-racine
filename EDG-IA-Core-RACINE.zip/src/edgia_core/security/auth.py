"""Authentification des appels à l'API par clé (en-tête `Authorization: Bearer <clé>`).

- Les clés ne sont jamais conservées en clair : seules leurs empreintes SHA-256 sont gardées en mémoire.
- La comparaison est faite en temps constant, sur toutes les clés, sans sortie anticipée.
- L'identité exposée (journaux, limites de débit) est la position de la clé dans la configuration
  (« key-1 », « key-2 »…), jamais la clé ni une empreinte de la clé.
"""

from __future__ import annotations

import hashlib
import hmac
from collections.abc import Iterable
from dataclasses import dataclass

MAX_TOKEN_LENGTH = 512


@dataclass(frozen=True)
class Principal:
    key_id: str


def _extract_bearer(authorization: str | None) -> str | None:
    if not authorization:
        return None
    scheme, _, rest = authorization.partition(" ")
    if scheme.lower() != "bearer":
        return None
    token = rest.strip()
    if not token or len(token) > MAX_TOKEN_LENGTH or any(ch.isspace() for ch in token):
        return None
    return token


class ApiKeyAuthenticator:
    def __init__(self, keys: Iterable[str]) -> None:
        self._digests = [hashlib.sha256(key.encode("utf-8")).digest() for key in keys]
        if not self._digests:
            raise ValueError("au moins une clé d'API est requise")

    def authenticate(self, authorization: str | None) -> Principal | None:
        token = _extract_bearer(authorization)
        if token is None:
            return None
        presented = hashlib.sha256(token.encode("utf-8")).digest()
        matched: int | None = None
        for index, digest in enumerate(self._digests):
            if hmac.compare_digest(digest, presented) and matched is None:
                matched = index
        return Principal(f"key-{matched + 1}") if matched is not None else None
