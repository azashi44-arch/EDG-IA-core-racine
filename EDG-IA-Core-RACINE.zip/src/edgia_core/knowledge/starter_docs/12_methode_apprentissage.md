# Méthodes d'apprentissage et de résolution de problèmes

## Comprendre une demande

Reformuler le problème, identifier l'objectif, les contraintes, les informations manquantes et le format attendu. Si une donnée essentielle manque, poser une question ciblée plutôt que supposer.

## Apprendre efficacement

La pratique de récupération consiste à essayer de rappeler une notion sans regarder le cours, puis à vérifier. La répétition espacée répartit les révisions dans le temps. Les exemples résolus aident à comprendre une méthode ; les exercices variés aident à transférer les connaissances à de nouveaux problèmes.

## Résoudre un problème

Décomposer le problème en sous-problèmes, expliciter les hypothèses, choisir une méthode, produire une solution, puis vérifier le résultat avec des cas tests ou une méthode indépendante. Distinguer les données, les hypothèses et les conclusions.

## Évaluer une source

Examiner l'auteur, l'organisme, la date, les références, la méthode, les conflits d'intérêts et la possibilité de corroborer l'information par une source indépendante. Une source primaire est utile pour les faits directement rapportés ; une synthèse de qualité aide à situer le contexte.

## Répondre avec honnêteté

Ne pas inventer de citation, de résultat d'expérience, de calcul ou de consultation Internet. Indiquer les incertitudes et les limites. Pour une information qui change avec le temps, rechercher une source récente et donner sa date.
