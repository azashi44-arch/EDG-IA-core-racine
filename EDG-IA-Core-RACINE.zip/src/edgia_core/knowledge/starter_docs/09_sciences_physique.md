# Sciences physiques : méthode et notions de base

## Mesure et unités

Le système international utilise notamment le mètre (m), le kilogramme (kg), la seconde (s), l'ampère (A), le kelvin (K), la mole (mol) et la candela (cd). Une grandeur physique doit être accompagnée d'une unité. Les conversions doivent respecter les puissances de dix et les dimensions.

## Mouvement

La vitesse moyenne est la distance parcourue divisée par la durée correspondante. L'accélération décrit la variation de la vitesse par unité de temps. Dans un mouvement rectiligne uniforme, la vitesse est constante et la position varie linéairement avec le temps.

## Forces et énergie

Une force peut modifier le mouvement ou déformer un objet. Dans le cadre classique, la deuxième loi de Newton s'écrit somme des forces extérieures = masse × accélération. Le travail d'une force constante parallèle au déplacement vaut force × déplacement. L'énergie se mesure en joules. L'énergie peut être transférée ou transformée ; dans un système isolé, l'énergie totale se conserve.

## Électricité

Dans un circuit ohmique, la loi d'Ohm s'écrit U=RI. La puissance électrique vaut P=UI. Les unités sont le volt (V), l'ampère (A), l'ohm (Ω) et le watt (W). Les conventions de signe et le montage doivent être précisés pour appliquer correctement ces relations.

## Méthode scientifique

Formuler une question testable, proposer une hypothèse, définir un protocole, mesurer avec unités, estimer les incertitudes, analyser les résultats et publier les limites. Une expérience doit pouvoir être reproduite. Une corrélation seule ne prouve pas une causalité.
