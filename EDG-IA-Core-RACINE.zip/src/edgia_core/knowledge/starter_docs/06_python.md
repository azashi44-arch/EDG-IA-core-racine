# Python : bases de programmation

Python est un langage de programmation généraliste. Un programme Python est exécuté par un interpréteur compatible avec la version utilisée.

## Types courants

int représente les entiers, float les nombres à virgule flottante, str le texte, bool les valeurs True et False. list est une séquence modifiable, tuple une séquence non modifiable, dict une association clé-valeur et set un ensemble d'éléments uniques.

## Contrôle du programme

if/elif/else choisit une branche. for parcourt un itérable. while répète tant qu'une condition est vraie ; cette structure est une boucle. Une boucle for parcourt les éléments d'un itérable. Une fonction est définie avec def et peut recevoir des paramètres et retourner une valeur avec return. Les blocs sont délimités par l'indentation.

## Exceptions et fichiers

try/except permet de traiter des erreurs attendues. Il faut éviter de capturer toutes les exceptions sans les traiter. with open(path, encoding="utf-8") as file permet de gérer proprement la fermeture d'un fichier. Pour des données structurées, json permet de lire et écrire du JSON.

## Modules et environnements

Un module regroupe du code réutilisable. Un environnement virtuel isole les dépendances d'un projet. Un fichier requirements ou la configuration pyproject.toml peut documenter les dépendances. Les versions doivent être testées et verrouillées pour des déploiements reproductibles.

## Bonnes pratiques

Choisir des noms explicites, découper le code en fonctions courtes, documenter les interfaces, écrire des tests, traiter les entrées comme non fiables et ne jamais exécuter directement du code reçu d'un utilisateur. Les exemples doivent être exécutés dans un environnement isolé si leur origine n'est pas fiable.
