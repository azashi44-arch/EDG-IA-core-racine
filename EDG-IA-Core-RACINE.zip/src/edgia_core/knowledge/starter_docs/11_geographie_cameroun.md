# Géographie : repères sur le Cameroun

Le Cameroun se situe en Afrique centrale et possède une façade maritime sur le golfe de Guinée. Il partage des frontières terrestres avec le Nigeria, le Tchad, la République centrafricaine, la République du Congo, le Gabon et la Guinée équatoriale.

Yaoundé est la capitale politique et le siège des principales institutions nationales. Douala est un grand centre économique et portuaire. Le pays présente une diversité de milieux : littoral, forêts équatoriales, hauts plateaux, savanes et régions sahéliennes au nord.

Le Cameroun compte plusieurs zones climatiques. Les précipitations, températures et saisons varient selon la latitude, l'altitude et la proximité de l'océan. Il faut préciser la région et la période lorsqu'on parle du climat local.

Le français et l'anglais sont les deux langues officielles. De nombreuses langues nationales sont également parlées. Les informations administratives, démographiques et politiques peuvent évoluer : pour une question actuelle, consulter une source officielle datée et vérifier la date de publication.
