# Algorithmique et structures de données

Un algorithme est une suite finie d'étapes permettant de résoudre un problème. Sa correction dépend de la spécification, des hypothèses et des cas limites. Sa complexité temporelle décrit l'évolution du travail avec la taille de l'entrée ; la complexité spatiale décrit l'évolution de la mémoire utilisée.

## Structures courantes

Un tableau ou une liste indexée permet généralement un accès direct par position. Une liste chaînée relie des éléments par des références. Une pile suit le principe dernier entré, premier sorti (LIFO). Une file suit le principe premier entré, premier sorti (FIFO). Un dictionnaire ou une table de hachage associe des clés à des valeurs. Un arbre représente une hiérarchie ; un graphe représente des sommets et des relations.

## Recherche et tri

La recherche linéaire examine les éléments successivement et coûte O(n) dans le pire cas. La recherche dichotomique exige des données ordonnées et coûte O(log n). Les tris par fusion et par tas ont une complexité O(n log n) dans les cas usuels ; le tri rapide a un coût moyen O(n log n), mais un pire cas O(n²) dans ses formes classiques.

## Conception

Définir les entrées, sorties, contraintes et cas limites. Écrire une solution simple, puis mesurer avant d'optimiser. Tester les entrées vides, minimales, maximales, invalides et répétées. La complexité théorique ne remplace pas les mesures dans l'environnement réel.
