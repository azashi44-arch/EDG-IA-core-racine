# Intelligence artificielle et apprentissage automatique : bases

L'intelligence artificielle regroupe des méthodes permettant à des systèmes d'effectuer des tâches associées à des capacités comme la perception, le raisonnement, la prédiction ou la génération. L'apprentissage automatique est une famille de méthodes qui ajustent un modèle à partir de données.

Un réseau neuronal est constitué de couches de transformations paramétrées. Pendant l'entraînement supervisé, le modèle produit une sortie, une fonction de perte mesure l'écart à une cible, puis la rétropropagation calcule des gradients. Un optimiseur utilise ces gradients pour mettre à jour les paramètres. Les données d'entraînement servent à l'ajustement ; les données de validation servent à suivre la généralisation et à choisir des configurations ; les données de test servent à une évaluation finale indépendante.

PyTorch est un framework de calcul tensoriel et d'apprentissage automatique. Il permet de définir des modèles, calculer des gradients et exécuter l'entraînement sur CPU ou GPU compatible. Il ne constitue pas, à lui seul, une base de connaissances et ne fournit pas automatiquement les données d'entraînement.

Un modèle de langage apprend des régularités statistiques dans des séquences de tokens. Ses poids contiennent des paramètres ajustés, pas une encyclopédie structurée et garantie. Il peut produire des erreurs ou des informations périmées.

La génération augmentée par récupération (RAG) recherche des documents externes pertinents et les fournit au modèle comme contexte au moment de répondre. La RAG met à jour la bibliothèque, pas les poids. Pour changer les poids, il faut un entraînement ou un ajustement supervisé distinct, contrôlé et évalué.

Les résultats doivent être mesurés sur des jeux d'évaluation séparés, représentatifs et non contaminés par les données d'entraînement. Il faut surveiller les biais, la confidentialité, les licences, la sécurité et les performances réelles.
