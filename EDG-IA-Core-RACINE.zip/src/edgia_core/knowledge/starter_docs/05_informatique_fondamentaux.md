# Informatique : concepts fondamentaux

## Représentation de l'information

Un bit vaut 0 ou 1. Un octet contient 8 bits. Les ordinateurs représentent nombres, textes, images et sons par des données codées. Unicode attribue des points de code aux caractères ; UTF-8 est un encodage variable très répandu pour représenter Unicode.

## Matériel et logiciel

Le processeur exécute des instructions. La mémoire vive conserve temporairement les données utilisées. Le stockage conserve les données plus durablement. Le système d'exploitation gère les ressources et fournit des services aux applications. Un programme est une suite d'instructions exécutées par un environnement logiciel.

## Réseaux et Web

Une adresse IP identifie une interface sur un réseau. DNS associe des noms de domaine à des informations de réseau, notamment des adresses IP. HTTP est un protocole applicatif du Web ; HTTPS protège les échanges HTTP par TLS. Un navigateur demande des ressources à des serveurs. Une API définit une interface permettant à des logiciels de communiquer.

## Bases de données

Une base relationnelle organise souvent les données en tables reliées par des clés. SQL sert à définir, interroger et modifier ces données. Les transactions visent notamment les propriétés ACID : atomicité, cohérence, isolation et durabilité. Il faut valider les entrées, utiliser des requêtes paramétrées et limiter les privilèges.

## Sécurité

Utiliser des mots de passe uniques et robustes, les stocker sous forme de hachages adaptés, protéger les secrets dans des variables d'environnement ou un gestionnaire de secrets, appliquer les mises à jour et sauvegarder les données. Ne jamais exposer une clé privée dans un client public ou un dépôt de code.
