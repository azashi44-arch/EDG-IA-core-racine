"""Découpage de blocs en passages de taille bornée, sur des frontières naturelles, avec léger chevauchement."""

from __future__ import annotations

import re
from dataclasses import dataclass

_SENTENCE_END = re.compile(r"(?<=[.!?…])\s+")


@dataclass(frozen=True)
class Chunk:
    position: int
    section: str
    text: str


def _split_long(paragraph: str, size: int) -> list[str]:
    """Coupe un paragraphe trop long aux fins de phrases ; une phrase démesurée est coupée aux espaces."""
    pieces: list[str] = []
    current = ""
    for sentence in _SENTENCE_END.split(paragraph):
        while len(sentence) > size:
            cut = sentence.rfind(" ", 0, size)
            cut = cut if cut > size // 2 else size
            if current:
                pieces.append(current)
                current = ""
            pieces.append(sentence[:cut].strip())
            sentence = sentence[cut:].strip()
        if current and len(current) + 1 + len(sentence) > size:
            pieces.append(current)
            current = sentence
        else:
            current = f"{current} {sentence}".strip()
    if current:
        pieces.append(current)
    return [p for p in pieces if p]


def chunk_blocks(blocks: list[tuple[str, str]], size: int = 900, overlap: int = 120) -> list[Chunk]:
    """Regroupe les paragraphes d'une même section jusqu'à `size` caractères ; chaque passage reprend la fin du précédent."""
    if size < 200 or not 0 <= overlap < size // 2:
        raise ValueError("size ≥ 200 et 0 ≤ overlap < size/2 requis")
    chunks: list[Chunk] = []

    def emit(section: str, text: str) -> None:
        text = text.strip()
        if text:
            chunks.append(Chunk(len(chunks), section, text))

    for section, body in blocks:
        current = ""
        tail = ""
        for paragraph in (p.strip() for p in re.split(r"\n\s*\n|\n", body)):
            if not paragraph:
                continue
            for piece in _split_long(paragraph, size) if len(paragraph) > size else [paragraph]:
                if current and len(current) + 1 + len(piece) > size:
                    emit(section, current)
                    tail = current[-overlap:].split(" ", 1)[-1] if overlap else ""
                    current = f"{tail} {piece}".strip() if tail else piece
                else:
                    current = f"{current}\n{piece}".strip() if current else piece
        emit(section, current)
    return chunks
