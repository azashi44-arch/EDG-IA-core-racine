"""Bibliothèque de démarrage EDG-IA, composée de notes originales et révisables."""

from __future__ import annotations

from dataclasses import dataclass
from importlib.resources import files

from edgia_core.knowledge.store import KnowledgeBase, KnowledgeError


@dataclass(frozen=True)
class StarterDocument:
    filename: str
    title: str
    collection: str
    tags: tuple[str, ...]


STARTER_DOCUMENTS = (
    StarterDocument("00_comment_utilisation.md", "Comment utiliser une base de connaissances", "methodes", ("rag", "sources", "fiabilite")),
    StarterDocument("01_langue_francaise.md", "Langue française : bases", "langues", ("francais", "grammaire", "redaction")),
    StarterDocument("02_anglais_fondamentaux.md", "Anglais : fondamentaux", "langues", ("anglais", "vocabulaire", "grammaire")),
    StarterDocument("03_mathematiques.md", "Mathématiques : nombres, calcul et algèbre", "mathematiques", ("calcul", "algebre", "geometrie")),
    StarterDocument("04_statistiques_probabilites.md", "Statistiques et probabilités", "mathematiques", ("statistiques", "probabilites")),
    StarterDocument("05_informatique_fondamentaux.md", "Informatique : concepts fondamentaux", "informatique", ("ordinateur", "reseaux", "securite", "bases-de-donnees")),
    StarterDocument("06_python.md", "Python : bases de programmation", "programmation", ("python", "programmation")),
    StarterDocument("07_web_html_css_javascript.md", "Développement Web : HTML, CSS, JavaScript et API", "programmation", ("web", "html", "css", "javascript", "api")),
    StarterDocument("08_algorithmes_structures.md", "Algorithmique et structures de données", "informatique", ("algorithmes", "complexite", "structures-de-donnees")),
    StarterDocument("09_sciences_physique.md", "Sciences physiques : méthode et notions de base", "sciences", ("physique", "mesure", "energie")),
    StarterDocument("10_biologie.md", "Biologie : notions fondamentales", "sciences", ("biologie", "cellule", "genetique")),
    StarterDocument("11_geographie_cameroun.md", "Géographie : repères sur le Cameroun", "geographie", ("cameroun", "afrique", "geographie")),
    StarterDocument("12_methode_apprentissage.md", "Méthodes d'apprentissage et de résolution de problèmes", "methodes", ("apprentissage", "raisonnement", "sources")),
    StarterDocument("13_ia_et_apprentissage_machine.md", "Intelligence artificielle et apprentissage automatique", "intelligence_artificielle", ("ia", "pytorch", "rag", "entrainement")),
)

SOURCE = "EDG-IA Knowledge Starter Pack v1 — notes originales préparées pour le projet EDG-IA"
RIGHTS = (
    "Contenu original préparé pour EDG-IA ; utilisation dans le projet EDG-IA autorisée. "
    "Révision humaine recommandée avant toute redistribution publique."
)


def seed_starter_library(database: KnowledgeBase) -> dict[str, object]:
    """Indexe les notes de démarrage sans écraser les documents existants.

    Les identifiants sont stables. Une relance ignore un identifiant déjà présent ;
    les contenus modifiés doivent être remplacés explicitement par l'opérateur.
    """
    root = files("edgia_core.knowledge").joinpath("starter_docs")
    added: list[str] = []
    skipped: list[str] = []
    for item in STARTER_DOCUMENTS:
        doc_id = f"starter-{item.filename.removesuffix('.md')}"
        try:
            database.get(doc_id)
        except KnowledgeError:
            pass
        else:
            skipped.append(doc_id)
            continue
        resource = root.joinpath(item.filename)
        database.add_document(
            item.filename,
            resource.read_bytes(),
            title=item.title,
            source=SOURCE,
            rights=RIGHTS,
            collection=item.collection,
            tags=list(item.tags) + ["starter-v1", "contenu-original"],
            doc_id=doc_id,
        )
        added.append(doc_id)
    return {"added": added, "skipped": skipped, "total": len(STARTER_DOCUMENTS), "stats": database.stats()}
