"""Phase 6 : base documentaire locale (extraction, découpage, recherche lexicale FTS5, contexte pour le modèle)."""
