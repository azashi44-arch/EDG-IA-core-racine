"""Configuration d'EDG-IA Core.

Tout se règle par variables d'environnement préfixées EDGIA_ (ou un fichier .env), sans
modifier le code. Principes :
- sécurisé par défaut : écoute locale, authentification et limites de débit activées ;
- une variable EDGIA_ inconnue est refusée (une faute de frappe ne doit pas désactiver une protection) ;
- les messages d'erreur ne recopient jamais les valeurs saisies (elles peuvent être des secrets).
"""

from __future__ import annotations

import ipaddress
import os
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SecretStr,
    ValidationError,
    field_validator,
    model_validator,
)

from edgia_core.errors import ConfigurationError, format_validation_error
from edgia_core.model.descriptor import (
    ModelDescriptor,
    Runtime,
    apply_overrides,
    check_model,
    load_descriptor,
)
from edgia_core.model.registry import ModelRegistry, RegistryError

ENV_PREFIX = "EDGIA_"
MIN_API_KEY_LENGTH = 24

DEMO_NOTICE = "MODE DÉMONSTRATION : le modèle servi n'est PAS le modèle EDG-IA entraîné."


class Mode(StrEnum):
    DEMO = "demo"
    REAL = "real"


class LogLevel(StrEnum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


def _is_loopback(host: str) -> bool:
    if host.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


class Settings(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    mode: Mode = Mode.DEMO

    # Réseau
    host: str = "127.0.0.1"
    port: int = Field(default=8000, ge=1, le=65535)

    # Modèle (source de vérité : le descripteur ; les trois surcharges sont facultatives)
    model_descriptor: Path | None = None
    registry_path: Path | None = None  # alternative au descripteur : sert la version active du registre
    model_path: Path | None = None
    tokenizer_path: Path | None = None
    runtime: Runtime | None = None

    # Base documentaire (facultative) : fichier SQLite créé par `edgia-core knowledge add`
    knowledge_db: Path | None = None
    knowledge_max_context_chars: int = Field(default=6000, ge=500, le=100_000)
    # Recherche documentaire automatique à chaque message utilisateur, si la base est configurée.
    knowledge_auto_search: bool = False

    # Apprentissage par le chat (facultatif) : fichier SQLite créé par `edgia-core learning --db … init`.
    # Les leçons proposées restent EN ATTENTE jusqu'à la relecture d'un humain (voir docs/LEARNING.md).
    learning_db: Path | None = None
    # Indexe aussitôt les FAITS proposés (sans relecture). À réserver à un usage privé ; exige la base documentaire.
    learning_auto_approve_facts: bool = False
    learning_max_pending_per_key: int = Field(default=50, ge=1, le=10_000)

    # Limites
    max_context_tokens: int = Field(default=4096, ge=128, le=1_048_576)
    max_new_tokens: int = Field(default=512, ge=1)
    max_messages: int = Field(default=64, ge=1, le=1024)
    max_message_chars: int = Field(default=32_000, ge=1)
    max_request_bytes: int = Field(default=262_144, ge=1_024)
    request_timeout_seconds: float = Field(default=60.0, gt=0)
    max_concurrent_requests: int = Field(default=4, ge=1, le=256)
    streaming_enabled: bool = True

    # Sécurité
    auth_enabled: bool = True
    api_keys: tuple[SecretStr, ...] = ()
    rate_limit_enabled: bool = True
    rate_limit_per_minute: int = Field(default=60, ge=1, le=100_000)
    allowed_origins: tuple[str, ...] = ()

    # Journalisation
    log_level: LogLevel = LogLevel.INFO
    log_redact_content: bool = True

    @field_validator("api_keys", "allowed_origins", mode="before")
    @classmethod
    def _split_csv(cls, value: object) -> object:
        if isinstance(value, str):
            return [part.strip() for part in value.split(",") if part.strip()]
        return value

    @field_validator("host")
    @classmethod
    def _check_host(cls, value: str) -> str:
        value = value.strip()
        if not value or any(ch.isspace() for ch in value):
            raise ValueError("hôte invalide")
        return value

    @field_validator("api_keys")
    @classmethod
    def _check_keys(cls, value: tuple[SecretStr, ...]) -> tuple[SecretStr, ...]:
        secrets = [key.get_secret_value() for key in value]
        if any(len(secret) < MIN_API_KEY_LENGTH for secret in secrets):
            raise ValueError(f"chaque clé doit contenir au moins {MIN_API_KEY_LENGTH} caractères")
        if len(set(secrets)) != len(secrets):
            raise ValueError("clés dupliquées")
        return value

    @model_validator(mode="after")
    def _check_consistency(self) -> Settings:
        if self.max_new_tokens >= self.max_context_tokens:
            raise ValueError("max_new_tokens doit être strictement inférieur à max_context_tokens")
        if not self.auth_enabled and not _is_loopback(self.host):
            raise ValueError(
                "auth_enabled=false est interdit hors boucle locale : "
                "utilisez host=127.0.0.1 ou activez l'authentification"
            )
        return self


def parse_env_file(path: Path) -> dict[str, str]:
    """Lit un fichier .env simple (CLE=VALEUR, commentaires #, guillemets facultatifs)."""
    path = Path(path)
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigurationError(f"Fichier d'environnement illisible : {path}") from exc
    values: dict[str, str] = {}
    for number, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("export "):
            stripped = stripped[len("export ") :].lstrip()
        key, separator, value = stripped.partition("=")
        if not separator or not key.strip():
            raise ConfigurationError(f"{path}:{number} : ligne invalide (attendu CLE=VALEUR)")
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "'\"":
            value = value[1:-1]
        else:
            value = value.split(" #", 1)[0].rstrip()
        values[key.strip()] = value
    return values


def load_settings(env: Mapping[str, str] | None = None, env_file: Path | None = None) -> Settings:
    """Construit la configuration. Les variables d'environnement l'emportent sur le fichier .env.

    Une valeur vide équivaut à « non définie ».
    """
    merged: dict[str, str] = {}
    if env_file is not None:
        merged.update(parse_env_file(env_file))
    merged.update(os.environ if env is None else env)

    raw: dict[str, str] = {}
    unknown: list[str] = []
    for key, value in merged.items():
        if not key.startswith(ENV_PREFIX) or value == "":
            continue
        name = key[len(ENV_PREFIX) :].lower()
        if name not in Settings.model_fields:
            unknown.append(key)
            continue
        raw[name] = value

    if unknown:
        raise ConfigurationError([f"Variable inconnue : {key}" for key in sorted(unknown)])
    try:
        return Settings.model_validate(raw)
    except ValidationError as exc:
        raise ConfigurationError(format_validation_error(exc)) from None


@dataclass(frozen=True)
class ServingReport:
    """Résultat de la vérification « le service peut-il démarrer ? »."""

    problems: tuple[str, ...]
    warnings: tuple[str, ...]
    descriptor: ModelDescriptor | None

    @property
    def ok(self) -> bool:
        return not self.problems


def build_serving_report(settings: Settings) -> ServingReport:
    """Vérifie tout ce qui doit être vrai pour démarrer, sans rien télécharger ni charger."""
    problems: list[str] = []
    warnings: list[str] = []
    descriptor: ModelDescriptor | None = None

    if settings.auth_enabled and not settings.api_keys:
        problems.append("Authentification activée mais aucune clé fournie (EDGIA_API_KEYS).")
    if not settings.auth_enabled:
        warnings.append("Authentification désactivée (autorisé uniquement en boucle locale).")
    if not settings.rate_limit_enabled:
        warnings.append("Limitation de débit désactivée.")
    if settings.knowledge_db is not None and not settings.knowledge_db.is_file():
        problems.append(f"Base documentaire introuvable : {settings.knowledge_db} (EDGIA_KNOWLEDGE_DB ; créez-la avec `edgia-core knowledge seed-starter`).")
    if settings.knowledge_auto_search and settings.knowledge_db is None:
        problems.append("EDGIA_KNOWLEDGE_AUTO_SEARCH=true exige EDGIA_KNOWLEDGE_DB.")
    if settings.learning_db is not None and not settings.learning_db.is_file():
        problems.append(f"Base des leçons introuvable : {settings.learning_db} (EDGIA_LEARNING_DB ; créez-la avec `edgia-core learning --db … init`).")
    if settings.learning_auto_approve_facts and (settings.learning_db is None or settings.knowledge_db is None):
        problems.append("EDGIA_LEARNING_AUTO_APPROVE_FACTS=true exige EDGIA_LEARNING_DB et EDGIA_KNOWLEDGE_DB.")
    if settings.learning_auto_approve_facts:
        warnings.append("Apprentissage automatique des faits : un fait proposé par n'importe quelle clé est indexé SANS relecture humaine (risque de fausses informations ou de consignes cachées).")

    if settings.mode is Mode.DEMO:
        warnings.append(DEMO_NOTICE)
        return ServingReport(tuple(problems), tuple(warnings), None)

    if settings.model_descriptor is not None and settings.registry_path is not None:
        problems.append("Mode réel : choisissez EDGIA_MODEL_DESCRIPTOR ou EDGIA_REGISTRY_PATH, pas les deux.")
        return ServingReport(tuple(problems), tuple(warnings), None)
    if settings.model_descriptor is None and settings.registry_path is None:
        problems.append("Mode réel : EDGIA_MODEL_DESCRIPTOR (ou EDGIA_REGISTRY_PATH) est obligatoire.")
        return ServingReport(tuple(problems), tuple(warnings), None)

    try:
        if settings.registry_path is not None:
            if not settings.registry_path.is_file():
                raise ConfigurationError(f"Registre introuvable : {settings.registry_path}")
            try:
                active = ModelRegistry(settings.registry_path).active()
            except (RegistryError, OSError, ValueError) as exc:
                raise ConfigurationError(f"Registre illisible : {type(exc).__name__}") from None
            if active is None:
                raise ConfigurationError("Le registre ne contient aucune version active (commande : models activate).")
            descriptor = active.descriptor
        else:
            descriptor = load_descriptor(settings.model_descriptor)
        descriptor = apply_overrides(
            descriptor,
            weights_path=settings.model_path,
            tokenizer_path=settings.tokenizer_path,
            runtime=settings.runtime,
        )
    except ConfigurationError as exc:
        problems.extend(exc.problems)
        return ServingReport(tuple(problems), tuple(warnings), None)

    model_problems, model_warnings = check_model(descriptor)
    problems.extend(model_problems)
    warnings.extend(model_warnings)
    return ServingReport(tuple(problems), tuple(warnings), descriptor)
