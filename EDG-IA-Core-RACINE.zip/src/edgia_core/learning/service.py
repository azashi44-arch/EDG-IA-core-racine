"""Opérations qui relient les leçons à la base documentaire et aux données d'entraînement.

- `publish_lesson`  : valide une leçon ; un FAIT est indexé dans la base documentaire (utilisable tout de suite, sans toucher
                      aux poids), un EXEMPLE est seulement marqué « validé » (il attend un export puis la préparation de données).
- `withdraw_lesson` : retire une leçon (et le document indexé le cas échéant).
- `export_training_jsonl` : écrit les exemples validés au format de `edgia-core data prepare` (jamais d'écrasement).

Rien ici ne lance d'entraînement.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

from edgia_core.errors import EdgiaError
from edgia_core.learning.store import Lesson, LearningError, LearningStore

if TYPE_CHECKING:
    from edgia_core.knowledge.store import KnowledgeBase

FACT_COLLECTION = "appris-chat"
FACT_TITLE = "Leçon enseignée par chat"
FACT_SOURCE = "Enseigné par chat (contribution d'utilisateur)"
FACT_RIGHTS = "Contribution d'utilisateur avec consentement explicite ; validée par un opérateur avant indexation."
EXAMPLE_SOURCE = "Conversations EDG-IA proposées par des utilisateurs (leçons validées)"
EXAMPLE_LICENSE = "Contribution d'utilisateur avec consentement explicite ; validée par un opérateur."


def _fact_document(lesson: Lesson) -> bytes:
    return f"# {FACT_TITLE}\n\n{lesson.content}\n".encode("utf-8")


def publish_lesson(
    store: LearningStore, knowledge: "KnowledgeBase | None", lesson_id: str, *, note: str = ""
) -> Lesson:
    """Valide une leçon en attente. Un fait est indexé d'abord ; s'il ne peut pas l'être, la leçon reste en attente."""
    lesson = store.get(lesson_id)
    if lesson.status != "pending":
        raise LearningError("lesson_state", "Seule une leçon en attente peut être validée ou rejetée.")
    if lesson.kind == "example":
        return store.review(lesson_id, approve=True, note=note)

    if knowledge is None:
        raise LearningError("lesson_state", "La base documentaire n'est pas configurée : impossible d'indexer un fait.")
    try:
        record = knowledge.add_document(
            f"{lesson.id}.md",
            _fact_document(lesson),
            title=FACT_TITLE,
            source=FACT_SOURCE,
            rights=FACT_RIGHTS,
            collection=FACT_COLLECTION,
            tags=["chat", "lecon"],
            doc_id=lesson.id,
        )
    except EdgiaError as exc:  # doublon d'un document existant, contenu sans texte, etc. (le message ne recopie pas le contenu)
        raise LearningError("lesson_state", f"Indexation refusée : {exc}") from None
    try:
        return store.review(lesson_id, approve=True, note=note, doc_id=record.id)
    except Exception:
        knowledge.delete_document(record.id)  # pas de document indexé sans leçon validée
        raise


def reject_lesson(store: LearningStore, lesson_id: str, *, note: str = "") -> Lesson:
    return store.review(lesson_id, approve=False, note=note)


def withdraw_lesson(
    store: LearningStore, knowledge: "KnowledgeBase | None", lesson_id: str, *, key_id: str | None = None
) -> Lesson:
    """Retire une leçon. Si elle est indexée, le document est supprimé d'abord ; sans accès à la base, on refuse
    (un retrait de consentement ne doit pas laisser le contenu dans la base documentaire)."""
    lesson = store.get(lesson_id, key_id=key_id)
    if lesson.doc_id is not None:
        if knowledge is None:
            raise LearningError("lesson_state", "La leçon est indexée : la base documentaire doit être configurée pour la retirer.")
        try:
            knowledge.delete_document(lesson.doc_id)
        except EdgiaError:
            pass  # déjà supprimée de la base : on poursuit
    return store.delete(lesson_id, key_id=key_id)


def export_training_jsonl(store: LearningStore, out_path: Path) -> int:
    """Écrit les exemples validés (un JSON par ligne, format DataRecord). Retourne le nombre de lignes ; n'écrase jamais."""
    out_path = Path(out_path)
    lessons = store.list_lessons(status="approved", kind="example", limit=100_000)
    if not lessons:
        return 0
    try:
        handle = out_path.open("x", encoding="utf-8")
    except FileExistsError:
        raise LearningError("lesson_state", f"{out_path} existe déjà : choisissez un autre fichier (rien n'est écrasé).") from None
    with handle:
        for lesson in lessons:
            record = {
                "id": lesson.id,
                "messages": lesson.messages,
                "source": EXAMPLE_SOURCE,
                "license": EXAMPLE_LICENSE,
                "origin": "user_conversation",
                "consent": True,
                "tags": ["chat-lesson"],
            }
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
    return len(lessons)
