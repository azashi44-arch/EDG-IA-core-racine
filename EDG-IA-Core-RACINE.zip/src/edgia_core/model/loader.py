"""Construit le moteur d'inférence réel à partir d'un descripteur validé.

Tout échec de chargement devient une `ConfigurationError` : le serveur refuse de démarrer. Il ne retombe JAMAIS sur
le modèle de démonstration.
"""

from __future__ import annotations

from edgia_core.config import Settings
from edgia_core.errors import ConfigurationError
from edgia_core.inference.base import InferenceEngine, ModelInfo
from edgia_core.model.descriptor import ModelDescriptor, Runtime

MAX_ERROR_LENGTH = 300


def build_engine(settings: Settings, descriptor: ModelDescriptor) -> InferenceEngine:
    if descriptor.runtime is Runtime.EDGIA_NATIVE:
        # Importé ici : ni PyTorch ni le paquet `native` ne sont requis hors de ce runtime.
        from edgia_core.native.backend import build_native_engine

        return build_native_engine(settings, descriptor)
    if descriptor.runtime is not Runtime.TRANSFORMERS:
        raise ConfigurationError(
            f"Le runtime « {descriptor.runtime.value} » n'est pas encore pris en charge : seul « transformers » l'est."
        )
    # Importés ici : un serveur en mode démo ne doit pas exiger PyTorch.
    from edgia_core.inference.hf_backend import HuggingFaceBackend
    from edgia_core.inference.llm_engine import LanguageModelEngine

    try:
        backend = HuggingFaceBackend(descriptor)
    except ConfigurationError:
        raise
    except Exception as exc:  # noqa: BLE001 - toute erreur de chargement doit empêcher le démarrage
        message = f"{type(exc).__name__}: {exc}"[:MAX_ERROR_LENGTH]
        raise ConfigurationError(f"Chargement du modèle impossible ({message}).") from None

    info = ModelInfo(
        id=descriptor.model_id,
        version=descriptor.version,
        runtime=descriptor.runtime.value,
        is_demo=False,
        description=descriptor.display_name,
    )
    return LanguageModelEngine(info, backend)
