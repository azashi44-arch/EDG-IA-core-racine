"""Descripteur de modèle : décrit un modèle livré (fichiers, licence, matériel, adaptation).

Le descripteur est la source de vérité sur le modèle. Il est volontairement strict :
un modèle dont la licence n'a pas été vérifiée, dont les fichiers sont absents ou dont
les sommes de contrôle ne correspondent pas ne peut pas être servi en mode réel.
"""

from __future__ import annotations

import hashlib
import re
from enum import StrEnum
from pathlib import Path

import yaml
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    field_validator,
    model_validator,
)

from edgia_core.errors import ConfigurationError, format_validation_error

_MODEL_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._\-/]{0,127}$")
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class WeightsFormat(StrEnum):
    # Le format pickle (.bin / .pt) est volontairement absent : il peut exécuter du code à la lecture.
    SAFETENSORS = "safetensors"
    GGUF = "gguf"
    # EDG-IA Native : safetensors au format du paquet `edgia_core.native` (jamais de pickle).
    EDGIA_SAFETENSORS = "edgia-safetensors"


class Runtime(StrEnum):
    TRANSFORMERS = "transformers"
    LLAMA_CPP = "llama_cpp"
    EDGIA_NATIVE = "edgia_native"


class Device(StrEnum):
    AUTO = "auto"
    CPU = "cpu"
    CUDA = "cuda"


class AdaptationMethod(StrEnum):
    NONE = "none"
    LORA = "lora"
    QLORA = "qlora"
    FULL_SFT = "full_sft"


_COMPATIBLE_RUNTIME = {
    WeightsFormat.SAFETENSORS: Runtime.TRANSFORMERS,
    WeightsFormat.GGUF: Runtime.LLAMA_CPP,
    WeightsFormat.EDGIA_SAFETENSORS: Runtime.EDGIA_NATIVE,
}


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class LicenseInfo(_Strict):
    name: str = Field(min_length=1)
    url: str = ""
    commercial_use_allowed: bool | None = None
    reviewed: bool = False
    notes: str = ""


class HardwareInfo(_Strict):
    device: Device = Device.AUTO
    min_ram_gb: float | None = Field(default=None, gt=0)
    min_vram_gb: float | None = Field(default=None, gt=0)


class AdaptationInfo(_Strict):
    method: AdaptationMethod = AdaptationMethod.NONE
    base_model_id: str | None = None
    adapter_path: Path | None = None


class ModelDescriptor(_Strict):
    model_id: str
    version: str = Field(min_length=1)
    display_name: str = ""
    weights_path: Path
    tokenizer_path: Path | None = None
    weights_format: WeightsFormat
    runtime: Runtime
    license: LicenseInfo
    hardware: HardwareInfo = HardwareInfo()
    adaptation: AdaptationInfo = AdaptationInfo()
    sha256: dict[str, str] = Field(default_factory=dict)

    @field_validator("model_id")
    @classmethod
    def _check_model_id(cls, value: str) -> str:
        if not _MODEL_ID_RE.match(value):
            raise ValueError(
                "identifiant invalide (lettres, chiffres, '.', '_', '-', '/' ; 128 caractères maximum)"
            )
        return value

    @field_validator("sha256")
    @classmethod
    def _check_sha256(cls, value: dict[str, str]) -> dict[str, str]:
        cleaned: dict[str, str] = {}
        for relative, digest in value.items():
            if not relative or Path(relative).is_absolute():
                raise ValueError("les chemins de sommes de contrôle doivent être relatifs et non vides")
            normalized = digest.strip().lower()
            if not _SHA256_RE.match(normalized):
                raise ValueError(f"somme SHA-256 invalide pour « {relative} » (64 caractères hexadécimaux attendus)")
            cleaned[relative] = normalized
        return cleaned

    @model_validator(mode="after")
    def _check_consistency(self) -> ModelDescriptor:
        expected = _COMPATIBLE_RUNTIME[self.weights_format]
        if self.runtime is not expected:
            raise ValueError(
                f"le format « {self.weights_format.value} » est servi par le runtime « {expected.value} », "
                f"pas « {self.runtime.value} »"
            )
        if self.runtime in (Runtime.TRANSFORMERS, Runtime.EDGIA_NATIVE) and self.tokenizer_path is None:
            raise ValueError(f"tokenizer_path est obligatoire avec le runtime « {self.runtime.value} »")
        return self


def load_descriptor(path: Path) -> ModelDescriptor:
    """Charge un descripteur YAML. Les chemins relatifs sont résolus par rapport au fichier."""
    path = Path(path)
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ConfigurationError(f"Descripteur de modèle illisible : {path}") from exc
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"Descripteur de modèle : YAML invalide dans {path}") from exc
    if not isinstance(raw, dict):
        raise ConfigurationError(f"Descripteur de modèle : {path} doit contenir un objet YAML")

    base = path.resolve().parent

    def absolute(value: object) -> object:
        if isinstance(value, str) and value:
            candidate = Path(value)
            return candidate if candidate.is_absolute() else (base / candidate).resolve()
        return value

    for key in ("weights_path", "tokenizer_path"):
        if key in raw:
            raw[key] = absolute(raw[key])
    adaptation = raw.get("adaptation")
    if isinstance(adaptation, dict) and "adapter_path" in adaptation:
        adaptation["adapter_path"] = absolute(adaptation["adapter_path"])

    try:
        return ModelDescriptor.model_validate(raw)
    except ValidationError as exc:
        raise ConfigurationError(format_validation_error(exc, prefix="Descripteur de modèle — ")) from None


def apply_overrides(
    descriptor: ModelDescriptor,
    *,
    weights_path: Path | None = None,
    tokenizer_path: Path | None = None,
    runtime: Runtime | None = None,
) -> ModelDescriptor:
    """Applique les surcharges de configuration (variables d'environnement) au descripteur."""
    update: dict[str, object] = {}
    if weights_path is not None:
        update["weights_path"] = weights_path
    if tokenizer_path is not None:
        update["tokenizer_path"] = tokenizer_path
    if runtime is not None:
        update["runtime"] = runtime
    if not update:
        return descriptor
    try:
        return ModelDescriptor.model_validate({**descriptor.model_dump(), **update})
    except ValidationError as exc:
        raise ConfigurationError(format_validation_error(exc, prefix="Surcharge de modèle — ")) from None


def _weights_directory(descriptor: ModelDescriptor) -> Path:
    path = descriptor.weights_path
    return path if path.is_dir() else path.parent


def _sha256_of(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def check_model(descriptor: ModelDescriptor) -> tuple[list[str], list[str]]:
    """Vérifie qu'un modèle peut être servi en mode réel. Retourne (problèmes, avertissements).

    Un problème bloque le démarrage ; un avertissement est seulement signalé.
    Aucun fichier n'est téléchargé : seules les vérifications locales sont faites.
    """
    problems: list[str] = []
    warnings: list[str] = []

    # Licence
    if not descriptor.license.reviewed:
        problems.append("Licence non vérifiée : license.reviewed doit valoir true après lecture des conditions d'utilisation.")
    if descriptor.license.commercial_use_allowed is not True:
        problems.append("Usage commercial non confirmé : license.commercial_use_allowed doit valoir true (EDG-IA est un produit payant).")

    # Poids
    weights = descriptor.weights_path
    if not weights.exists():
        problems.append(f"Poids introuvables : {weights}")
    elif descriptor.weights_format is WeightsFormat.GGUF:
        if not weights.is_file() or weights.suffix.lower() != ".gguf":
            problems.append(f"Format gguf : un fichier .gguf est attendu, reçu {weights}")
        elif weights.stat().st_size == 0:
            problems.append(f"Fichier de poids vide : {weights}")
    else:
        files = [weights] if weights.is_file() else sorted(weights.glob("*.safetensors"))
        if not files or any(f.suffix.lower() != ".safetensors" for f in files):
            problems.append(f"Format safetensors : aucun fichier .safetensors valide dans {weights}")
        elif any(f.stat().st_size == 0 for f in files):
            problems.append(f"Fichier de poids vide dans {weights}")

    # Tokenizer
    tokenizer = descriptor.tokenizer_path
    if tokenizer is not None and not tokenizer.exists():
        problems.append(f"Tokenizer introuvable : {tokenizer}")

    # Adaptateur
    adapter = descriptor.adaptation.adapter_path
    if adapter is not None and not adapter.exists():
        problems.append(f"Adaptateur introuvable : {adapter}")

    # Sommes de contrôle
    if not descriptor.sha256:
        warnings.append("Aucune somme SHA-256 déclarée : l'intégrité des poids ne peut pas être vérifiée.")
    elif weights.exists():
        base = _weights_directory(descriptor).resolve()
        for relative, expected in descriptor.sha256.items():
            target = (base / relative).resolve()
            if not target.is_relative_to(base):
                problems.append(f"Somme de contrôle : chemin hors du dossier des poids refusé (« {relative} »).")
            elif not target.is_file():
                problems.append(f"Somme de contrôle : fichier introuvable (« {relative} »).")
            elif _sha256_of(target) != expected:
                problems.append(f"Somme de contrôle incorrecte pour « {relative} » : le fichier est corrompu ou différent de celui déclaré.")

    return problems, warnings
