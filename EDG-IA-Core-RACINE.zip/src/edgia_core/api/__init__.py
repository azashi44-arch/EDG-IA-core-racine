"""Routes et schémas HTTP d'EDG-IA Core. Voir docs/API.md."""

from edgia_core.api.app import create_app

__all__ = ["create_app"]
