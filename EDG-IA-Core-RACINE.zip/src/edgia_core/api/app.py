"""Application HTTP d'EDG-IA Core (Starlette).

Endpoints :
- GET  /health               vie du processus (sans authentification)
- GET  /ready                disponibilité du modèle (sans authentification)
- GET  /v1/models            modèles disponibles (authentifié)
- POST /v1/chat/completions  génération, avec ou sans streaming SSE (authentifié) ; champ facultatif `knowledge`
- POST /v1/knowledge/search  recherche de passages dans la base documentaire, si EDGIA_KNOWLEDGE_DB est défini (authentifié)
- POST /v1/learning/lessons  propose une leçon depuis le chat (fait ou conversation corrigée), si EDGIA_LEARNING_DB est défini
- GET  /v1/learning/lessons  leçons de la clé appelante (sans contenu)
- DELETE /v1/learning/lessons/{id}  retire une leçon de la clé appelante (retrait du consentement)

Ordre des contrôles sur une requête authentifiée : blocage des échecs d'authentification répétés, authentification,
limite de débit, type de contenu, taille du corps, JSON, schéma, limites configurées, modèle demandé, streaming,
disponibilité du modèle, fenêtre de contexte, concurrence, génération avec délai d'attente.
Les erreurs ne recopient jamais le contenu envoyé par le client.
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
import threading
import time
import uuid
from collections.abc import AsyncIterator, Awaitable, Callable
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any

from pydantic import ValidationError
from starlette.applications import Starlette
from starlette.background import BackgroundTask
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response, StreamingResponse
from starlette.routing import Route

from edgia_core import __version__
from edgia_core.api.http import SSE_DONE, ApiError, error_response, read_limited_body, sse_event
from edgia_core.api.schemas import ChatCompletionRequest, KnowledgeSearchRequest, LessonRequest
from edgia_core.config import DEMO_NOTICE, Mode, Settings, build_serving_report
from edgia_core.errors import ConfigurationError, format_validation_error
from edgia_core.inference.base import GenerationParams, InferenceEngine, Message, ModelInfo
from edgia_core.inference.demo import DemoEngine
from edgia_core.inference.gate import ConcurrencyGate, Slot
from edgia_core.knowledge.store import KnowledgeBase, build_rag_messages
from edgia_core.learning import LESSON_ID_RE, STATUSES, LearningError, LearningStore, Lesson, publish_lesson, withdraw_lesson
from edgia_core.model.descriptor import ModelDescriptor
from edgia_core.logging_setup import sanitize
from edgia_core.security.auth import ApiKeyAuthenticator, Principal
from edgia_core.security.ratelimit import RateDecision, SlidingWindowRateLimiter

LOG = logging.getLogger("edgia_core.api")

# Échecs d'authentification tolérés par minute et par adresse cliente, avant blocage temporaire.
# Attention : derrière un proxy, toutes les requêtes semblent venir de l'adresse du proxy.
AUTH_FAILURES_PER_MINUTE = 10
MAX_ERROR_LINES = 5
MAX_ERROR_LINE_LENGTH = 200


@dataclass
class AppContext:
    settings: Settings
    engine: InferenceEngine
    authenticator: ApiKeyAuthenticator | None
    rate_limiter: SlidingWindowRateLimiter | None
    auth_failures: SlidingWindowRateLimiter
    gate: ConcurrencyGate
    executor: ThreadPoolExecutor
    knowledge: KnowledgeBase | None = None
    learning: LearningStore | None = None

    def close(self) -> None:
        self.executor.shutdown(wait=False, cancel_futures=True)
        self.engine.close()
        if self.knowledge is not None:
            self.knowledge.close()
        if self.learning is not None:
            self.learning.close()


def _ctx(request: Request) -> AppContext:
    return request.app.state.ctx  # type: ignore[no-any-return]


def _client_host(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _retry_headers(decision: RateDecision) -> dict[str, str]:
    return {"Retry-After": str(max(1, math.ceil(decision.retry_after)))}


# --- Authentification et limites ---------------------------------------------------------------------------------


def _authorize(request: Request, ctx: AppContext) -> Principal:
    if ctx.authenticator is None:
        principal = Principal("anonymous")
    else:
        client = _client_host(request)
        blocked = ctx.auth_failures.peek(client)
        if not blocked.allowed:
            raise ApiError(
                429,
                "rate_limited",
                "Trop de tentatives d'authentification échouées. Réessayez plus tard.",
                headers=_retry_headers(blocked),
            )
        authenticated = ctx.authenticator.authenticate(request.headers.get("authorization"))
        if authenticated is None:
            ctx.auth_failures.hit(client)
            raise ApiError(401, "unauthorized", "Clé d'API absente ou invalide.", headers={"WWW-Authenticate": "Bearer"})
        principal = authenticated
    request.state.key_id = principal.key_id
    if ctx.rate_limiter is not None:
        identity = principal.key_id if ctx.authenticator is not None else _client_host(request)
        decision = ctx.rate_limiter.hit(identity)
        if not decision.allowed:
            raise ApiError(
                429, "rate_limited", "Limite de requêtes atteinte. Réessayez plus tard.", headers=_retry_headers(decision)
            )
    return principal


# --- Réponses ----------------------------------------------------------------------------------------------------


def _edgia_extension(info: ModelInfo, sources: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    extension: dict[str, Any] = {"demo": info.is_demo, "model_version": info.version}
    if info.is_demo:
        extension["notice"] = DEMO_NOTICE
    if sources is not None:  # présent seulement si l'ancrage documentaire a été demandé ; liste vide = rien trouvé
        extension["sources"] = sources
    return extension


def _usage(prompt_tokens: int, completion_tokens: int) -> dict[str, int]:
    return {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": prompt_tokens + completion_tokens,
    }


def _chunk(
    completion_id: str, created: int, model: str, delta: dict[str, Any], finish_reason: str | None
) -> dict[str, Any]:
    return {
        "id": completion_id,
        "object": "chat.completion.chunk",
        "created": created,
        "model": model,
        "choices": [{"index": 0, "delta": delta, "finish_reason": finish_reason}],
    }


# --- Endpoints ---------------------------------------------------------------------------------------------------


async def health(request: Request, rid: str) -> Response:
    return JSONResponse({"status": "ok", "service": "edgia-core", "version": __version__})


async def ready(request: Request, rid: str) -> Response:
    engine = _ctx(request).engine
    if not engine.is_ready():
        raise ApiError(503, "model_unavailable", "Le modèle n'est pas prêt.")
    return JSONResponse({"status": "ready", "model": engine.info.id, "demo": engine.info.is_demo})


async def list_models(request: Request, rid: str) -> Response:
    ctx = _ctx(request)
    _authorize(request, ctx)
    info = ctx.engine.info
    return JSONResponse(
        {
            "object": "list",
            "data": [
                {
                    "id": info.id,
                    "object": "model",
                    "created": 0,
                    "owned_by": "edgia",
                    "edgia": {**_edgia_extension(info), "runtime": info.runtime, "ready": ctx.engine.is_ready()},
                }
            ],
        }
    )


def _parse_chat_request(body: bytes) -> ChatCompletionRequest:
    try:
        payload = json.loads(body)
    except (ValueError, RecursionError):
        raise ApiError(400, "invalid_json", "Le corps de la requête n'est pas un JSON valide.") from None
    try:
        return ChatCompletionRequest.model_validate(payload)
    except ValidationError as exc:
        lines = [line[:MAX_ERROR_LINE_LENGTH] for line in format_validation_error(exc)]
        message = "Requête invalide : " + " ; ".join(lines[:MAX_ERROR_LINES])
        if len(lines) > MAX_ERROR_LINES:
            message += f" ; … ({len(lines) - MAX_ERROR_LINES} autre(s) erreur(s))"
        raise ApiError(422, "invalid_request", message) from None


def _check_limits(settings: Settings, req: ChatCompletionRequest) -> None:
    if len(req.messages) > settings.max_messages:
        raise ApiError(422, "invalid_request", f"Trop de messages (limite : {settings.max_messages}).")
    if any(len(m.content) > settings.max_message_chars for m in req.messages):
        raise ApiError(
            422, "invalid_request", f"Un message dépasse {settings.max_message_chars} caractères (limite configurée)."
        )
    if req.max_tokens is not None and req.max_tokens > settings.max_new_tokens:
        raise ApiError(422, "invalid_request", f"max_tokens dépasse la limite du serveur ({settings.max_new_tokens}).")


async def chat_completions(request: Request, rid: str) -> Response:
    ctx = _ctx(request)
    settings = ctx.settings
    engine = ctx.engine
    _authorize(request, ctx)

    content_type = request.headers.get("content-type", "").split(";")[0].strip().lower()
    if content_type != "application/json":
        raise ApiError(415, "unsupported_media_type", "Content-Type doit être application/json.")
    req = _parse_chat_request(await read_limited_body(request, settings.max_request_bytes))
    _check_limits(settings, req)

    info = engine.info
    if req.model is not None and req.model != info.id:
        raise ApiError(404, "model_not_found", "Modèle inconnu : consultez GET /v1/models.")
    if req.stream and not settings.streaming_enabled:
        raise ApiError(400, "streaming_disabled", "Le streaming est désactivé sur ce serveur.")
    if req.stream and not engine.supports_streaming:
        raise ApiError(400, "streaming_unsupported", "Le modèle servi ne prend pas en charge le streaming.")
    if not engine.is_ready():
        raise ApiError(503, "model_unavailable", "Le modèle n'est pas prêt.")

    conversation = [(m.role, m.content) for m in req.messages]
    use_knowledge = req.knowledge is not None or settings.knowledge_auto_search
    if use_knowledge:
        if ctx.knowledge is None:
            raise ApiError(400, "knowledge_disabled", "La base documentaire n'est pas configurée sur ce serveur.")
        question = next((c for r, c in reversed(conversation) if r == "user"), "")
        top_k = req.knowledge.top_k if req.knowledge is not None else 3
        collection = req.knowledge.collection if req.knowledge is not None else None
        hits = await asyncio.to_thread(
            ctx.knowledge.search, question, top_k=top_k, collection=collection
        )
        conversation, used = build_rag_messages(conversation, hits, max_chars=settings.knowledge_max_context_chars)
        request.state.knowledge_sources = [
            {"n": n, "document_id": h.doc_id, "title": h.title, "source": h.source, "section": h.section, "position": h.position}
            for n, h in enumerate(used, start=1)
        ]
        request.state.log_extra["knowledge_passages"] = len(used)
    messages = [Message(role, content) for role, content in conversation]
    params = GenerationParams(
        max_tokens=req.max_tokens if req.max_tokens is not None else settings.max_new_tokens,
        temperature=req.temperature,
        top_p=req.top_p,
        stop=tuple(req.stop or ()),
    )
    prompt_tokens = engine.count_tokens(messages)
    if prompt_tokens + params.max_tokens > settings.max_context_tokens:
        raise ApiError(
            422,
            "context_length_exceeded",
            f"Le prompt ({prompt_tokens} tokens) et max_tokens ({params.max_tokens}) dépassent "
            f"la fenêtre de contexte ({settings.max_context_tokens}).",
        )
    request.state.log_extra.update(prompt_tokens=prompt_tokens, stream=req.stream)
    if not settings.log_redact_content:
        LOG.debug("request_content request_id=%s messages=%r", rid, [(m.role, m.content) for m in messages])

    slot = ctx.gate.try_acquire()
    if slot is None:
        raise ApiError(503, "server_busy", "Le serveur traite déjà le nombre maximal de requêtes.", headers={"Retry-After": "1"})

    completion_id = f"chatcmpl-{rid}"
    created = int(time.time())
    if req.stream:
        try:
            return _stream_response(request, ctx, slot, completion_id, created, messages, params, prompt_tokens)
        except BaseException:
            slot.release()
            raise
    # `_complete` devient propriétaire de l'emplacement : il est libéré à la fin du thread de génération.
    return await _complete(request, ctx, slot, completion_id, created, messages, params)


async def _complete(
    request: Request,
    ctx: AppContext,
    slot: Slot,
    completion_id: str,
    created: int,
    messages: list[Message],
    params: GenerationParams,
) -> Response:
    settings = ctx.settings
    cancel = threading.Event()
    try:
        if ctx.engine.supports_cancel:
            future = ctx.executor.submit(ctx.engine.generate, messages, params, cancel)
        else:
            future = ctx.executor.submit(ctx.engine.generate, messages, params)
    except RuntimeError:
        slot.release()
        raise ApiError(503, "model_unavailable", "Le serveur est en cours d'arrêt.") from None
    # L'emplacement n'est libéré qu'à la fin réelle du thread, même si le client a déjà reçu un délai dépassé.
    future.add_done_callback(lambda _: slot.release())
    try:
        result = await asyncio.wait_for(asyncio.wrap_future(future), settings.request_timeout_seconds)
    except TimeoutError:
        cancel.set()  # un moteur qui le supporte s'arrête ; sinon l'emplacement reste pris jusqu'à la fin du thread
        raise ApiError(
            504, "generation_timeout", f"La génération a dépassé le délai de {settings.request_timeout_seconds:g} s."
        ) from None
    except asyncio.CancelledError:
        cancel.set()  # client parti
        raise
    except Exception as exc:
        LOG.error("generation_error request_id=%s error=%s", completion_id, type(exc).__name__)
        raise ApiError(500, "internal_error", "Erreur interne lors de la génération.") from None

    request.state.log_extra["completion_tokens"] = result.completion_tokens
    info = ctx.engine.info
    return JSONResponse(
        {
            "id": completion_id,
            "object": "chat.completion",
            "created": created,
            "model": info.id,
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": result.text},
                    "finish_reason": result.finish_reason,
                }
            ],
            "usage": _usage(result.prompt_tokens, result.completion_tokens),
            "edgia": _edgia_extension(info, getattr(request.state, "knowledge_sources", None)),
        }
    )


def _stream_response(
    request: Request,
    ctx: AppContext,
    slot: Slot,
    completion_id: str,
    created: int,
    messages: list[Message],
    params: GenerationParams,
    prompt_tokens: int,
) -> Response:
    settings = ctx.settings
    info = ctx.engine.info
    model = info.id

    async def events() -> AsyncIterator[bytes]:
        loop = asyncio.get_running_loop()
        deadline = loop.time() + settings.request_timeout_seconds
        iterator = ctx.engine.stream(messages, params).__aiter__()
        completion_tokens = 0
        try:
            yield sse_event(_chunk(completion_id, created, model, {"role": "assistant"}, None))
            while True:
                remaining = deadline - loop.time()
                if remaining <= 0:
                    raise TimeoutError
                try:
                    chunk = await asyncio.wait_for(iterator.__anext__(), remaining)
                except StopAsyncIteration:
                    break
                if chunk.text:
                    yield sse_event(_chunk(completion_id, created, model, {"content": chunk.text}, None))
                if chunk.finish_reason is not None:
                    completion_tokens = chunk.completion_tokens or 0
                    final = _chunk(completion_id, created, model, {}, chunk.finish_reason)
                    final["usage"] = _usage(prompt_tokens, completion_tokens)
                    final["edgia"] = _edgia_extension(info, getattr(request.state, "knowledge_sources", None))
                    yield sse_event(final)
            yield SSE_DONE
        except TimeoutError:
            timeout = ApiError(504, "generation_timeout", "La génération a dépassé le délai autorisé.")
            yield sse_event(timeout.body())
        except Exception as exc:
            LOG.error("stream_error request_id=%s error=%s", completion_id, type(exc).__name__)
            yield sse_event(ApiError(500, "internal_error", "Erreur interne lors de la génération.").body())
        finally:
            aclose = getattr(iterator, "aclose", None)
            if aclose is not None:
                await aclose()
            slot.release()
            LOG.info("stream_finished request_id=%s completion_tokens=%s", completion_id, completion_tokens)

    return StreamingResponse(
        events(),
        media_type="text/event-stream",
        headers={"X-Accel-Buffering": "no"},
        background=BackgroundTask(slot.release),
    )


async def knowledge_search(request: Request, rid: str) -> Response:
    ctx = _ctx(request)
    _authorize(request, ctx)
    content_type = request.headers.get("content-type", "").split(";")[0].strip().lower()
    if content_type != "application/json":
        raise ApiError(415, "unsupported_media_type", "Content-Type doit être application/json.")
    if ctx.knowledge is None:
        raise ApiError(404, "knowledge_disabled", "La base documentaire n'est pas configurée sur ce serveur.")
    body = await read_limited_body(request, ctx.settings.max_request_bytes)
    try:
        payload = json.loads(body)
    except (ValueError, RecursionError):
        raise ApiError(400, "invalid_json", "Le corps de la requête n'est pas un JSON valide.") from None
    try:
        req = KnowledgeSearchRequest.model_validate(payload)
    except ValidationError as exc:
        lines = [line[:MAX_ERROR_LINE_LENGTH] for line in format_validation_error(exc)]
        raise ApiError(422, "invalid_request", "Requête invalide : " + " ; ".join(lines[:MAX_ERROR_LINES])) from None
    hits = await asyncio.to_thread(ctx.knowledge.search, req.query, top_k=req.top_k, collection=req.collection)
    request.state.log_extra["knowledge_passages"] = len(hits)
    return JSONResponse(
        {
            "object": "list",
            "data": [
                {
                    "document_id": h.doc_id, "title": h.title, "source": h.source, "collection": h.collection,
                    "position": h.position, "section": h.section, "text": h.text, "score": h.score, "coverage": h.coverage,
                }
                for h in hits
            ],
        }
    )



# --- Apprentissage par le chat -----------------------------------------------------------------------------------

# Code HTTP de chaque refus de l'apprentissage (le code d'erreur vient de `LearningError.code`, jamais du contenu).
_LEARNING_STATUS = {
    "consent_required": 422,
    "lesson_invalid": 422,
    "lesson_duplicate": 409,
    "lesson_state": 409,
    "lesson_quota_exceeded": 429,
    "lesson_not_found": 404,
}


def _learning_error(exc: LearningError) -> ApiError:
    return ApiError(_LEARNING_STATUS.get(exc.code, 400), exc.code, exc.message)


def _learning_store(ctx: AppContext) -> LearningStore:
    if ctx.learning is None:
        raise ApiError(404, "learning_disabled", "L'apprentissage par le chat n'est pas configuré sur ce serveur.")
    return ctx.learning


def _lesson_public(lesson: Lesson) -> dict[str, Any]:
    """Ce que l'auteur voit de sa leçon : jamais son contenu (inutile et plus exposé)."""
    return {
        "id": lesson.id,
        "kind": lesson.kind,
        "status": lesson.status,
        "created_at": int(lesson.created_at),
        "pii_redactions": lesson.pii_redactions,
        "indexed": lesson.doc_id is not None,
    }


async def lesson_create(request: Request, rid: str) -> Response:
    ctx = _ctx(request)
    principal = _authorize(request, ctx)
    store = _learning_store(ctx)
    content_type = request.headers.get("content-type", "").split(";")[0].strip().lower()
    if content_type != "application/json":
        raise ApiError(415, "unsupported_media_type", "Content-Type doit être application/json.")
    body = await read_limited_body(request, ctx.settings.max_request_bytes)
    try:
        payload = json.loads(body)
    except (ValueError, RecursionError):
        raise ApiError(400, "invalid_json", "Le corps de la requête n'est pas un JSON valide.") from None
    try:
        req = LessonRequest.model_validate(payload)
    except ValidationError as exc:
        lines = [line[:MAX_ERROR_LINE_LENGTH] for line in format_validation_error(exc)]
        raise ApiError(422, "invalid_request", "Requête invalide : " + " ; ".join(lines[:MAX_ERROR_LINES])) from None
    messages = [{"role": m.role, "content": m.content} for m in req.messages] if req.messages is not None else None
    try:
        lesson = await asyncio.to_thread(
            store.submit, req.kind, text=req.text, messages=messages, key_id=principal.key_id, consent=req.consent
        )
    except LearningError as exc:
        raise _learning_error(exc) from None
    if lesson.kind == "fact" and ctx.settings.learning_auto_approve_facts and ctx.knowledge is not None:
        try:
            lesson = await asyncio.to_thread(
                publish_lesson, store, ctx.knowledge, lesson.id, note="Validation automatique (EDGIA_LEARNING_AUTO_APPROVE_FACTS)"
            )
        except LearningError:
            pass  # l'indexation a échoué (ex. contenu déjà connu) : la leçon reste en attente de relecture humaine
    request.state.log_extra.update(lesson_kind=lesson.kind, lesson_status=lesson.status)
    return JSONResponse({"object": "lesson", **_lesson_public(lesson)}, status_code=201)


async def lesson_list(request: Request, rid: str) -> Response:
    ctx = _ctx(request)
    principal = _authorize(request, ctx)
    store = _learning_store(ctx)
    status = request.query_params.get("status")
    if status is not None and status not in STATUSES:
        raise ApiError(422, "invalid_request", "Paramètre status invalide (pending, approved ou rejected).")
    lessons = await asyncio.to_thread(store.list_lessons, status=status, key_id=principal.key_id)
    return JSONResponse({"object": "list", "data": [_lesson_public(lesson) for lesson in lessons]})


async def lesson_delete(request: Request, rid: str) -> Response:
    ctx = _ctx(request)
    principal = _authorize(request, ctx)
    store = _learning_store(ctx)
    lesson_id = request.path_params["lesson_id"]
    if not LESSON_ID_RE.match(lesson_id):
        raise ApiError(404, "lesson_not_found", "Leçon introuvable.")
    try:
        await asyncio.to_thread(withdraw_lesson, store, ctx.knowledge, lesson_id, key_id=principal.key_id)
    except LearningError as exc:
        raise _learning_error(exc) from None
    return JSONResponse({"object": "lesson.deleted", "id": lesson_id, "deleted": True})


# --- Enveloppe commune : identifiant de requête, en-têtes, journal -----------------------------------------------


def _endpoint(handler: Callable[[Request, str], Awaitable[Response]], *, quiet: bool = False) -> Callable[[Request], Awaitable[Response]]:
    async def endpoint(request: Request) -> Response:
        rid = uuid.uuid4().hex
        request.state.key_id = "-"
        request.state.log_extra = {}
        started = time.perf_counter()
        try:
            response = await handler(request, rid)
        except ApiError as error:
            response = error_response(error)
        except Exception as exc:
            LOG.error("internal_error request_id=%s error=%s", rid, type(exc).__name__)
            response = error_response(ApiError(500, "internal_error", "Erreur interne du serveur."))
        _finalize(response, rid)
        extra = " ".join(f"{key}={value}" for key, value in request.state.log_extra.items())
        LOG.log(
            logging.DEBUG if quiet else logging.INFO,
            "request request_id=%s method=%s path=%s status=%s duration_ms=%d key=%s %s",
            rid,
            sanitize(request.method, 10),
            sanitize(request.url.path),
            response.status_code,
            (time.perf_counter() - started) * 1000,
            request.state.key_id,
            extra,
        )
        return response

    return endpoint


def _finalize(response: Response, rid: str) -> None:
    response.headers["X-Request-ID"] = rid
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"


async def _http_exception_handler(request: Request, exc: Exception) -> Response:
    assert isinstance(exc, StarletteHTTPException)
    codes = {404: ("not_found", "Ressource introuvable."), 405: ("method_not_allowed", "Méthode non autorisée.")}
    code, message = codes.get(exc.status_code, ("http_error", "Requête refusée."))
    response = error_response(ApiError(exc.status_code, code, message, headers=dict(exc.headers or {})))
    rid = uuid.uuid4().hex
    _finalize(response, rid)
    LOG.info(
        "request request_id=%s method=%s path=%s status=%s key=-",
        rid,
        sanitize(request.method, 10),
        sanitize(request.url.path),
        response.status_code,
    )
    return response


async def _unhandled_exception_handler(request: Request, exc: Exception) -> Response:
    LOG.error("unhandled_error error=%s", type(exc).__name__)
    response = error_response(ApiError(500, "internal_error", "Erreur interne du serveur."))
    _finalize(response, uuid.uuid4().hex)
    return response


# --- Construction ------------------------------------------------------------------------------------------------


EngineFactory = Callable[[Settings, ModelDescriptor], InferenceEngine]


def create_app(
    settings: Settings, engine: InferenceEngine | None = None, engine_factory: EngineFactory | None = None
) -> Starlette:
    """Construit l'application ou refuse de démarrer (ConfigurationError) si la configuration est invalide.

    Sans moteur fourni : le mode démonstration utilise `DemoEngine` ; le mode réel charge le modèle décrit par le
    descripteur (ou la version active du registre) avec `engine_factory` (par défaut `build_engine`). Tout échec de
    chargement empêche le démarrage : le mode réel ne retombe JAMAIS sur la démonstration.
    """
    report = build_serving_report(settings)
    if not report.ok:
        raise ConfigurationError(list(report.problems))
    if engine is None:
        if settings.mode is Mode.REAL:
            assert report.descriptor is not None  # garanti par un rapport sans problème en mode réel
            if engine_factory is None:
                from edgia_core.model.loader import build_engine as engine_factory
            engine = engine_factory(settings, report.descriptor)
        else:
            engine = DemoEngine()

    ctx = AppContext(
        settings=settings,
        engine=engine,
        authenticator=ApiKeyAuthenticator(k.get_secret_value() for k in settings.api_keys) if settings.auth_enabled else None,
        rate_limiter=SlidingWindowRateLimiter(settings.rate_limit_per_minute) if settings.rate_limit_enabled else None,
        auth_failures=SlidingWindowRateLimiter(AUTH_FAILURES_PER_MINUTE),
        gate=ConcurrencyGate(settings.max_concurrent_requests),
        executor=ThreadPoolExecutor(max_workers=settings.max_concurrent_requests, thread_name_prefix="edgia-infer"),
        knowledge=KnowledgeBase(settings.knowledge_db) if settings.knowledge_db is not None else None,
        learning=LearningStore(settings.learning_db, max_pending_per_key=settings.learning_max_pending_per_key)
        if settings.learning_db is not None
        else None,
    )

    @asynccontextmanager
    async def lifespan(_app: Starlette) -> AsyncIterator[None]:
        if engine.info.is_demo:
            LOG.warning(DEMO_NOTICE)
        yield
        ctx.close()

    middleware = []
    if settings.allowed_origins:
        middleware.append(
            Middleware(
                CORSMiddleware,
                allow_origins=list(settings.allowed_origins),
                allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
                allow_headers=["Authorization", "Content-Type"],
                max_age=600,
            )
        )

    app = Starlette(
        routes=[
            Route("/health", _endpoint(health, quiet=True), methods=["GET"]),
            Route("/ready", _endpoint(ready, quiet=True), methods=["GET"]),
            Route("/v1/models", _endpoint(list_models), methods=["GET"]),
            Route("/v1/chat/completions", _endpoint(chat_completions), methods=["POST"]),
            Route("/v1/knowledge/search", _endpoint(knowledge_search), methods=["POST"]),
            Route("/v1/learning/lessons", _endpoint(lesson_create), methods=["POST"]),
            Route("/v1/learning/lessons", _endpoint(lesson_list), methods=["GET"]),
            Route("/v1/learning/lessons/{lesson_id}", _endpoint(lesson_delete), methods=["DELETE"]),
        ],
        middleware=middleware,
        exception_handlers={
            StarletteHTTPException: _http_exception_handler,
            Exception: _unhandled_exception_handler,
        },
        lifespan=lifespan,
    )
    app.state.ctx = ctx
    return app
