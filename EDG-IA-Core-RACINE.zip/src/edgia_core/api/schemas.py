"""Schémas de requête de l'API (validation stricte : champ inconnu ou type incorrect = refus)."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from edgia_core.learning.store import MAX_EXAMPLE_TURNS, MAX_FACT_CHARS

MAX_STOP_SEQUENCES = 4
MAX_STOP_LENGTH = 64


class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    role: Literal["system", "user", "assistant"]
    content: str


COLLECTION_PATTERN = r"^[a-z0-9][a-z0-9_\-]{0,63}$"


class KnowledgeOptions(BaseModel):
    """Demande d'ancrage sur la base documentaire : les passages trouvés sont ajoutés comme données non fiables."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    collection: str | None = Field(default=None, pattern=COLLECTION_PATTERN)
    top_k: int = Field(default=3, ge=1, le=8)


class KnowledgeSearchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    query: str = Field(min_length=1, max_length=1000)
    top_k: int = Field(default=5, ge=1, le=20)
    collection: str | None = Field(default=None, pattern=COLLECTION_PATTERN)


class LessonRequest(BaseModel):
    """Leçon proposée depuis le chat : un fait (`text`) ou une conversation corrigée (`messages`). `consent` doit valoir true."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    kind: Literal["fact", "example"]
    consent: bool
    text: str | None = Field(default=None, max_length=MAX_FACT_CHARS)
    messages: list[ChatMessage] | None = Field(default=None, max_length=MAX_EXAMPLE_TURNS)


class ChatCompletionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    model: str | None = Field(default=None, min_length=1, max_length=128)
    messages: list[ChatMessage] = Field(min_length=1)
    max_tokens: int | None = Field(default=None, ge=1)
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    top_p: float = Field(default=1.0, gt=0.0, le=1.0)
    stream: bool = False
    stop: list[str] | None = Field(default=None, max_length=MAX_STOP_SEQUENCES)
    knowledge: KnowledgeOptions | None = None

    @field_validator("stop")
    @classmethod
    def _check_stop(cls, value: list[str] | None) -> list[str] | None:
        if value is not None and any(not s or len(s) > MAX_STOP_LENGTH for s in value):
            raise ValueError(f"chaque séquence d'arrêt doit contenir de 1 à {MAX_STOP_LENGTH} caractères")
        return value
