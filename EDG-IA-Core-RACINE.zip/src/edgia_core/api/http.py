"""Outils HTTP communs : erreurs normalisées, lecture bornée du corps, événements SSE."""

from __future__ import annotations

import json
from typing import Any

from starlette.requests import Request
from starlette.responses import JSONResponse

_ERROR_TYPES = {
    400: "invalid_request_error",
    401: "authentication_error",
    404: "not_found_error",
    405: "invalid_request_error",
    409: "invalid_request_error",
    413: "invalid_request_error",
    415: "invalid_request_error",
    422: "invalid_request_error",
    429: "rate_limit_error",
}


class ApiError(Exception):
    """Erreur à renvoyer au client. Le message ne doit jamais recopier de contenu fourni par le client."""

    def __init__(self, status: int, code: str, message: str, *, headers: dict[str, str] | None = None) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.headers = headers or {}

    @property
    def error_type(self) -> str:
        return _ERROR_TYPES.get(self.status, "server_error")

    def body(self) -> dict[str, Any]:
        return {"error": {"type": self.error_type, "code": self.code, "message": self.message}}


def error_response(error: ApiError) -> JSONResponse:
    return JSONResponse(error.body(), status_code=error.status, headers=error.headers)


async def read_limited_body(request: Request, max_bytes: int) -> bytes:
    """Lit le corps en refusant dès que la limite est dépassée (avec ou sans Content-Length)."""
    too_large = ApiError(413, "request_too_large", f"Corps de requête trop volumineux (limite : {max_bytes} octets).")
    declared = request.headers.get("content-length")
    if declared is not None:
        try:
            size = int(declared)
        except ValueError:
            raise ApiError(400, "invalid_request", "En-tête Content-Length invalide.") from None
        if size < 0:
            raise ApiError(400, "invalid_request", "En-tête Content-Length invalide.")
        if size > max_bytes:
            raise too_large
    chunks: list[bytes] = []
    total = 0
    async for chunk in request.stream():
        total += len(chunk)
        if total > max_bytes:
            raise too_large
        chunks.append(chunk)
    return b"".join(chunks)


def sse_event(payload: dict[str, Any]) -> bytes:
    return b"data: " + json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8") + b"\n\n"


SSE_DONE = b"data: [DONE]\n\n"
