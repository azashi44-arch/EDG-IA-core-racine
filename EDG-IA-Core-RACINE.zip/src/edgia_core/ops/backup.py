"""Sauvegarde cohérente des bases SQLite (registre de modèles, base documentaire) et vérification.

Utilise l'API de sauvegarde de SQLite : la copie est cohérente même si le serveur tourne. Les poids du modèle ne sont
PAS copiés (volumineux, fournis par l'équipe d'entraînement, protégés par leurs sommes SHA-256) ; les descripteurs et
configurations vivent dans le dépôt de configuration. Aucune restauration automatique : elle écraserait des données
(procédure manuelle documentée dans docs/EXPLOITATION.md).
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from edgia_core import __version__
from edgia_core.errors import ConfigurationError


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _integrity_problem(path: Path) -> str | None:
    try:
        connection = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            result = connection.execute("PRAGMA integrity_check").fetchall()
        finally:
            connection.close()
    except sqlite3.DatabaseError as exc:
        return f"base illisible ({type(exc).__name__})"
    return None if result == [("ok",)] else "contrôle d'intégrité SQLite en échec"


def backup(out_dir: Path, *, registry: Path | None = None, knowledge: Path | None = None, learning: Path | None = None) -> dict:
    sources = {"registry.sqlite3": registry, "knowledge.sqlite3": knowledge, "learning.sqlite3": learning}
    chosen = {name: path for name, path in sources.items() if path is not None}
    if not chosen:
        raise ConfigurationError("Rien à sauvegarder : indiquez --registry, --knowledge et/ou --learning.")
    for name, path in chosen.items():
        if not path.is_file():
            raise ConfigurationError(f"Base introuvable : {path}")
    if (out_dir / "backup.json").exists():
        raise ConfigurationError(f"{out_dir} contient déjà une sauvegarde : choisissez un autre dossier (rien n'est écrasé).")
    out_dir.mkdir(parents=True, exist_ok=True)

    files: dict[str, dict] = {}
    for name, source in chosen.items():
        target = out_dir / name
        reader = sqlite3.connect(f"file:{source}?mode=ro", uri=True)
        writer = sqlite3.connect(target)
        try:
            reader.backup(writer)
        except sqlite3.DatabaseError as exc:
            raise ConfigurationError(f"Sauvegarde de {source.name} impossible ({type(exc).__name__}).") from None
        finally:
            writer.close()
            reader.close()
        problem = _integrity_problem(target)
        if problem:
            raise ConfigurationError(f"Sauvegarde de {source.name} invalide : {problem}.")
        files[name] = {"sha256": _sha256(target), "bytes": target.stat().st_size, "source": str(source)}
    manifest = {
        "format": 1,
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "edgia_core_version": __version__,
        "files": files,
    }
    (out_dir / "backup.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def verify_backup(directory: Path) -> list[str]:
    """Retourne la liste des problèmes (vide = sauvegarde saine)."""
    manifest_path = directory / "backup.json"
    if not manifest_path.is_file():
        return [f"backup.json introuvable dans {directory}"]
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        files = manifest["files"]
    except (ValueError, KeyError):
        return ["backup.json illisible"]
    problems = []
    for name, info in files.items():
        path = directory / name
        if not path.is_file():
            problems.append(f"{name} : fichier manquant")
        elif _sha256(path) != info.get("sha256"):
            problems.append(f"{name} : somme SHA-256 différente (fichier modifié ou corrompu)")
        else:
            problem = _integrity_problem(path)
            if problem:
                problems.append(f"{name} : {problem}")
    return problems
