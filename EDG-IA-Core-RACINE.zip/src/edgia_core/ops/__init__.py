"""Phase 7 : outils d'exploitation (diagnostic de l'environnement, sauvegardes)."""
