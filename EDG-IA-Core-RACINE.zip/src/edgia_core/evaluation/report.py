"""Rapports d'évaluation : Markdown, HTML autonome, CSV de relecture humaine.

Tout texte produit par un modèle est traité comme non fiable : il est échappé dans le HTML et neutralisé dans le CSV
(contre l'injection de formules de tableur).
"""

from __future__ import annotations

import csv
import html
import io

DEMO_BANNER = (
    "MODÈLE DE DÉMONSTRATION : ces résultats n'ont AUCUNE signification. Le moteur de démonstration ne génère pas de "
    "texte avec une IA ; il ne mesure rien sur le modèle EDG-IA."
)
LIMITS_NOTE = (
    "Les vérifications automatiques sont des heuristiques : elles repèrent des erreurs évidentes (mauvais résultat, "
    "consigne de forme ignorée, fuite d'un secret) mais ne jugent ni la qualité d'une explication, ni le style, ni la "
    "pédagogie. Un score élevé ne prouve pas qu'un modèle est bon ; les cas « review » exigent une relecture humaine."
)
_STATUS_LABEL = {
    "pass": "réussi", "fail": "échec", "partial": "partiel", "skipped": "non exécuté", "review": "à relire", "error": "erreur",
}


def _pct(value: float | None) -> str:
    return "n/a" if value is None else f"{value * 100:.0f} %"


def _meta_lines(results: dict) -> list[tuple[str, str]]:
    engine, suite, perf = results["engine"], results["suite"], results["performance"]
    lines = [
        ("Moteur", f"{engine['id']} {engine['version']} ({engine['runtime']})"),
        ("Suite", f"{suite['name']} — {suite['cases_run']}/{suite['cases_total']} cas — sha256 {suite['sha256'][:16]}…"),
        ("Date", results["generated_at"]),
        ("Exécution de code", "activée" if results["settings"]["allow_code_execution"] else "désactivée"),
        ("Durée totale", f"{perf['wall_time_s']} s"),
    ]
    if "latency_median_s" in perf:
        lines.append(("Latence médiane / max", f"{perf['latency_median_s']} s / {perf['latency_max_s']} s"))
    if "tokens_per_s_median" in perf:
        lines.append(("Débit médian", f"{perf['tokens_per_s_median']} tokens/s"))
    rss = perf["peak_rss_mb_after"]
    lines.append(("Mémoire RSS max (processus)", "indisponible sur cette plateforme" if rss is None else f"{rss} Mo"))
    if perf.get("gpu_peak_allocated_mb") is not None:
        lines.append(("Mémoire GPU max allouée", f"{perf['gpu_peak_allocated_mb']} Mo"))
    return lines


def render_markdown(results: dict) -> str:
    out = ["# Rapport d'évaluation EDG-IA", ""]
    if results["engine"]["is_demo"]:
        out += [f"> **{DEMO_BANNER}**", ""]
    out += [f"- **{k}** : {v}" for k, v in _meta_lines(results)]
    out += ["", f"> {LIMITS_NOTE}", "", "## Résultats par catégorie", ""]
    out += ["| Catégorie | Réussis | Échecs | Erreurs | Partiels | Non exécutés | À relire | Taux (cas vérifiés) |", "|---|---|---|---|---|---|---|---|"]
    rows = [("**Ensemble**", results["summary"]["overall"])] + list(results["summary"]["by_category"].items())
    for name, block in rows:
        c = block["counts"]
        out.append(
            f"| {name} | {c['pass']} | {c['fail']} | {c['error']} | {c['partial']} | {c['skipped']} | {c['review']} | "
            f"{_pct(block['pass_rate'])} sur {block['scored']} |"
        )
    failures = [r for r in results["cases"] if r["status"] in ("fail", "error")]
    out += ["", f"## Cas en échec ({len(failures)})", ""]
    for r in failures:
        details = "; ".join(f"{c['kind']}: {c['detail']}" for c in r["checks"] if c["status"] == "fail") or r.get("error", "")
        out.append(f"- `{r['id']}` ({r['category']}) — {details}")
    if not failures:
        out.append("Aucun.")
    out += ["", "Les réponses complètes sont dans `results.json` ; les cas à relire sont dans `review.csv`.", ""]
    return "\n".join(out)


def render_html(results: dict) -> str:
    e = html.escape
    parts = [
        "<!doctype html><html lang='fr'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>",
        "<title>Rapport d'évaluation EDG-IA</title><style>",
        "body{font:15px/1.5 system-ui,sans-serif;max-width:1000px;margin:0 auto;padding:16px;color:#1b1f24;background:#fff}"
        "table{border-collapse:collapse;width:100%;margin:12px 0}td,th{border:1px solid #ccd;padding:6px 8px;text-align:left;vertical-align:top}"
        ".banner{background:#fff3cd;border:2px solid #d9a400;padding:12px;font-weight:700}.note{background:#eef;padding:10px}"
        ".pass{color:#0a6b2d}.fail,.error{color:#b00020}.review,.partial,.skipped{color:#7a5b00}"
        "pre{white-space:pre-wrap;word-break:break-word;background:#f5f5f7;padding:8px;margin:0}"
        "@media(prefers-color-scheme:dark){body{background:#14161a;color:#e6e8eb}td,th{border-color:#3a3f48}pre{background:#20242b}"
        ".note{background:#222a44}.banner{background:#4a3b00}.pass{color:#6fdc8c}.fail,.error{color:#ff8a98}.review,.partial,.skipped{color:#f0c75e}}",
        "</style></head><body><h1>Rapport d'évaluation EDG-IA</h1>",
    ]
    if results["engine"]["is_demo"]:
        parts.append(f"<p class='banner'>{e(DEMO_BANNER)}</p>")
    parts.append("<ul>" + "".join(f"<li><b>{e(k)}</b> : {e(v)}</li>" for k, v in _meta_lines(results)) + "</ul>")
    parts.append(f"<p class='note'>{e(LIMITS_NOTE)}</p><h2>Résultats par catégorie</h2><table><tr><th>Catégorie</th>")
    parts.append("".join(f"<th>{e(h)}</th>" for h in ("Réussis", "Échecs", "Erreurs", "Partiels", "Non exécutés", "À relire", "Taux (cas vérifiés)")) + "</tr>")
    rows = [("Ensemble", results["summary"]["overall"])] + list(results["summary"]["by_category"].items())
    for name, block in rows:
        c = block["counts"]
        cells = [c["pass"], c["fail"], c["error"], c["partial"], c["skipped"], c["review"], f"{_pct(block['pass_rate'])} sur {block['scored']}"]
        parts.append(f"<tr><td>{e(name)}</td>" + "".join(f"<td>{e(str(x))}</td>" for x in cells) + "</tr>")
    parts.append("</table><h2>Détail des cas</h2><table><tr><th>Cas</th><th>Statut</th><th>Vérifications</th><th>Réponse</th></tr>")
    for r in results["cases"]:
        checks = "<br>".join(e(f"{c['kind']} : {_STATUS_LABEL.get(c['status'], c['status'])} {c['detail']}".strip()) for c in r["checks"]) or e(r.get("error", "—"))
        parts.append(
            f"<tr><td>{e(r['id'])}<br><small>{e(r['category'])}</small></td>"
            f"<td class='{e(r['status'])}'>{e(_STATUS_LABEL.get(r['status'], r['status']))}</td><td>{checks}</td>"
            f"<td><pre>{e(r.get('output', '')[:2000])}</pre></td></tr>"
        )
    parts.append("</table></body></html>")
    return "".join(parts)


def _csv_safe(text: str) -> str:
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


def render_review_csv(results: dict) -> str:
    """Fichier pour la relecture humaine : cas sans vérification, partiels, non exécutés et en échec."""
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["id", "categorie", "statut", "note", "reponse", "note_relecteur_0_a_5", "commentaire_relecteur"])
    for r in results["cases"]:
        if r["status"] in ("review", "partial", "skipped", "fail", "error"):
            writer.writerow([r["id"], r["category"], r["status"], _csv_safe(r.get("note", "")), _csv_safe(r.get("output", "")), "", ""])
    return buffer.getvalue()
