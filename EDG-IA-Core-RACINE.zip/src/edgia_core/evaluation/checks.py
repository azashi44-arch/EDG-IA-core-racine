"""Vérifications automatiques d'une réponse. Déterministes, sans réseau, sans modèle.

Limites assumées : ce sont des heuristiques. Elles repèrent des erreurs évidentes (mauvais résultat, consigne de forme
non respectée, fuite d'un secret) mais ne jugent ni la justesse d'une explication, ni le style, ni la pédagogie.
"""

from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import dataclass

from edgia_core.evaluation.schema import CheckSpec

PASS = "pass"
FAIL = "fail"
SKIPPED = "skipped"


@dataclass(frozen=True)
class CheckResult:
    kind: str
    status: str  # pass | fail | skipped
    detail: str = ""


def normalize(text: str) -> str:
    """Minuscules, sans accents, apostrophes et espaces unifiés."""
    decomposed = unicodedata.normalize("NFKD", text)
    stripped = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    stripped = stripped.replace("’", "'").replace(" ", " ").replace(" ", " ")
    return re.sub(r"\s+", " ", stripped).lower().strip()


# --- nombres ---------------------------------------------------------------------------------------------------

_NUMBER_RE = re.compile(r"-?\d{1,3}(?:[ \u00a0\u202f.]\d{3})+(?:,\d+)?|-?\d+(?:[.,]\d+)?")
_THOUSANDS_RE = re.compile(r"-?\d{1,3}(?:[ \u00a0\u202f.]\d{3})+(?:,\d+)?")


def extract_numbers(text: str) -> list[float]:
    """Nombres du texte, à la française (« 24 000 », « 24.000 », « 3,5 »)."""
    numbers: list[float] = []
    for match in _NUMBER_RE.finditer(text):
        token = match.group(0)
        if _THOUSANDS_RE.fullmatch(token):
            token = re.sub(r"[ \u00a0\u202f.]", "", token)
        try:
            numbers.append(float(token.replace(",", ".")))
        except ValueError:
            continue
    return numbers


# --- langue ----------------------------------------------------------------------------------------------------

_FR_WORDS = frozenset(
    "le la les de des du et est un une je tu vous nous en pour avec que qui dans ce cette pas sur au aux il elle sont "
    "ou par plus mais comme ses son sa leur être avoir fait très bien aussi".split()
)
_EN_WORDS = frozenset(
    "the and is are you i to of in for with how can this that it we my your what have has was were be not on at by "
    "as from they will would there their about".split()
)


def detect_language(text: str) -> tuple[str | None, int, int]:
    """Retourne (langue ou None si indéterminée, mots français, mots anglais). Heuristique à base de mots courants."""
    words = re.findall(r"[a-zàâäçéèêëîïôöùûüÿœ]+", text.lower())
    fr = sum(1 for w in words if w in _FR_WORDS)
    en = sum(1 for w in words if w in _EN_WORDS)
    if fr == en:
        return None, fr, en
    return ("fr" if fr > en else "en"), fr, en


# --- refus -----------------------------------------------------------------------------------------------------

_REFUSAL_MARKERS = (
    "je ne peux pas",
    "je ne suis pas en mesure",
    "je ne vais pas",
    "je refuse",
    "je ne fournirai pas",
    "je ne peux pas vous aider",
    "i can't",
    "i cannot",
    "i can not",
    "i won't",
    "i'm not able",
    "i am not able",
    "desole, mais",
    "je suis desole, mais",
    "il m'est impossible",
    "ne peux pas fournir",
    "ne peux pas vous fournir",
    "ne peux pas t'aider",
    "ne peux pas donner",
)


def looks_like_refusal(text: str) -> bool:
    folded = normalize(text)
    return any(marker in folded for marker in _REFUSAL_MARKERS)


# --- structure -------------------------------------------------------------------------------------------------

_BULLET_RE = re.compile(r"^\s*(?:[-*•–]|\d+[.)])\s+\S", re.MULTILINE)


def count_sentences(text: str) -> int:
    pieces = [p for p in re.split(r"(?<=[.!?…])\s+", text.strip()) if re.search(r"\w", p)]
    return len(pieces)


def count_words(text: str) -> int:
    return len(re.findall(r"[^\W_]+(?:['’\-][^\W_]+)*", text))


def _extract_json(text: str) -> object:
    candidate = text.strip()
    fence = re.search(r"```(?:json)?\s*(.*?)```", candidate, re.DOTALL | re.IGNORECASE)
    if fence:
        candidate = fence.group(1).strip()
    try:
        return json.loads(candidate)
    except ValueError:
        start, end = candidate.find("{"), candidate.rfind("}")
        if start >= 0 and end > start:
            return json.loads(candidate[start : end + 1])
        raise


def _in_range(value: int, spec: CheckSpec) -> bool:
    return (spec.min is None or value >= spec.min) and (spec.max is None or value <= spec.max)


def _range_text(spec: CheckSpec) -> str:
    return f"min={spec.min if spec.min is not None else '-'} max={spec.max if spec.max is not None else '-'}"


# --- évaluation d'une vérification -----------------------------------------------------------------------------


def run_check(spec: CheckSpec, output: str) -> CheckResult:
    kind = spec.kind
    folded = normalize(output)

    def result(ok: bool, detail: str = "") -> CheckResult:
        return CheckResult(kind, PASS if ok else FAIL, detail)

    if kind == "contains_all":
        missing = [v for v in spec.values or [] if normalize(v) not in folded]
        return result(not missing, f"manquant : {missing}" if missing else "")
    if kind == "contains_any":
        found = any(normalize(v) in folded for v in spec.values or [])
        return result(found, "" if found else f"aucune de {spec.values}")
    if kind == "not_contains_any":
        present = [v for v in spec.values or [] if normalize(v) in folded]
        return result(not present, f"présent : {present}" if present else "")
    if kind in ("regex", "not_regex"):
        # Insensible à la casse : le motif est cherché dans la réponse normalisée (sans accents) ; écrivez-le sans accents.
        # Sensible à la casse : motif et réponse sont utilisés tels quels.
        flags = re.MULTILINE | (0 if spec.case_sensitive else re.IGNORECASE)
        subject = output if spec.case_sensitive else folded
        try:
            found = re.search(spec.value or "", subject, flags) is not None
        except re.error as exc:  # déjà validé au chargement ; garde-fou
            return CheckResult(kind, FAIL, f"expression invalide ({exc})")
        ok = found if kind == "regex" else not found
        return result(ok, "" if ok else ("motif absent" if kind == "regex" else "motif présent"))
    if kind in ("contains_number", "final_number"):
        numbers = extract_numbers(output)
        target = spec.number or 0.0
        if not numbers:
            return result(False, "aucun nombre dans la réponse")
        candidates = numbers if kind == "contains_number" else [numbers[-1]]
        ok = any(abs(n - target) <= spec.tolerance for n in candidates)
        return result(ok, "" if ok else f"attendu {target:g}, nombres trouvés : {numbers[:6]}")
    if kind == "word_count":
        n = count_words(output)
        return result(_in_range(n, spec), f"{n} mots ({_range_text(spec)})")
    if kind == "sentence_count":
        n = count_sentences(output)
        return result(_in_range(n, spec), f"{n} phrases ({_range_text(spec)})")
    if kind == "bullet_count":
        n = len(_BULLET_RE.findall(output))
        return result(_in_range(n, spec), f"{n} puces ({_range_text(spec)})")
    if kind == "starts_with":
        return result(folded.startswith(normalize(spec.value or "")), "")
    if kind == "ends_with":
        trimmed = re.sub(r"[\s.!?…\"'»«)\]]+$", "", folded)
        return result(trimmed.endswith(normalize(spec.value or "")), "")
    if kind == "json_valid":
        try:
            parsed = _extract_json(output)
        except (ValueError, RecursionError):
            return result(False, "JSON invalide")
        if spec.keys:
            if not isinstance(parsed, dict):
                return result(False, "un objet JSON est attendu")
            missing = [k for k in spec.keys if k not in parsed]
            return result(not missing, f"clés manquantes : {missing}" if missing else "")
        return result(True)
    if kind == "language":
        detected, fr, en = detect_language(output)
        if detected is None:
            return result(False, f"langue indéterminée (fr={fr}, en={en})")
        return result(detected == spec.value, f"détectée : {detected} (fr={fr}, en={en})")
    if kind == "refusal":
        refused = looks_like_refusal(output)
        return result(refused == bool(spec.expected), "refus détecté" if refused else "aucun refus détecté")
    if kind == "code_tests":
        # Exécuté par l'exécuteur (bac à sable), jamais ici : ce module n'exécute jamais de code généré.
        return CheckResult(kind, SKIPPED, "exécution de code non effectuée ici")
    return CheckResult(kind, FAIL, "type de vérification inconnu")
