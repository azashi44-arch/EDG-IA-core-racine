"""Nettoyage, identifiants de documents, langue (heuristique) et retrait de données personnelles.

LIMITES (à lire) : la détection de langue est une heuristique de mots courants (pas un modèle) ; le retrait de données
personnelles est fondé sur des motifs (e-mails, téléphones, IBAN, cartes bancaires validées par Luhn, adresses IP,
numéros de sécurité sociale français) : il NE garantit PAS l'anonymisation ni la conformité RGPD. À compléter avant tout
corpus contenant des textes récents ou personnels.
"""

from __future__ import annotations

import re
import unicodedata

from edgia_core.native.hashing import sha256_bytes

_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")
_WORD = re.compile(r"\w+", re.UNICODE)


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFC", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = _CONTROL.sub("", text)
    return text.strip()


def make_doc_id(normalized_text: str) -> str:
    return sha256_bytes(normalized_text.encode("utf-8"))[:32]


def words(text: str) -> list[str]:
    return [w.lower() for w in _WORD.findall(text)]


_FR = frozenset("le la les un une des du de et est dans pour avec sur par plus ce cette qui que ne pas il elle nous vous ils sont au aux ou mais où comme".split())
_EN = frozenset("the of and to in is that it for with as was on are by this be from or an at not which have but they his her you".split())


def guess_lang(text: str) -> str:
    """« fr », « en » ou « other » selon la fréquence de mots courants. Heuristique déterministe."""
    tokens = words(text)[:2000]
    if len(tokens) < 8:
        return "other"
    fr = sum(1 for t in tokens if t in _FR)
    en = sum(1 for t in tokens if t in _EN)
    if max(fr, en) / len(tokens) < 0.08:
        return "other"
    return "fr" if fr >= en else "en"


_EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_IBAN = re.compile(r"\b[A-Z]{2}\d{2}(?: ?[A-Z0-9]{4}){3,7}(?: ?[A-Z0-9]{1,4})?\b")
_IPV4 = re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b")
_PHONE = re.compile(r"(?<!\d)(?:\+33\s?|0033\s?|0)[1-9](?:[\s.-]?\d{2}){4}(?!\d)")
_SSN_FR = re.compile(r"(?<!\d)[12]\s?\d{2}\s?(?:0[1-9]|1[0-2])\s?(?:\d{2}|2[AB])\s?\d{3}\s?\d{3}(?:\s?\d{2})?(?!\d)")
_CARD = re.compile(r"(?<!\d)(?:\d[ -]?){13,19}(?!\d)")


def _luhn(digits: str) -> bool:
    total, alt = 0, False
    for ch in reversed(digits):
        n = int(ch)
        if alt:
            n *= 2
            n -= 9 if n > 9 else 0
        total += n
        alt = not alt
    return total % 10 == 0


def scrub_pii(text: str) -> tuple[str, dict[str, int]]:
    """Remplace les motifs de données personnelles par des marqueurs. Retourne (texte, compteurs)."""
    counts: dict[str, int] = {}

    def sub(pattern: re.Pattern[str], label: str, source: str, check=None) -> str:
        def repl(match: re.Match[str]) -> str:
            if check is not None and not check(match.group(0)):
                return match.group(0)
            counts[label] = counts.get(label, 0) + 1
            return f"[{label}]"

        return pattern.sub(repl, source)

    text = sub(_EMAIL, "EMAIL", text)
    text = sub(_IBAN, "IBAN", text)
    text = sub(_SSN_FR, "NUMERO_SECU", text)
    text = sub(_CARD, "CARTE", text, check=lambda s: 13 <= len(re.sub(r"\D", "", s)) <= 19 and _luhn(re.sub(r"\D", "", s)))
    text = sub(_PHONE, "TELEPHONE", text)
    text = sub(_IPV4, "IP", text)
    return text, counts
