"""Classes de licences (spécification v1.1, §5.1). AUCUNE équivalence automatique entre licences d'une même classe.

Ce tableau est un outil de TRI, pas un avis juridique : l'admission d'une source dépend de la validation humaine
documentée dans le registre (porte 1) et, pour la distribution des poids, d'une seconde validation (porte 2).
"""

from __future__ import annotations

CLASS_A = "A"  # domaine public, CC0
CLASS_B = "B"  # licences à obligations (chacune traitée séparément)
CLASS_C = "C"  # partage à l'identique, copyleft : exclues sauf décision juridique écrite
CLASS_D = "D"  # restrictions d'usage : exclues
CLASS_E = "E"  # inconnue / invérifiable : bloquée

_CLASSES: dict[str, str] = {}
for _id in ("CC0-1.0", "PDM-1.0", "public-domain"):
    _CLASSES[_id] = CLASS_A
for _id in ("CC-BY-4.0", "LO-2.0", "MIT", "BSD-2-Clause", "BSD-3-Clause", "Apache-2.0"):
    _CLASSES[_id] = CLASS_B
for _id in ("CC-BY-SA-4.0", "CC-BY-SA-3.0", "GPL-2.0-only", "GPL-3.0-only", "LGPL-3.0-only", "AGPL-3.0-only", "ODbL-1.0"):
    _CLASSES[_id] = CLASS_C
for _id in ("CC-BY-NC-4.0", "CC-BY-NC-SA-4.0", "CC-BY-ND-4.0", "proprietary", "ai-service-output"):
    _CLASSES[_id] = CLASS_D

ALIASES = {"etalab-2.0": "LO-2.0", "Etalab-2.0": "LO-2.0", "licence-ouverte-2.0": "LO-2.0", "cc0": "CC0-1.0", "CC0": "CC0-1.0"}

# Obligations connues par licence de classe B : rappel pour la fiche de données, PAS une analyse juridique.
OBLIGATIONS: dict[str, list[str]] = {
    "CC-BY-4.0": ["attribution (auteur, source, licence)", "indiquer les modifications"],
    "LO-2.0": ["mentionner la paternité (source) et la date de dernière mise à jour"],
    "MIT": ["conserver l'avis de droit d'auteur et le texte de la licence dans les copies"],
    "BSD-2-Clause": ["conserver l'avis de droit d'auteur, la liste de conditions et l'exclusion de garantie"],
    "BSD-3-Clause": ["conserver l'avis de droit d'auteur et les conditions", "ne pas utiliser le nom des auteurs pour promouvoir"],
    "Apache-2.0": ["conserver les avis et le fichier NOTICE", "indiquer les modifications", "clauses de brevets et de résiliation"],
}


def canonical_license_id(license_id: str) -> str:
    return ALIASES.get(license_id, license_id)


def license_class(license_id: str) -> str:
    """Classe de la licence ; toute licence inconnue est de classe E (bloquée)."""
    return _CLASSES.get(canonical_license_id(license_id), CLASS_E)
