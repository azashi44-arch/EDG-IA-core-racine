"""Chargeur de fenêtres SANS ÉTAT (spécification v1.1, §6.3).

Fenêtres de ctx+1 tokens au pas de ctx : deux fenêtres voisines partagent 1 token (cible de l'une, entrée de la suivante),
donc chaque token est prédit exactement une fois. Une fenêtre ne traverse jamais deux fragments (queue inutilisée comptée).
Le lot du pas s est entièrement déterminé par (graine, s) : n = s·B + j ; époque e = n // W ; indice = perm_e[n mod W],
perm_e = Generator(PCG64(graine + e)).permutation(W). La reprise n'a donc pas d'état de chargeur à sauvegarder.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np

from edgia_core.native.errors import DataError


class WindowLoader:
    def __init__(self, shard_paths: list[Path], ctx: int, seed: int, batch_seqs: int) -> None:
        if ctx < 1 or batch_seqs < 1:
            raise DataError("ctx et batch_seqs doivent être ≥ 1")
        self.ctx, self.seed, self.batch_seqs = ctx, seed, batch_seqs
        self._maps: list[np.ndarray] = []
        self._counts: list[int] = []
        self.unused_tail_tokens = 0
        for path in shard_paths:
            data = np.memmap(path, dtype="<u2", mode="r")
            windows = max(0, (data.size - 1) // ctx)
            self.unused_tail_tokens += int(data.size - (windows * ctx + 1 if windows else 0))
            if windows:
                self._maps.append(data)
                self._counts.append(windows)
        self._cum = np.cumsum([0, *self._counts])
        self.total_windows = int(self._cum[-1])
        if self.total_windows == 0:
            raise DataError("aucune fenêtre disponible (données trop courtes pour ce contexte)")
        self._perm_cache: tuple[int, np.ndarray] | None = None

    def _perm(self, epoch: int) -> np.ndarray:
        if self._perm_cache is None or self._perm_cache[0] != epoch:
            rng = np.random.Generator(np.random.PCG64(self.seed + epoch))
            self._perm_cache = (epoch, rng.permutation(self.total_windows))
        return self._perm_cache[1]

    def window_indices(self, step: int) -> list[int]:
        out = []
        for j in range(self.batch_seqs):
            n = step * self.batch_seqs + j
            out.append(int(self._perm(n // self.total_windows)[n % self.total_windows]))
        return out

    def window(self, index: int) -> np.ndarray:
        shard = int(np.searchsorted(self._cum, index, side="right") - 1)
        start = (index - int(self._cum[shard])) * self.ctx
        return np.asarray(self._maps[shard][start : start + self.ctx + 1], dtype=np.int64)

    def get_batch(self, step: int) -> np.ndarray:
        """Tableau int64 [batch_seqs, ctx+1] : entrées = [:, :-1], cibles = [:, 1:]."""
        return np.stack([self.window(i) for i in self.window_indices(step)])

    def batch_fingerprint(self, step: int) -> str:
        return hashlib.sha256(repr(self.window_indices(step)).encode("ascii")).hexdigest()
