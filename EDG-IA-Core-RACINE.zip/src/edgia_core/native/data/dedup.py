"""Doublons exacts, quasi-doublons (MinHash + LSH) et regroupement par œuvre (spécification v1.1, §5.4 étapes 6-8).

MinHash : empreintes de 5 mots (par défaut), 128 permutations ; LSH : 16 bandes × 8 lignes (rappel théorique ≈ 95 % à
J = 0,8). La similarité d'une paire candidate est ESTIMÉE par la fraction de permutations égales (erreur-type ≈ ±0,035).
LIMITES : seuils provisoires ; ne détecte pas les traductions, paraphrases ni résumés ; coût Python pur élevé à l'échelle de
milliards de tokens (prévoir un outil dédié ou `datasketch` à ce stade).
"""

from __future__ import annotations

import hashlib
import random
from collections import defaultdict
from collections.abc import Sequence
from dataclasses import dataclass

import numpy as np

from edgia_core.native.data.text import words

_MASK = (1 << 64) - 1


def _hash64(data: str) -> int:
    return int.from_bytes(hashlib.blake2b(data.encode("utf-8"), digest_size=8).digest(), "little")


def shingle_hashes(text: str, n: int) -> set[int]:
    tokens = words(text)
    if len(tokens) < n:
        return {_hash64(" ".join(tokens))} if tokens else set()
    return {_hash64(" ".join(tokens[i : i + n])) for i in range(len(tokens) - n + 1)}


@dataclass(frozen=True)
class MinHasher:
    n_perm: int = 128
    seed: int = 20260101
    shingle_words: int = 5

    def _params(self) -> tuple[np.ndarray, np.ndarray]:
        rng = random.Random(self.seed)
        a = np.array([rng.getrandbits(64) | 1 for _ in range(self.n_perm)], dtype=np.uint64)
        b = np.array([rng.getrandbits(64) for _ in range(self.n_perm)], dtype=np.uint64)
        return a, b

    def signature(self, text: str) -> np.ndarray:
        hashes = np.array(sorted(shingle_hashes(text, self.shingle_words)), dtype=np.uint64)
        a, b = self._params()
        if hashes.size == 0:
            return np.full(self.n_perm, _MASK, dtype=np.uint64)
        with np.errstate(over="ignore"):
            mixed = hashes[:, None] * a[None, :] + b[None, :]  # arithmétique modulo 2^64
        return mixed.min(axis=0)


def estimated_jaccard(sig_a: np.ndarray, sig_b: np.ndarray) -> float:
    return float(np.mean(sig_a == sig_b))


class UnionFind:
    def __init__(self) -> None:
        self._parent: dict[str, str] = {}

    def add(self, key: str) -> None:
        self._parent.setdefault(key, key)

    def find(self, key: str) -> str:
        self.add(key)
        root = key
        while self._parent[root] != root:
            root = self._parent[root]
        while self._parent[key] != root:
            self._parent[key], key = root, self._parent[key]
        return root

    def union(self, a: str, b: str) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            # racine = plus petit identifiant : résultat indépendant de l'ordre des unions
            low, high = (ra, rb) if ra < rb else (rb, ra)
            self._parent[high] = low

    def groups(self) -> dict[str, list[str]]:
        out: dict[str, list[str]] = defaultdict(list)
        for key in sorted(self._parent):
            out[self.find(key)].append(key)
        return dict(out)


def find_near_duplicates(
    doc_ids: Sequence[str], texts: Sequence[str], *, hasher: MinHasher, bands: int = 16, threshold: float = 0.8,
    max_bucket: int = 500,
) -> tuple[list[tuple[str, str, float]], dict[str, int]]:
    """Paires de quasi-doublons (id_a, id_b, similarité estimée) et statistiques."""
    if hasher.n_perm % bands != 0:
        raise ValueError("n_perm doit être un multiple de bands")
    rows = hasher.n_perm // bands
    sigs = [hasher.signature(t) for t in texts]
    buckets: dict[tuple[int, bytes], list[int]] = defaultdict(list)
    for index, sig in enumerate(sigs):
        for band in range(bands):
            buckets[(band, sig[band * rows : (band + 1) * rows].tobytes())].append(index)
    candidates: set[tuple[int, int]] = set()
    skipped = 0
    for members in buckets.values():
        if len(members) < 2:
            continue
        if len(members) > max_bucket:  # boilerplate : on borne le coût quadratique (limite documentée)
            skipped += 1
            members = members[:max_bucket]
        for i, a in enumerate(members):
            for b in members[i + 1 :]:
                candidates.add((a, b))
    pairs = []
    for a, b in sorted(candidates):
        score = estimated_jaccard(sigs[a], sigs[b])
        if score >= threshold:
            pairs.append((doc_ids[a], doc_ids[b], score))
    return pairs, {"candidates": len(candidates), "pairs": len(pairs), "oversized_buckets_truncated": skipped}


def build_groups(doc_ids: Sequence[str], work_ids: Sequence[str | None], near_pairs: Sequence[tuple[str, str, float]]) -> dict[str, str]:
    """doc_id → group_id. Un groupe réunit : les documents d'un même `work_id` (ISBN, ark, titre+auteur…) ET les
    quasi-doublons, transitivement. group_id = plus petit doc_id du groupe, préfixé « g_ »."""
    uf = UnionFind()
    for doc_id in doc_ids:
        uf.add(doc_id)
    by_work: dict[str, list[str]] = defaultdict(list)
    for doc_id, work in zip(doc_ids, work_ids, strict=True):
        if work:
            by_work[work].append(doc_id)
    for members in by_work.values():
        for other in members[1:]:
            uf.union(members[0], other)
    for a, b, _ in near_pairs:
        uf.union(a, b)
    return {member: "g_" + root for root, members in uf.groups().items() for member in members}
