"""Manifeste du jeu de données : empreintes SHA-256 de chaque fragment, index, tokenizer, registre (§5.7)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from edgia_core.native.errors import DataError
from edgia_core.native.hashing import sha256_file, sha256_json

MANIFEST_NAME = "dataset_manifest.json"
MANIFEST_FORMAT = "edgia-dataset-v1"


def manifest_digest(manifest: dict[str, Any]) -> str:
    """Empreinte du manifeste (hors champ `manifest_sha256`)."""
    return sha256_json({k: v for k, v in manifest.items() if k != "manifest_sha256"})


def write_manifest(directory: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    manifest = {k: v for k, v in manifest.items() if k != "manifest_sha256"}
    manifest["manifest_sha256"] = manifest_digest(manifest)
    (directory / MANIFEST_NAME).write_text(json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8")
    return manifest


def load_manifest(directory: Path) -> dict[str, Any]:
    try:
        manifest = json.loads((directory / MANIFEST_NAME).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise DataError(f"manifeste illisible dans {directory}") from exc
    if manifest.get("format") != MANIFEST_FORMAT:
        raise DataError("format de manifeste inconnu")
    return manifest


def verify_manifest(directory: str | Path) -> list[str]:
    """Recalcule toutes les empreintes. Retourne la liste des problèmes (vide = intègre)."""
    root = Path(directory)
    problems: list[str] = []
    manifest = load_manifest(root)
    if manifest.get("manifest_sha256") != manifest_digest(manifest):
        problems.append("empreinte du manifeste incorrecte")
    for split, info in manifest["splits"].items():
        for shard in info["shards"]:
            for key, name in (("sha256", "path"), ("index_sha256", "index_path")):
                path = root / split / shard[name]
                if not path.exists():
                    problems.append(f"fichier absent : {split}/{shard[name]}")
                elif sha256_file(path) != shard[key]:
                    problems.append(f"empreinte différente : {split}/{shard[name]}")
    tokenizer_json = root / "tokenizer" / "tokenizer.json"
    if tokenizer_json.exists():
        from edgia_core.native.tokenizer.tokenizer import EdgiaTokenizer

        if EdgiaTokenizer.load(root / "tokenizer").tokenizer_hash() != manifest["tokenizer_sha256"]:
            problems.append("le tokenizer du dossier ne correspond pas au manifeste")
    return problems


def train_shard_paths(directory: Path, split: str = "train") -> list[Path]:
    manifest = load_manifest(directory)
    return [directory / split / s["path"] for s in manifest["splits"][split]["shards"]]
