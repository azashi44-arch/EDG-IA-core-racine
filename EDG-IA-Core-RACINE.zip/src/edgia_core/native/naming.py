"""Noms et formes canoniques des tenseurs d'un modèle EDG-IA Native (partagés par l'init NumPy, le modèle PyTorch,
les checkpoints et l'export). Il n'existe AUCUN tenseur de sortie : la matrice de sortie est la table d'embeddings."""

from __future__ import annotations

from edgia_core.native.config import ModelConfig

EMBEDDING = "tok_embeddings.weight"
FINAL_NORM = "norm.weight"


def layer_name(i: int, suffix: str) -> str:
    return f"layers.{i}.{suffix}"


# Projections dont la sortie revient dans le flux résiduel : initialisées avec l'écart-type réduit.
RESIDUAL_SUFFIXES = ("attn.o_proj.weight", "ffn.down_proj.weight")
NORM_SUFFIXES = ("attn_norm.weight", "ffn_norm.weight")


def expected_shapes(cfg: ModelConfig) -> dict[str, tuple[int, ...]]:
    d, h, hk, hd, f = cfg.d_model, cfg.n_heads, cfg.n_kv_heads, cfg.head_dim, cfg.ffn_dim
    shapes: dict[str, tuple[int, ...]] = {EMBEDDING: (cfg.vocab_size, d), FINAL_NORM: (d,)}
    for i in range(cfg.n_layers):
        shapes[layer_name(i, "attn_norm.weight")] = (d,)
        shapes[layer_name(i, "attn.q_proj.weight")] = (h * hd, d)
        shapes[layer_name(i, "attn.k_proj.weight")] = (hk * hd, d)
        shapes[layer_name(i, "attn.v_proj.weight")] = (hk * hd, d)
        shapes[layer_name(i, "attn.o_proj.weight")] = (d, h * hd)
        shapes[layer_name(i, "ffn_norm.weight")] = (d,)
        shapes[layer_name(i, "ffn.gate_proj.weight")] = (f, d)
        shapes[layer_name(i, "ffn.up_proj.weight")] = (f, d)
        shapes[layer_name(i, "ffn.down_proj.weight")] = (d, f)
    return shapes


def total_params_from_shapes(shapes: dict[str, tuple[int, ...]]) -> int:
    total = 0
    for shape in shapes.values():
        count = 1
        for dim in shape:
            count *= dim
        total += count
    return total


def is_decay_param(name: str, shape: tuple[int, ...]) -> bool:
    """Décroissance de poids uniquement sur les matrices 2D hors embeddings (spécification §6.2)."""
    return len(shape) == 2 and name != EMBEDDING
