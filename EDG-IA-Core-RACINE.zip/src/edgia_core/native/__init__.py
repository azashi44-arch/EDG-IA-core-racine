"""EDG-IA Native : modèle de langage propriétaire d'EDG-IA (architecture, tokenizer, données, entraînement).

Ce paquet est AJOUTÉ à EDG-IA Core : il ne modifie pas le prototype de la phase 9 (`custom_model/`) et n'importe jamais
PyTorch à l'import (les modules qui en ont besoin le font paresseusement).
"""

from __future__ import annotations

NATIVE_VERSION = "0.1.0-L0"
