"""CLI d'EDG-IA Native : `python -m edgia_core.native <commande>` (aucune commande ne télécharge quoi que ce soit)."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from edgia_core.native import NATIVE_VERSION
from edgia_core.native.config import EXPECTED_PARAMS, PRESETS, TrainConfig, load_model_config
from edgia_core.native.errors import NativeError
from edgia_core.native.tokenizer import specials


def _print(obj: Any) -> None:
    print(json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=True))


def _load_train_config(path: str | None, status: str | None) -> TrainConfig:
    raw: dict[str, Any] = {}
    if path:
        import yaml

        loaded = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
        raw = loaded.get("train", loaded) if isinstance(loaded, dict) else {}
    if status:
        raw["status"] = status
    return TrainConfig.from_dict(raw)


def cmd_info(args: argparse.Namespace) -> int:
    rows = {}
    for name, cfg in PRESETS.items():
        rows[name] = {"params": cfg.param_count(), "expected_in_spec": EXPECTED_PARAMS.get(name), "d_model": cfg.d_model,
                      "layers": cfg.n_layers, "heads": f"{cfg.n_heads}/{cfg.n_kv_heads}", "ffn": cfg.ffn_dim,
                      "context": cfg.max_seq_len, "vocab": cfg.vocab_size, "profile": cfg.profile, "config_sha256": cfg.config_hash()}
    _print({"native_version": NATIVE_VERSION, "special_tokens_sha256": specials.lock_hash(), "presets": rows})
    return 0


def cmd_selfcheck(args: argparse.Namespace) -> int:
    """Contrôles sans PyTorch : formules de paramètres, verrou des jetons spéciaux, aller-retour du tokenizer de test."""
    problems: list[str] = []
    for name, expected in EXPECTED_PARAMS.items():
        if PRESETS[name].param_count() != expected:
            problems.append(f"{name} : {PRESETS[name].param_count()} ≠ {expected}")
    lock = Path(args.lock) if args.lock else None
    if lock and lock.exists() and json.loads(lock.read_text(encoding="utf-8")) != specials.lock_document():
        problems.append("special_tokens.lock.json ≠ code")
    _print({"ok": not problems, "problems": problems})
    return 0 if not problems else 1


def cmd_sources_check(args: argparse.Namespace) -> int:
    from edgia_core.native.data.registry import SourceRegistry

    report = SourceRegistry.load(args.registry).training_report()
    _print({sid: ("ADMISE (porte 1)" if not p else p) for sid, p in report.items()})
    return 0 if all(not p for p in report.values()) else 2


def cmd_data_build(args: argparse.Namespace) -> int:
    from edgia_core.native.data.pipeline import DataConfig, build_dataset, read_jsonl
    from edgia_core.native.data.registry import SourceRegistry
    from edgia_core.native.tokenizer.tokenizer import EdgiaTokenizer

    registry = SourceRegistry.load(args.registry)
    config = DataConfig(val_rate=args.val_rate, test_rate=args.test_rate, min_chars=args.min_chars, shard_tokens=args.shard_tokens,
                        tokenizer_profile=args.profile)
    records = (r for path in args.input for r in read_jsonl(path))
    tokenizer = EdgiaTokenizer.load(args.tokenizer) if args.tokenizer else None
    manifest = build_dataset(records, registry, config, args.out, tokenizer=tokenizer)
    _print({"manifest_sha256": manifest["manifest_sha256"], "counts": manifest["counts"],
            "splits": {k: {"docs": v["docs"], "tokens": v["tokens"]} for k, v in manifest["splits"].items()}})
    return 0


def cmd_data_verify(args: argparse.Namespace) -> int:
    from edgia_core.native.data.manifest import verify_manifest

    problems = verify_manifest(args.dir)
    _print({"ok": not problems, "problems": problems})
    return 0 if not problems else 1


def cmd_train_plan(args: argparse.Namespace) -> int:
    from edgia_core.native.train.loop import plan

    _print(plan(load_model_config(args.model), _load_train_config(args.train_config, None)))
    return 0


def cmd_train_run(args: argparse.Namespace) -> int:
    from edgia_core.native.train.loop import run_training

    model = load_model_config(args.model)
    train = _load_train_config(args.train_config, "smoke_test" if model.profile == "smoke" else args.status)
    if model.profile != "smoke" and not args.confirm_training:
        print("Refusé : un entraînement hors profil smoke exige --confirm-training (autorisation explicite).", file=sys.stderr)
        return 3
    _print(run_training(model, train, args.data, args.out, resume=not args.no_resume, device=args.device,
                        stop_after_step=args.stop_after_step))
    return 0


def cmd_ckpt_verify(args: argparse.Namespace) -> int:
    from edgia_core.native.train.checkpoint import list_checkpoints, step_dir_name, verify_checkpoint

    report = {str(s): verify_checkpoint(Path(args.dir) / step_dir_name(s)) for s in list_checkpoints(args.dir)}
    _print({"ok": all(not p for p in report.values()), "checkpoints": report})
    return 0 if all(not p for p in report.values()) else 1


def cmd_export(args: argparse.Namespace) -> int:
    from edgia_core.native.data.registry import SourceRegistry
    from edgia_core.native.tokenizer.tokenizer import EdgiaTokenizer
    from edgia_core.native.train import checkpoint as ck
    from edgia_core.native.train.export import export_model

    model = load_model_config(args.model)
    steps = ck.list_checkpoints(args.ckpt_dir)
    if not steps:
        print("Aucun checkpoint complet.", file=sys.stderr)
        return 1
    loaded = ck.load_checkpoint(Path(args.ckpt_dir) / ck.step_dir_name(steps[-1]))
    if args.status == "trained" and not args.evaluation_report:
        print("Statut « trained » : fournir --evaluation-report (rapport d'évaluation réel).", file=sys.stderr)
        return 3
    registry = SourceRegistry.load(args.registry) if args.registry else None
    info = {"checkpoint_step": steps[-1], "evaluation_report": args.evaluation_report or "aucun"}
    config = export_model(loaded["model"], model, EdgiaTokenizer.load(Path(args.data) / "tokenizer"), args.out, status=args.status,
                          dataset_dir=args.data, registry=registry, for_distribution=args.for_distribution, run_info=info)
    _print({"training_status": config["training_status"], "distribution_cleared": config["distribution_cleared"]})
    return 0


def cmd_export_random(args: argparse.Namespace) -> int:
    """Export d'un modèle à poids ALÉATOIRES (essais techniques d'intégration). Jamais une IA : statut random_init/smoke_test."""
    import numpy as np

    from edgia_core.native.reference.numpy_model import init_params
    from edgia_core.native.tokenizer.tokenizer import EdgiaTokenizer
    from edgia_core.native.train.export import export_model

    model = load_model_config(args.model)
    status = "smoke_test" if model.profile == "smoke" else "random_init"
    config = export_model(init_params(model, dtype=np.float32), model, EdgiaTokenizer.load(args.tokenizer), args.out, status=status)
    _print({"training_status": config["training_status"], "avertissement": "modèle NON entraîné"})
    return 0


def cmd_export_verify(args: argparse.Namespace) -> int:
    from edgia_core.native.train.export import verify_export

    problems = verify_export(args.dir)
    _print({"ok": not problems, "problems": problems})
    return 0 if not problems else 1


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="python -m edgia_core.native", description="EDG-IA Native — outils (aucun téléchargement).")
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("info", help="tailles et empreintes des configurations").set_defaults(func=cmd_info)
    s = sub.add_parser("selfcheck", help="contrôles sans PyTorch"); s.add_argument("--lock"); s.set_defaults(func=cmd_selfcheck)
    s = sub.add_parser("sources-check", help="porte 1 sur un registre de sources"); s.add_argument("--registry", required=True); s.set_defaults(func=cmd_sources_check)
    s = sub.add_parser("data-build", help="construit un jeu de données à partir de fichiers JSONL")
    s.add_argument("--registry", required=True); s.add_argument("--input", nargs="+", required=True); s.add_argument("--out", required=True)
    s.add_argument("--profile", choices=["smoke", "production"], default="production"); s.add_argument("--tokenizer")
    s.add_argument("--val-rate", type=float, default=0.001); s.add_argument("--test-rate", type=float, default=0.001)
    s.add_argument("--min-chars", type=int, default=200); s.add_argument("--shard-tokens", type=int, default=100_000_000)
    s.set_defaults(func=cmd_data_build)
    s = sub.add_parser("data-verify"); s.add_argument("dir"); s.set_defaults(func=cmd_data_verify)
    s = sub.add_parser("train-plan"); s.add_argument("--model", default="xs"); s.add_argument("--train-config"); s.set_defaults(func=cmd_train_plan)
    s = sub.add_parser("train-run", help="entraînement (PyTorch requis)")
    s.add_argument("--model", default="smoke"); s.add_argument("--train-config"); s.add_argument("--data", required=True); s.add_argument("--out", required=True)
    s.add_argument("--device"); s.add_argument("--status", default="pilot", choices=["pilot", "trained"]); s.add_argument("--no-resume", action="store_true")
    s.add_argument("--stop-after-step", type=int); s.add_argument("--confirm-training", action="store_true")
    s.set_defaults(func=cmd_train_run)
    s = sub.add_parser("ckpt-verify"); s.add_argument("dir"); s.set_defaults(func=cmd_ckpt_verify)
    s = sub.add_parser("export", help="exporte le dernier checkpoint pour Core")
    s.add_argument("--model", required=True); s.add_argument("--ckpt-dir", required=True); s.add_argument("--data", required=True); s.add_argument("--out", required=True)
    s.add_argument("--status", required=True, choices=["smoke_test", "pilot", "trained"]); s.add_argument("--registry"); s.add_argument("--evaluation-report")
    s.add_argument("--for-distribution", action="store_true"); s.set_defaults(func=cmd_export)
    s = sub.add_parser("export-random", help="export à poids aléatoires (essais d'intégration uniquement)")
    s.add_argument("--model", default="smoke"); s.add_argument("--tokenizer", required=True); s.add_argument("--out", required=True); s.set_defaults(func=cmd_export_random)
    s = sub.add_parser("export-verify"); s.add_argument("dir"); s.set_defaults(func=cmd_export_verify)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except NativeError as exc:
        print(f"Erreur : {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
