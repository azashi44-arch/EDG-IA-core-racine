from edgia_core.native.cli import main

raise SystemExit(main())
