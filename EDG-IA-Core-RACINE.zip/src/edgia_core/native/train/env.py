"""Environnement numérique et niveaux de reproductibilité (spécification v1.1, §7.2).

Niveau A — bit à bit : CPU, float32, mode déterministe, un seul thread, environnement IDENTIQUE.
Niveau B — reprise fidèle : même environnement, mais GPU/bf16 → tous les états sont restaurés, l'égalité bit à bit n'est PAS garantie.
Niveau C — environnement différent : reprise autorisée avec avertissement, `resume_exact = false`.
"""

from __future__ import annotations

import platform
import sys
from typing import Any

# Champs dont une différence fait passer au niveau C.
COMPARED_FIELDS = (
    "python", "numpy", "torch", "cuda", "cudnn", "device_type", "device_name", "device_capability", "device_count",
    "precision", "tf32_matmul", "tf32_cudnn", "matmul_precision", "deterministic", "num_threads", "attention_backend",
    "compiled", "micro_batch_seqs", "accumulation_steps",
)


def capture_environment(runtime: dict[str, Any] | None = None) -> dict[str, Any]:
    """Capture l'environnement. `runtime` apporte les réglages de l'exécution (précision, micro-lot, etc.)."""
    env: dict[str, Any] = {
        "python": sys.version.split()[0], "platform": platform.platform(), "numpy": None, "torch": None, "cuda": None,
        "cudnn": None, "device_type": "cpu", "device_name": "cpu", "device_capability": None, "device_count": 0,
        "tf32_matmul": None, "tf32_cudnn": None, "matmul_precision": None, "num_threads": None, "safetensors": None,
    }
    try:
        import numpy

        env["numpy"] = numpy.__version__
    except ImportError:  # pragma: no cover
        pass
    try:
        import torch

        env.update(
            torch=torch.__version__, cuda=torch.version.cuda, num_threads=torch.get_num_threads(),
            matmul_precision=torch.get_float32_matmul_precision(),
            tf32_matmul=bool(torch.backends.cuda.matmul.allow_tf32), tf32_cudnn=bool(torch.backends.cudnn.allow_tf32),
        )
        env["cudnn"] = str(torch.backends.cudnn.version()) if torch.cuda.is_available() else None
        if torch.cuda.is_available():
            index = torch.cuda.current_device()
            env.update(device_type="cuda", device_name=torch.cuda.get_device_name(index), device_count=torch.cuda.device_count(),
                       device_capability=list(torch.cuda.get_device_capability(index)))
    except ImportError:
        pass
    env.update(runtime or {})
    return env


def compare_environments(saved: dict[str, Any], current: dict[str, Any]) -> tuple[str, list[str]]:
    """Retourne (niveau « A » | « B » | « C », champs différents)."""
    diffs = [f for f in COMPARED_FIELDS if saved.get(f) != current.get(f)]
    if diffs:
        return "C", diffs
    bit_exact = (
        current.get("device_type") == "cpu" and current.get("precision") == "fp32"
        and bool(current.get("deterministic")) and current.get("num_threads") == 1
    )
    return ("A" if bit_exact else "B"), []
