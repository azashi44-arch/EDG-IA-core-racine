"""Taux d'apprentissage : échauffement linéaire puis décroissance cosinus jusqu'à min_lr (fonction PURE du pas).

Pour le pas s (0-based, celui qu'on s'apprête à appliquer) :
  warm = round(warmup_frac · max_steps)
  s < warm          → peak · (s + 1) / warm
  sinon             → min + ½ (peak − min) (1 + cos(π · (s − warm) / max(1, max_steps − warm)))      avec min = min_lr_frac · peak
"""

from __future__ import annotations

import math

from edgia_core.native.config import TrainConfig


def warmup_steps(cfg: TrainConfig) -> int:
    return int(round(cfg.warmup_frac * cfg.max_steps))


def lr_at(step: int, cfg: TrainConfig) -> float:
    if step < 0:
        raise ValueError("step négatif")
    warm = warmup_steps(cfg)
    peak = cfg.peak_lr
    low = cfg.min_lr_frac * peak
    if step < warm:
        return peak * (step + 1) / warm
    progress = min(1.0, (step - warm) / max(1, cfg.max_steps - warm))
    return low + 0.5 * (peak - low) * (1.0 + math.cos(math.pi * progress))
