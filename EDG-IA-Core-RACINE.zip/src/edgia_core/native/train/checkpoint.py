"""Checkpoints atomiques, vérifiables et SANS pickle (spécification v1.1, §7.1). Indépendant de PyTorch.

Dossier `step_NNNNNN/` : model.safetensors, optimizer.safetensors, trainer_state.json, rng.json, MANIFEST.json (SHA-256 de
chaque fichier), COMPLETE. Écriture dans un dossier temporaire puis renommage : un dossier sans COMPLETE est ignoré et
rien n'est jamais écrasé. Les tenseurs sont des tableaux NumPy (ou `RawTensor`) ; l'adaptation PyTorch est faite par l'appelant.
"""

from __future__ import annotations

import json
import os
import re
import shutil
from collections.abc import Mapping
from pathlib import Path
from typing import Any, Callable

import numpy as np

from edgia_core.native import safetensors_io as st
from edgia_core.native.errors import CheckpointError
from edgia_core.native.hashing import sha256_file, sha256_json

FILES = ("model.safetensors", "optimizer.safetensors", "trainer_state.json", "rng.json")
_STEP_DIR = re.compile(r"^step_(\d{6,})$")


def step_dir_name(step: int) -> str:
    return f"step_{step:06d}"


def _fsync_dir(path: Path) -> None:
    try:
        fd = os.open(path, os.O_RDONLY)
    except OSError:  # Windows : non supporté, sans conséquence pour la cohérence logique
        return
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def save_checkpoint(
    root: str | Path, step: int, *, model: Mapping[str, np.ndarray | st.RawTensor], optimizer: Mapping[str, np.ndarray | st.RawTensor],
    trainer_state: dict[str, Any], rng_state: dict[str, Any], _fail_after: str | None = None,
) -> Path:
    """Écrit le checkpoint `step`. `_fail_after` (tests) simule un arrêt brutal après l'écriture d'un fichier donné."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    final = root / step_dir_name(step)
    tmp = root / f".tmp_{step_dir_name(step)}"
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir()
    state = {**trainer_state, "step": step}

    def crash(name: str) -> None:
        if _fail_after == name:
            raise RuntimeError(f"arrêt simulé après {name}")

    st.save(tmp / "model.safetensors", model, {"edgia_format": "checkpoint-model-v1", "step": str(step)})
    crash("model.safetensors")
    st.save(tmp / "optimizer.safetensors", optimizer, {"edgia_format": "checkpoint-optimizer-v1", "step": str(step)})
    crash("optimizer.safetensors")
    (tmp / "trainer_state.json").write_text(json.dumps(state, indent=2, sort_keys=True), encoding="utf-8")
    (tmp / "rng.json").write_text(json.dumps(rng_state, indent=2, sort_keys=True), encoding="utf-8")
    crash("rng.json")
    manifest = {"step": step, "files": {name: sha256_file(tmp / name) for name in FILES}}
    (tmp / "MANIFEST.json").write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    (tmp / "COMPLETE").write_text(sha256_json(manifest) + "\n", encoding="utf-8")
    for name in (*FILES, "MANIFEST.json", "COMPLETE"):
        with (tmp / name).open("rb") as handle:
            os.fsync(handle.fileno())
    if final.exists():
        if (final / "COMPLETE").exists() and (final / "COMPLETE").read_text() == (tmp / "COMPLETE").read_text():
            shutil.rmtree(tmp)  # contenu strictement identique : rien à faire
            return final
        shutil.rmtree(tmp)
        raise CheckpointError(f"{final.name} existe déjà avec un contenu différent : un checkpoint n'est jamais écrasé")
    os.rename(tmp, final)
    _fsync_dir(root)
    return final


def list_checkpoints(root: str | Path) -> list[int]:
    """Pas des checkpoints COMPLETS, croissants. Les dossiers temporaires ou sans COMPLETE sont ignorés."""
    root = Path(root)
    if not root.is_dir():
        return []
    steps = []
    for child in root.iterdir():
        match = _STEP_DIR.match(child.name)
        if match and child.is_dir() and (child / "COMPLETE").is_file():
            steps.append(int(match.group(1)))
    return sorted(steps)


def verify_checkpoint(path: str | Path) -> list[str]:
    path = Path(path)
    problems: list[str] = []
    if not (path / "COMPLETE").is_file():
        return ["marqueur COMPLETE absent"]
    try:
        manifest = json.loads((path / "MANIFEST.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ["MANIFEST.json illisible"]
    if (path / "COMPLETE").read_text().strip() != sha256_json(manifest):
        problems.append("COMPLETE ne correspond pas au manifeste")
    for name in FILES:
        file = path / name
        if not file.is_file():
            problems.append(f"fichier absent : {name}")
        elif sha256_file(file) != manifest["files"].get(name):
            problems.append(f"empreinte différente : {name}")
    return problems


def load_checkpoint(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    problems = verify_checkpoint(path)
    if problems:
        raise CheckpointError(f"checkpoint {path.name} invalide : " + " ; ".join(problems))
    model, _ = st.load_numpy(path / "model.safetensors")
    optimizer, _ = st.load_numpy(path / "optimizer.safetensors")
    return {
        "model": model, "optimizer": optimizer,
        "trainer_state": json.loads((path / "trainer_state.json").read_text(encoding="utf-8")),
        "rng_state": json.loads((path / "rng.json").read_text(encoding="utf-8")),
    }


def check_resume_compatibility(trainer_state: dict[str, Any], expected: Mapping[str, str]) -> None:
    """Refuse la reprise si une empreinte (configuration, tokenizer, verrou, données) diffère."""
    bad = [k for k, v in expected.items() if trainer_state.get("fingerprints", {}).get(k) != v]
    if bad:
        raise CheckpointError("reprise refusée : empreintes différentes pour " + ", ".join(sorted(bad)))


def apply_retention(
    root: str | Path, *, keep_last: int, milestone_every: int, best_step: int | None = None, log: Callable[[str], None] | None = None,
) -> list[int]:
    """Conserve les `keep_last` derniers, le meilleur en validation et un jalon tous les `milestone_every` pas. Retourne les pas supprimés."""
    root = Path(root)
    steps = list_checkpoints(root)
    keep = set(steps[-keep_last:]) if keep_last > 0 else set()
    if best_step is not None:
        keep.add(best_step)
    if milestone_every > 0:
        keep |= {s for s in steps if s % milestone_every == 0}
    removed = []
    for step in steps:
        if step not in keep:
            shutil.rmtree(root / step_dir_name(step))
            removed.append(step)
            if log:
                log(f"checkpoint {step} supprimé (rétention)")
    return removed
