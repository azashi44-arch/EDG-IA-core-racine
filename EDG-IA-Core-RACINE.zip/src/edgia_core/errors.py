"""Erreurs communes d'EDG-IA Core."""

from __future__ import annotations

from pydantic import ValidationError


class EdgiaError(Exception):
    """Base de toutes les erreurs applicatives d'EDG-IA Core."""


class ConfigurationError(EdgiaError):
    """Configuration invalide. `problems` liste chaque problème, en français."""

    def __init__(self, problems: list[str] | str) -> None:
        if isinstance(problems, str):
            problems = [problems]
        self.problems: list[str] = list(problems)
        details = "\n".join(f"- {p}" for p in self.problems)
        super().__init__(f"Configuration invalide :\n{details}")


def format_validation_error(exc: ValidationError, prefix: str = "") -> list[str]:
    """Met en forme une erreur Pydantic SANS jamais recopier les valeurs saisies.

    Les valeurs peuvent contenir des secrets (clés d'API) : seul le nom du champ
    et le message de validation sont conservés.
    """
    lines: list[str] = []
    for err in exc.errors(include_url=False, include_context=False, include_input=False):
        location = ".".join(str(part) for part in err["loc"]) or "(racine)"
        message = err["msg"]
        if message.startswith("Value error, "):
            message = message[len("Value error, ") :]
        lines.append(f"{prefix}{location} : {message}")
    return lines
