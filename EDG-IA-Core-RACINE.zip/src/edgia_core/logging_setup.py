"""Journalisation : sur la sortie standard, sans jamais écrire le contenu des conversations par défaut."""

from __future__ import annotations

import logging

from edgia_core.config import Settings

LOGGER_NAME = "edgia_core"


def configure_logging(settings: Settings) -> logging.Logger:
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(settings.log_level.value)
    if not any(getattr(handler, "_edgia", False) for handler in logger.handlers):
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
        handler._edgia = True  # type: ignore[attr-defined]
        logger.addHandler(handler)
    logger.propagate = False
    return logger


def sanitize(value: str, limit: int = 100) -> str:
    """Neutralise les caractères de contrôle d'une valeur fournie par le client avant de la journaliser."""
    return "".join(ch if ch.isprintable() else "?" for ch in value)[:limit]
