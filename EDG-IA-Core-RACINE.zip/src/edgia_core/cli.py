"""Ligne de commande : `python -m edgia_core check-config`."""

from __future__ import annotations

import argparse
import json
import time
from collections.abc import Sequence
from pathlib import Path

from edgia_core import __version__
from edgia_core.config import build_serving_report, load_settings
from edgia_core.errors import ConfigurationError, EdgiaError
from edgia_core.model.descriptor import check_model, load_descriptor
from edgia_core.model.registry import ModelRegistry

EXIT_OK = 0
EXIT_INVALID = 2


def _check_config(env_file: Path | None) -> int:
    try:
        settings = load_settings(env_file=env_file)
    except ConfigurationError as exc:
        print("Configuration INVALIDE :")
        for problem in exc.problems:
            print(f"  - {problem}")
        return EXIT_INVALID

    report = build_serving_report(settings)

    print(f"EDG-IA Core {__version__}")
    print(f"  mode              : {settings.mode.value}")
    print(f"  écoute            : {settings.host}:{settings.port}")
    keys = len(settings.api_keys)
    print(f"  authentification  : {'activée' if settings.auth_enabled else 'désactivée'} ({keys} clé(s) configurée(s))")
    print(f"  limite de débit   : {settings.rate_limit_per_minute}/min" if settings.rate_limit_enabled else "  limite de débit   : désactivée")
    print(f"  streaming         : {'activé' if settings.streaming_enabled else 'désactivé'}")
    print(f"  contexte / sortie : {settings.max_context_tokens} / {settings.max_new_tokens} tokens")
    if report.descriptor is not None:
        d = report.descriptor
        print(f"  modèle            : {d.model_id} v{d.version} ({d.weights_format.value}, runtime {d.runtime.value})")

    for warning in report.warnings:
        print(f"AVERTISSEMENT : {warning}")
    if report.ok:
        print("Résultat : le service peut démarrer avec cette configuration.")
        return EXIT_OK
    print("Résultat : le service REFUSE de démarrer :")
    for problem in report.problems:
        print(f"  - {problem}")
    return EXIT_INVALID


def _serve(env_file: Path | None) -> int:
    from edgia_core.server import serve

    try:
        serve(load_settings(env_file=env_file))
    except ConfigurationError as exc:
        print("Le service REFUSE de démarrer :")
        for problem in exc.problems:
            print(f"  - {problem}")
        return EXIT_INVALID
    return EXIT_OK


def _models(args: argparse.Namespace) -> int:
    """Commandes du registre : list, register, validate, activate, rollback, retire."""
    try:
        registry = ModelRegistry(args.registry)
        action = args.models_command
        if action == "list":
            records = registry.list_versions()
            if not records:
                print("Registre vide.")
            for r in records:
                print(f"{r.model_id} {r.version} : {r.status}")
                for problem in r.problems:
                    print(f"    - {problem}")
            return EXIT_OK
        if action == "history":
            for at, what, model_id, version, detail in registry.history():
                print(f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(at))}  {what:<9} {model_id} {version}  {detail}")
            return EXIT_OK
        if action == "register":
            descriptor = load_descriptor(args.descriptor)
            record = registry.register(descriptor)
            print(f"Enregistrée : {record.model_id} {record.version} (état : {record.status}). Validez-la avant de l'activer.")
            return EXIT_OK
        if action == "validate":
            record = registry.validate(args.model_id, args.version)
            _problems, warnings = check_model(record.descriptor)
            print(f"{record.model_id} {record.version} : {record.status}")
            for problem in record.problems:
                print(f"    - {problem}")
            for warning in warnings:
                print(f"    AVERTISSEMENT : {warning}")
            return EXIT_OK if not record.problems else EXIT_INVALID
        if action == "activate":
            record = registry.activate(args.model_id, args.version)
        elif action == "rollback":
            record = registry.rollback()
        else:  # retire
            record = registry.retire(args.model_id, args.version)
        print(f"{record.model_id} {record.version} : {record.status}")
        return EXIT_OK
    except (EdgiaError, OSError) as exc:
        print(f"Refusé : {exc}")
        return EXIT_INVALID


def _acquire_engine(args: argparse.Namespace):
    """Moteur à évaluer : démonstration (--demo) ou vrai modèle décrit par un descripteur (--descriptor)."""
    if args.demo:
        from edgia_core.inference.demo import DemoEngine

        return DemoEngine()
    from edgia_core.model.loader import build_engine

    settings = load_settings(
        env={"EDGIA_MODE": "real", "EDGIA_AUTH_ENABLED": "false", "EDGIA_MODEL_DESCRIPTOR": str(args.descriptor)}
    )
    report = build_serving_report(settings)
    if not report.ok:
        raise ConfigurationError(list(report.problems))
    return build_engine(settings, report.descriptor)


def _eval(args: argparse.Namespace) -> int:
    """Commandes d'évaluation : validate-suite, run, compare."""
    from edgia_core.evaluation import report as report_mod
    from edgia_core.evaluation.compare import compare_results, render_comparison_markdown
    from edgia_core.evaluation.runner import run_suite
    from edgia_core.evaluation.sandbox import sandbox_available
    from edgia_core.evaluation.schema import load_suite

    try:
        if args.eval_command == "validate-suite":
            suite = load_suite(args.suite)
            review = sum(1 for c in suite.cases if c.needs_review)
            print(f"Suite valide : {suite.name}, {len(suite.cases)} cas, sha256 {suite.sha256[:16]}…")
            for category in suite.categories():
                print(f"  {category} : {sum(1 for c in suite.cases if c.category == category)} cas")
            print(f"  dont {review} à relire par un humain (sans vérification automatique)")
            return EXIT_OK
        if args.eval_command == "compare":
            comparison = compare_results(*(json.loads(p.read_text(encoding="utf-8")) for p in (args.a, args.b)))
            text = render_comparison_markdown(comparison)
            if args.out:
                args.out.parent.mkdir(parents=True, exist_ok=True)
                args.out.write_text(text, encoding="utf-8")
            print(text)
            return EXIT_OK
        # run
        suite = load_suite(args.suite)
        if args.allow_code_execution and not sandbox_available():
            raise ConfigurationError("--allow-code-execution : bac à sable indisponible sur cette plateforme.")
        out_dir = args.out or Path("eval-results") / time.strftime("%Y%m%d-%H%M%S")
        if (out_dir / "results.json").exists():
            raise ConfigurationError(f"{out_dir} contient déjà des résultats : choisissez un autre dossier (rien n'est écrasé).")
        engine = _acquire_engine(args)
        try:
            results = run_suite(
                engine,
                suite,
                allow_code=args.allow_code_execution,
                limit=args.limit,
                progress=lambda i, n, cid: print(f"[{i}/{n}] {cid}", flush=True),
            )
        finally:
            engine.close()
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
        (out_dir / "report.md").write_text(report_mod.render_markdown(results), encoding="utf-8")
        (out_dir / "report.html").write_text(report_mod.render_html(results), encoding="utf-8")
        (out_dir / "review.csv").write_text(report_mod.render_review_csv(results), encoding="utf-8")
        overall = results["summary"]["overall"]
        if results["engine"]["is_demo"]:
            print(report_mod.DEMO_BANNER)
        print(f"Terminé : {overall['counts']} — rapports dans {out_dir}")
        return EXIT_OK
    except (EdgiaError, OSError, ValueError) as exc:
        print(f"Refusé : {exc}")
        return EXIT_INVALID


def _data(args: argparse.Namespace) -> int:
    """Commandes de données : validate, prepare."""
    from edgia_core.evaluation.schema import load_suite
    from edgia_core.training.data import load_records
    from edgia_core.training.prepare import PrepareOptions, prepare, write_outputs

    try:
        records, problems = load_records(list(args.input))
        if args.data_command == "validate":
            print(f"{len(records)} enregistrement(s) valide(s), {len(problems)} problème(s).")
            for problem in problems[:50]:
                print(f"  - {problem}")
            return EXIT_OK if not problems else EXIT_INVALID
        if problems and not args.skip_invalid:
            print("Fichiers invalides (corrigez-les ou utilisez --skip-invalid pour écarter les lignes en erreur) :")
            for problem in problems[:50]:
                print(f"  - {problem}")
            return EXIT_INVALID
        options = PrepareOptions(
            allow_user_conversations=args.allow_user_conversations,
            pii_mode=args.pii,
            val_fraction=args.val_fraction,
            seed=args.seed,
        )
        suite = load_suite(args.eval_suite) if args.eval_suite else None
        result = prepare(records, options, eval_suite=suite)
        manifest = write_outputs(result, args.out, options, input_files=list(args.input))
        print(f"Entraînement : {manifest['train']['records']} · validation : {manifest['validation']['records']} · écartés : {manifest['rejected']['total']}")
        for reason, count in manifest["rejected"]["by_reason"].items():
            print(f"  écarté ({count}) : {reason}")
        for warning in manifest["warnings"]:
            print(f"AVERTISSEMENT : {warning}")
        print(f"Jeu préparé dans {args.out}")
        return EXIT_OK
    except (EdgiaError, OSError) as exc:
        print(f"Refusé : {exc}")
        return EXIT_INVALID


def _train(args: argparse.Namespace) -> int:
    """Commandes d'entraînement : plan (à blanc), run (exige --confirm-training)."""
    from edgia_core.training.config import load_training_config
    from edgia_core.training.plan import build_plan

    try:
        config = load_training_config(args.config)
        plan = build_plan(config)
        print("PLAN D'ENTRAÎNEMENT (rien n'est lancé par `plan`)")
        for key, value in plan.summary.items():
            print(f"  {key} : {value}")
        for warning in plan.warnings:
            print(f"AVERTISSEMENT : {warning}")
        if not plan.ok:
            print("Entraînement REFUSÉ :")
            for problem in plan.problems:
                print(f"  - {problem}")
            return EXIT_INVALID
        print("Plan valide.")
        if args.train_command == "plan":
            return EXIT_OK
        if not args.confirm_training:
            print("Aucun entraînement lancé : ajoutez --confirm-training pour confirmer la dépense de calcul.")
            return EXIT_INVALID
        from edgia_core.training.sft import run_sft

        report = run_sft(config, plan)
        print(f"Terminé en {report['duration_s']} s — adaptateur dans {config.output_dir / 'adapter'}")
        print(report["note"])
        return EXIT_OK
    except (EdgiaError, OSError) as exc:
        print(f"Refusé : {exc}")
        return EXIT_INVALID


def _knowledge(args: argparse.Namespace) -> int:
    """Commandes de la base documentaire : add, list, search, delete, stats."""
    from edgia_core.knowledge.store import KnowledgeBase

    try:
        kb = KnowledgeBase(args.db)
        action = args.knowledge_command
        if action == "seed-starter":
            from edgia_core.knowledge.starter import seed_starter_library

            result = seed_starter_library(kb)
            print(f"Bibliothèque de démarrage : {len(result['added'])} ajouté(s), {len(result['skipped'])} déjà présent(s).")
            print(json.dumps(result["stats"], ensure_ascii=False))
        elif action == "add":
            record = kb.add_document(
                args.file.name,
                args.file.read_bytes(),
                title=args.title or args.file.stem,
                source=args.source,
                rights=args.rights,
                collection=args.collection,
                tags=args.tag or [],
                doc_id=args.id,
            )
            print(f"Indexé : {record.id} — {record.title} ({record.n_chunks} passage(s), collection {record.collection})")
        elif action == "list":
            documents = kb.list_documents(args.collection)
            if not documents:
                print("Base vide.")
            for d in documents:
                print(f"{d.id}  [{d.collection}]  {d.title}  ({d.n_chunks} passages)  source : {d.source}  droits : {d.rights}")
        elif action == "search":
            hits = kb.search(args.query, top_k=args.top_k, collection=args.collection)
            if not hits:
                print("Aucun passage pertinent trouvé.")
            for n, h in enumerate(hits, start=1):
                print(f"[{n}] {h.title}" + (f" — {h.section}" if h.section else "") + f"  (score {h.score}, couverture {h.coverage})")
                print("    " + h.text[:300].replace("\n", " "))
        elif action == "delete":
            kb.delete_document(args.id)
            print(f"Supprimé : {args.id} (le modèle n'a rien mémorisé : aucun réentraînement nécessaire).")
        else:  # stats
            print(json.dumps(kb.stats(), ensure_ascii=False))
        return EXIT_OK
    except (EdgiaError, OSError) as exc:
        print(f"Refusé : {exc}")
        return EXIT_INVALID


def _preview(lesson, width: int = 80) -> str:
    text = lesson.content if lesson.kind == "fact" else next((m["content"] for m in lesson.messages if m["role"] == "user"), "")
    text = " ".join(text.split())
    return text if len(text) <= width else text[: width - 1] + "…"


def _learning(args: argparse.Namespace) -> int:
    """Leçons proposées par chat : init, list, show, approve, reject, delete, export, stats (relecture par un humain)."""
    from edgia_core.knowledge.store import KnowledgeBase
    from edgia_core.learning import LearningStore, export_training_jsonl, publish_lesson, reject_lesson, withdraw_lesson

    try:
        action = args.learning_command
        if action != "init" and not args.db.is_file():
            raise ConfigurationError(f"Base des leçons introuvable : {args.db} (créez-la avec `learning --db … init`).")
        store = LearningStore(args.db)
        knowledge = None
        if getattr(args, "knowledge_db", None) is not None:
            if not args.knowledge_db.is_file():
                raise ConfigurationError(f"Base documentaire introuvable : {args.knowledge_db}.")
            knowledge = KnowledgeBase(args.knowledge_db)
        if action == "init":
            print(f"Base des leçons prête : {args.db}")
        elif action == "list":
            lessons = store.list_lessons(status=args.status, kind=args.kind)
            if not lessons:
                print("Aucune leçon.")
            for lesson in lessons:
                created = time.strftime("%Y-%m-%d %H:%M", time.localtime(lesson.created_at))
                print(f"{lesson.id}  {lesson.status:<8} {lesson.kind:<7} {lesson.key_id}  {created}  {_preview(lesson)}")
        elif action == "show":
            lesson = store.get(args.id)
            print(f"{lesson.id} — {lesson.kind} — {lesson.status} — clé {lesson.key_id} — {lesson.pii_redactions} donnée(s) personnelle(s) masquée(s)")
            if lesson.kind == "fact":
                print(lesson.content)
            for turn in lesson.messages:
                print(f"[{turn['role']}] {turn['content']}")
            if lesson.reviewer_note:
                print(f"Note de relecture : {lesson.reviewer_note}")
        elif action == "approve":
            lesson = publish_lesson(store, knowledge, args.id, note=args.note)
            if lesson.doc_id:
                print(f"Validée et indexée : {lesson.id} → document {lesson.doc_id} (collection appris-chat). Les poids du modèle ne changent pas.")
            else:
                print(f"Validée : {lesson.id}. Elle sera incluse au prochain `learning export` ; rien n'entraîne le modèle automatiquement.")
        elif action == "reject":
            lesson = reject_lesson(store, args.id, note=args.note)
            print(f"Rejetée : {lesson.id}.")
        elif action == "delete":
            lesson = withdraw_lesson(store, knowledge, args.id)
            print(f"Supprimée : {lesson.id}" + (f" (document {lesson.doc_id} retiré de la base documentaire)." if lesson.doc_id else "."))
        elif action == "export":
            count = export_training_jsonl(store, args.out)
            if count:
                print(f"{count} exemple(s) validé(s) écrit(s) dans {args.out}. Étape suivante : `edgia-core data prepare {args.out} --allow-user-conversations --eval-suite …` (rien n'est entraîné).")
            else:
                print("Aucun exemple validé à exporter.")
        else:  # stats
            print(json.dumps(store.stats(), ensure_ascii=False))
        return EXIT_OK
    except (EdgiaError, OSError) as exc:
        print(f"Refusé : {exc}")
        return EXIT_INVALID


def _doctor(args: argparse.Namespace) -> int:
    from edgia_core.ops.doctor import exit_code, run_doctor

    checks = run_doctor(env_file=args.env_file)
    labels = {"ok": "OK   ", "warn": "ATTN ", "fail": "ÉCHEC"}
    for check in checks:
        print(f"[{labels[check.status]}] {check.name} : {check.detail}")
    code = exit_code(checks)
    print("Diagnostic : le service ne devrait pas être lancé tel quel." if code else "Diagnostic : aucun blocage détecté (lisez les attentions).")
    return code


def _backup(args: argparse.Namespace) -> int:
    from edgia_core.ops.backup import backup, verify_backup

    try:
        if args.verify:
            problems = verify_backup(args.verify)
            print("Sauvegarde saine." if not problems else "Sauvegarde INVALIDE :")
            for problem in problems:
                print(f"  - {problem}")
            return EXIT_OK if not problems else EXIT_INVALID
        if args.out is None:
            raise ConfigurationError("--out (ou --verify) est obligatoire.")
        manifest = backup(args.out, registry=args.registry, knowledge=args.knowledge, learning=args.learning)
        for name, info in manifest["files"].items():
            print(f"{name} : {info['bytes']} octets, sha256 {info['sha256'][:16]}…")
        print(f"Sauvegarde écrite dans {args.out} (poids du modèle non inclus).")
        return EXIT_OK
    except (EdgiaError, OSError) as exc:
        print(f"Refusé : {exc}")
        return EXIT_INVALID


def _contract_check(args: argparse.Namespace) -> int:
    import os

    from edgia_core.integration.contract_check import run_contract_check

    key = os.environ.get(args.key_env, "")
    if not key:
        print(f"Refusé : la variable d'environnement {args.key_env} est vide (la clé n'est jamais passée en argument).")
        return EXIT_INVALID
    try:
        results = run_contract_check(args.url, key, expect_real=args.expect_real, check_knowledge=args.knowledge, timeout=args.timeout)
    except (ValueError, OSError) as exc:
        print(f"Refusé : {exc}")
        return EXIT_INVALID
    for r in results:
        print(f"[{'OK   ' if r.ok else 'ÉCHEC'}] {r.name}" + (f" — {r.detail}" if r.detail else ""))
    failed = [r for r in results if not r.ok]
    print(f"Contrat : {len(results) - len(failed)}/{len(results)} vérifications réussies." + (" (formes seulement : la qualité des réponses n'est pas évaluée)" if not failed else ""))
    return EXIT_OK if not failed else EXIT_INVALID


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="edgia-core", description="EDG-IA Core")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for name, help_text in (
        ("check-config", "vérifie la configuration sans démarrer le service"),
        ("serve", "démarre le serveur HTTP (refuse de démarrer si la configuration est invalide)"),
    ):
        sub = subparsers.add_parser(name, help=help_text)
        sub.add_argument("--env-file", type=Path, default=None, help="fichier .env à lire (facultatif)")
    models = subparsers.add_parser("models", help="gère le registre de modèles (versions, validation, activation)")
    models.add_argument("--registry", type=Path, required=True, help="fichier SQLite du registre")
    models_sub = models.add_subparsers(dest="models_command", required=True)
    models_sub.add_parser("list", help="liste les versions et leur état")
    models_sub.add_parser("history", help="affiche l'historique des opérations")
    register = models_sub.add_parser("register", help="enregistre une version à partir d'un descripteur YAML")
    register.add_argument("descriptor", type=Path)
    for name in ("validate", "activate", "retire"):
        sub = models_sub.add_parser(name)
        sub.add_argument("model_id")
        sub.add_argument("version")
    models_sub.add_parser("rollback", help="revient à la version remplacée par l'activation courante")
    evaluation = subparsers.add_parser("eval", help="évalue un modèle sur une suite de cas (phase 5)")
    eval_sub = evaluation.add_subparsers(dest="eval_command", required=True)
    validate_suite = eval_sub.add_parser("validate-suite", help="vérifie le format d'une suite")
    validate_suite.add_argument("suite", type=Path)
    run = eval_sub.add_parser("run", help="exécute une suite contre un moteur")
    run.add_argument("--suite", type=Path, required=True)
    target = run.add_mutually_exclusive_group(required=True)
    target.add_argument("--demo", action="store_true", help="moteur de démonstration (résultats sans signification)")
    target.add_argument("--descriptor", type=Path, help="descripteur YAML du vrai modèle à évaluer")
    run.add_argument("--out", type=Path, default=None, help="dossier de sortie (jamais écrasé)")
    run.add_argument("--limit", type=int, default=None, help="n'exécute que les N premiers cas")
    run.add_argument("--allow-code-execution", action="store_true", help="exécute le code généré dans le bac à sable (voir docs/EVALUATION.md)")
    compare = eval_sub.add_parser("compare", help="compare deux fichiers results.json (même suite exigée)")
    compare.add_argument("a", type=Path)
    compare.add_argument("b", type=Path)
    compare.add_argument("--out", type=Path, default=None)
    data = subparsers.add_parser("data", help="valide et prépare les données d'adaptation (phase 4)")
    data_sub = data.add_subparsers(dest="data_command", required=True)
    for name, help_text in (("validate", "vérifie le format de fichiers JSONL"), ("prepare", "nettoie, dédoublonne, contrôle la contamination, découpe")):
        sub = data_sub.add_parser(name, help=help_text)
        sub.add_argument("input", type=Path, nargs="+", help="fichiers .jsonl")
        if name == "prepare":
            sub.add_argument("--out", type=Path, required=True, help="dossier de sortie (jamais écrasé)")
            sub.add_argument("--eval-suite", type=Path, default=None, help="suite d'évaluation à protéger (anti-contamination) ; sans elle, l'entraînement sera refusé")
            sub.add_argument("--pii", choices=("redact", "reject"), default="redact")
            sub.add_argument("--val-fraction", type=float, default=0.05)
            sub.add_argument("--seed", type=int, default=0)
            sub.add_argument("--skip-invalid", action="store_true", help="écarte les lignes invalides au lieu de refuser")
            sub.add_argument("--allow-user-conversations", action="store_true", help="autorise les conversations d'utilisateurs ayant un consentement inscrit")
    train = subparsers.add_parser("train", help="plan et lancement d'un entraînement LoRA (phase 4)")
    train_sub = train.add_subparsers(dest="train_command", required=True)
    for name in ("plan", "run"):
        sub = train_sub.add_parser(name, help="vérifie tout sans rien lancer" if name == "plan" else "lance l'entraînement (exige --confirm-training)")
        sub.add_argument("config", type=Path, help="configuration d'entraînement YAML")
        if name == "run":
            sub.add_argument("--confirm-training", action="store_true", help="confirme la dépense de calcul")
    knowledge = subparsers.add_parser("knowledge", help="gère la base documentaire (phase 6)")
    knowledge.add_argument("--db", type=Path, required=True, help="fichier SQLite de la base documentaire")
    knowledge_sub = knowledge.add_subparsers(dest="knowledge_command", required=True)
    knowledge_sub.add_parser("seed-starter", help="indexe la bibliothèque initiale originale EDG-IA sans écraser les documents existants")
    add = knowledge_sub.add_parser("add", help="indexe un document (.txt .md .html .docx .pdf)")
    add.add_argument("file", type=Path)
    add.add_argument("--source", required=True, help="d'où vient le document")
    add.add_argument("--rights", required=True, help="droits d'utilisation (jamais « inconnu »)")
    add.add_argument("--title", default=None)
    add.add_argument("--collection", default="general")
    add.add_argument("--tag", action="append")
    add.add_argument("--id", default=None, help="identifiant du document (sinon dérivé du contenu)")
    for name in ("list", "search"):
        sub = knowledge_sub.add_parser(name)
        sub.add_argument("--collection", default=None)
        if name == "search":
            sub.add_argument("query")
            sub.add_argument("--top-k", type=int, default=5)
    delete = knowledge_sub.add_parser("delete", help="supprime un document et ses passages")
    delete.add_argument("id")
    knowledge_sub.add_parser("stats")
    learning = subparsers.add_parser("learning", help="gère les leçons proposées par chat : relecture, publication, export")
    learning.add_argument("--db", type=Path, required=True, help="fichier SQLite des leçons")
    learning_sub = learning.add_subparsers(dest="learning_command", required=True)
    learning_sub.add_parser("init", help="crée la base des leçons")
    learning_list = learning_sub.add_parser("list", help="liste les leçons (aperçu seulement)")
    learning_list.add_argument("--status", choices=("pending", "approved", "rejected"), default=None)
    learning_list.add_argument("--kind", choices=("fact", "example"), default=None)
    learning_show = learning_sub.add_parser("show", help="affiche une leçon en entier (relecture)")
    learning_show.add_argument("id")
    for name in ("approve", "reject"):
        sub = learning_sub.add_parser(name, help="valide (un fait est indexé) une leçon en attente" if name == "approve" else "rejette une leçon en attente")
        sub.add_argument("id")
        sub.add_argument("--note", default="", help="note de relecture (500 caractères au plus)")
        if name == "approve":
            sub.add_argument("--knowledge-db", type=Path, default=None, help="base documentaire où indexer un fait (obligatoire pour un fait)")
    learning_delete = learning_sub.add_parser("delete", help="supprime une leçon (retrait du consentement) et le document indexé")
    learning_delete.add_argument("id")
    learning_delete.add_argument("--knowledge-db", type=Path, default=None, help="base documentaire à nettoyer si la leçon y est indexée")
    learning_export = learning_sub.add_parser("export", help="écrit les exemples validés au format JSONL de `data prepare` (n'écrase rien)")
    learning_export.add_argument("--out", type=Path, required=True)
    learning_sub.add_parser("stats")
    doctor = subparsers.add_parser("doctor", help="diagnostique la machine et la configuration avant un déploiement (phase 7)")
    doctor.add_argument("--env-file", type=Path, default=None, help="fichier .env à lire (facultatif)")
    backup_parser = subparsers.add_parser("backup", help="sauvegarde les bases SQLite (registre, base documentaire) ou vérifie une sauvegarde")
    backup_parser.add_argument("--registry", type=Path, default=None)
    backup_parser.add_argument("--knowledge", type=Path, default=None)
    backup_parser.add_argument("--learning", type=Path, default=None, help="base des leçons apprises par chat")
    backup_parser.add_argument("--out", type=Path, default=None, help="dossier de sauvegarde (jamais écrasé)")
    backup_parser.add_argument("--verify", type=Path, default=None, help="vérifie le dossier d'une sauvegarde existante")
    contract = subparsers.add_parser("contract-check", help="vérifie le contrat d'API d'un serveur en marche (phase 8)")
    contract.add_argument("--url", required=True, help="adresse du serveur, ex. http://127.0.0.1:8000")
    contract.add_argument("--key-env", default="EDGIA_CHECK_API_KEY", help="variable d'environnement qui contient la clé d'API")
    contract.add_argument("--expect-real", action="store_true", help="échec si le serveur est en mode démonstration")
    contract.add_argument("--knowledge", action="store_true", help="vérifie aussi la recherche documentaire")
    contract.add_argument("--timeout", type=float, default=120.0)
    args = parser.parse_args(argv)

    if args.command == "models":
        return _models(args)
    if args.command == "eval":
        return _eval(args)
    if args.command == "contract-check":
        return _contract_check(args)
    if args.command == "doctor":
        return _doctor(args)
    if args.command == "backup":
        return _backup(args)
    if args.command == "data":
        return _data(args)
    if args.command == "knowledge":
        return _knowledge(args)
    if args.command == "learning":
        return _learning(args)
    if args.command == "train":
        return _train(args)
    if args.command == "check-config":
        return _check_config(args.env_file)
    if args.command == "serve":
        return _serve(args.env_file)
    return EXIT_INVALID  # inatteignable : la sous-commande est obligatoire
