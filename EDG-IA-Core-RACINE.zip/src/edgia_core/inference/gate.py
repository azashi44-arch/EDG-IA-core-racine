"""Verrou de concurrence : borne le nombre de générations simultanées, sans file d'attente.

Une génération qui dépasse son délai d'attente ne peut pas être interrompue dans son thread : son emplacement
n'est donc libéré qu'à la fin réelle du travail, pour que la limite de concurrence reste honnête.
"""

from __future__ import annotations

import threading


class Slot:
    """Emplacement occupé. `release()` est idempotent et peut être appelé depuis n'importe quel thread."""

    def __init__(self, gate: ConcurrencyGate) -> None:
        self._gate = gate
        self._released = False

    def release(self) -> None:
        with self._gate._lock:
            if self._released:
                return
            self._released = True
            self._gate._in_flight -= 1


class ConcurrencyGate:
    def __init__(self, capacity: int) -> None:
        if capacity < 1:
            raise ValueError("capacity >= 1 est requis")
        self._capacity = capacity
        self._in_flight = 0
        self._lock = threading.Lock()

    @property
    def in_flight(self) -> int:
        with self._lock:
            return self._in_flight

    def try_acquire(self) -> Slot | None:
        with self._lock:
            if self._in_flight >= self._capacity:
                return None
            self._in_flight += 1
            return Slot(self)
