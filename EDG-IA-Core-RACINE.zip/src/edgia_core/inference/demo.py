"""Moteur de démonstration : vérifie le circuit complet (API, sécurité, limites, streaming).

Il NE génère PAS de texte avec un modèle d'IA : la réponse est une phrase fixe qui rappelle qu'il s'agit d'une
démonstration et donne des statistiques sur la requête. Il ne recopie jamais le contenu des messages.
Les « tokens » sont approchés par des mots ; ce n'est qu'une approximation.
"""

from __future__ import annotations

import asyncio
import re
import threading
import time
from collections.abc import AsyncIterator, Sequence

from edgia_core.inference.base import (
    GenerationParams,
    GenerationResult,
    InferenceEngine,
    Message,
    ModelInfo,
    StreamChunk,
)

DEMO_MODEL_ID = "edgia-demo"
DEMO_REPLY_NOTICE = "Modèle de démonstration : cette réponse n'est PAS générée par le modèle EDG-IA entraîné."

_PIECE_RE = re.compile(r"\S+\s*")


class DemoEngine(InferenceEngine):
    supports_streaming = True

    def __init__(self, delay_seconds: float = 0.0) -> None:
        self._delay = delay_seconds
        self._info = ModelInfo(
            id=DEMO_MODEL_ID,
            version="0",
            runtime="demo",
            is_demo=True,
            description="Modèle de démonstration (aucun modèle d'IA, aucune capacité réelle).",
        )

    @property
    def info(self) -> ModelInfo:
        return self._info

    def is_ready(self) -> bool:
        return True

    def count_tokens(self, messages: Sequence[Message]) -> int:
        return sum(max(1, len(message.content.split())) for message in messages)

    def _compose(self, messages: Sequence[Message]) -> str:
        users = [m for m in messages if m.role == "user"]
        last_length = len(users[-1].content) if users else 0
        return (
            f"{DEMO_REPLY_NOTICE} "
            f"Messages reçus : {len(messages)}. "
            f"Longueur du dernier message de l'utilisateur : {last_length} caractères."
        )

    def _pieces(self, messages: Sequence[Message], params: GenerationParams) -> tuple[list[str], str]:
        text = self._compose(messages)
        finish_reason = "stop"
        cut = min((i for i in (text.find(s) for s in params.stop if s) if i >= 0), default=-1)
        if cut >= 0:
            text = text[:cut]
        pieces = _PIECE_RE.findall(text)
        if len(pieces) > params.max_tokens:
            pieces = pieces[: params.max_tokens]
            finish_reason = "length"
        return pieces, finish_reason

    def generate(
        self, messages: Sequence[Message], params: GenerationParams, cancel: threading.Event | None = None
    ) -> GenerationResult:
        if self._delay:
            time.sleep(self._delay)
        pieces, finish_reason = self._pieces(messages, params)
        return GenerationResult(
            text="".join(pieces),
            finish_reason=finish_reason,
            prompt_tokens=self.count_tokens(messages),
            completion_tokens=len(pieces),
        )

    async def stream(self, messages: Sequence[Message], params: GenerationParams) -> AsyncIterator[StreamChunk]:
        if self._delay:
            await asyncio.sleep(self._delay)
        pieces, finish_reason = self._pieces(messages, params)
        for piece in pieces:
            yield StreamChunk(text=piece)
            await asyncio.sleep(0)
        yield StreamChunk(text="", finish_reason=finish_reason, completion_tokens=len(pieces))
