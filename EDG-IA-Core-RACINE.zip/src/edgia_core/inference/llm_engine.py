"""Moteur de langage générique : logique commune (arrêts, annulation, comptage, streaming) au-dessus d'un backend.

Le backend (voir `hf_backend.py` pour Transformers) sait seulement produire des morceaux de texte pour une conversation.
Cette séparation permet de tester toute la logique sans PyTorch ni poids.
"""

from __future__ import annotations

import asyncio
import threading
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Iterator, Sequence
from dataclasses import dataclass

from edgia_core.inference.base import (
    EngineError,
    GenerationParams,
    GenerationResult,
    InferenceEngine,
    Message,
    ModelInfo,
    StreamChunk,
)
from edgia_core.inference.stops import StopMatcher


@dataclass(frozen=True)
class Piece:
    """Morceau de texte produit par le modèle."""

    text: str


@dataclass(frozen=True)
class Done:
    """Dernier élément du flux d'un backend."""

    finish_reason: str  # "stop" (fin naturelle) ou "length" (limite de tokens atteinte)
    completion_tokens: int


class Backend(ABC):
    @abstractmethod
    def count_prompt_tokens(self, messages: Sequence[Message]) -> int: ...

    @abstractmethod
    def stream(
        self, messages: Sequence[Message], params: GenerationParams, cancel: threading.Event
    ) -> Iterator[Piece | Done]:
        """Produit des `Piece` puis exactement un `Done`. Doit s'arrêter rapidement quand `cancel` est positionné."""

    def close(self) -> None:
        """Libère les ressources."""


class Cancelled(EngineError):
    """La génération a été annulée (délai dépassé ou client parti)."""


class LanguageModelEngine(InferenceEngine):
    supports_streaming = True
    supports_cancel = True

    def __init__(self, info: ModelInfo, backend: Backend) -> None:
        self._info = info
        self._backend = backend
        self._closed = False

    @property
    def info(self) -> ModelInfo:
        return self._info

    def is_ready(self) -> bool:
        return not self._closed

    def count_tokens(self, messages: Sequence[Message]) -> int:
        return self._backend.count_prompt_tokens(messages)

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._backend.close()

    # --- production ------------------------------------------------------------------------------------------

    def _produce(
        self, messages: Sequence[Message], params: GenerationParams, cancel: threading.Event
    ) -> Iterator[tuple[str, str | None, int | None]]:
        """Produit (texte, finish_reason, completion_tokens) ; les deux derniers ne sont renseignés qu'à la fin."""
        if self._closed:
            raise EngineError("Le modèle est arrêté.")
        matcher = StopMatcher(params.stop)
        pieces = self._backend.stream(messages, params, cancel)
        tokens = 0
        finish = "stop"
        try:
            for item in pieces:
                if cancel.is_set():
                    raise Cancelled("Génération annulée.")
                if isinstance(item, Done):
                    finish, tokens = item.finish_reason, item.completion_tokens
                    break
                text = matcher.feed(item.text)
                if text:
                    yield text, None, None
                if matcher.stopped:
                    finish = "stop"
                    break
            else:
                raise EngineError("Le backend s'est arrêté sans signaler la fin de la génération.")
        finally:
            close = getattr(pieces, "close", None)
            if close is not None:
                close()
        tail = matcher.flush()
        if tail:
            yield tail, None, None
        yield "", finish, tokens

    def generate(
        self, messages: Sequence[Message], params: GenerationParams, cancel: threading.Event | None = None
    ) -> GenerationResult:
        cancel = cancel or threading.Event()
        parts: list[str] = []
        finish, tokens = "stop", 0
        for text, finish_reason, completion_tokens in self._produce(messages, params, cancel):
            if finish_reason is not None:
                finish, tokens = finish_reason, completion_tokens or 0
            else:
                parts.append(text)
        return GenerationResult(
            text="".join(parts),
            finish_reason=finish,
            prompt_tokens=self.count_tokens(messages),
            completion_tokens=tokens,
        )

    async def stream(self, messages: Sequence[Message], params: GenerationParams) -> AsyncIterator[StreamChunk]:
        loop = asyncio.get_running_loop()
        queue: asyncio.Queue[tuple[str, object]] = asyncio.Queue()
        cancel = threading.Event()

        def push(kind: str, value: object) -> None:
            try:
                loop.call_soon_threadsafe(queue.put_nowait, (kind, value))
            except RuntimeError:  # boucle déjà fermée : plus personne n'écoute
                pass

        def worker() -> None:
            try:
                for item in self._produce(messages, params, cancel):
                    push("item", item)
                push("end", None)
            except Cancelled:
                push("end", None)
            except BaseException as exc:  # noqa: BLE001 - transmis tel quel au consommateur
                push("error", exc)

        thread = threading.Thread(target=worker, name="edgia-stream", daemon=True)
        thread.start()
        try:
            while True:
                kind, value = await queue.get()
                if kind == "end":
                    return
                if kind == "error":
                    raise value  # type: ignore[misc]
                text, finish_reason, completion_tokens = value  # type: ignore[misc]
                if finish_reason is not None:
                    yield StreamChunk(text="", finish_reason=finish_reason, completion_tokens=completion_tokens)
                else:
                    yield StreamChunk(text=text)
        finally:
            cancel.set()  # consommateur parti ou fin normale : le thread s'arrête au prochain morceau
