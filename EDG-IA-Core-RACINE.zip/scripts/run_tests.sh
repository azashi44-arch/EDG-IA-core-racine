#!/usr/bin/env sh
# Lance les tests unitaires et d'intégration locale (sans réseau externe, sans modèle, sans GPU).
# Utilise unittest (bibliothèque standard) ; les tests de tests/unit sont aussi exécutables avec pytest.
set -eu
cd "$(dirname "$0")/.."
PYTHONPATH=src exec python3 -m unittest discover -s tests -t . -v
